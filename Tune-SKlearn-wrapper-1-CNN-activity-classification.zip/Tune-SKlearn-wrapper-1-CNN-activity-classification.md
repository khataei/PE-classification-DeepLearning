<a href="https://colab.research.google.com/github/khataei/PE-classification-DeepLearning/blob/master/Tunned-Talos-1-CNN-activity-classification.ipynb" target="_parent"><img src="https://colab.research.google.com/assets/colab-badge.svg" alt="Open In Colab"/></a>

# Talos Tuner for CNN Activity Classifier

In this notebook, we use SKlearn  to tune a CNN neural net to classify PE activity.

#### Load dependencies


```python
import os  
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt 

import tensorflow
from tensorflow.keras.utils import to_categorical
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Flatten, Dropout, Conv1D, GlobalMaxPooling1D
from tensorflow.keras.layers import AveragePooling1D, LeakyReLU , MaxPool1D, GlobalAveragePooling1D
from tensorflow.keras.callbacks import ModelCheckpoint 
from tensorflow.keras.wrappers.scikit_learn import KerasClassifier

from sklearn.metrics import roc_auc_score, roc_curve 
from sklearn.model_selection import train_test_split
from sklearn.model_selection import RandomizedSearchCV
from tensorflow.python.client import device_lib

print(device_lib.list_local_devices())
import tensorflow as tf
print("# GPUs Available: ", len(tf.config.experimental.list_physical_devices('GPU')))
tensorflow.__version__
```

    [name: "/device:CPU:0"
    device_type: "CPU"
    memory_limit: 268435456
    locality {
    }
    incarnation: 16235421425325632868
    , name: "/device:XLA_CPU:0"
    device_type: "XLA_CPU"
    memory_limit: 17179869184
    locality {
    }
    incarnation: 2893282342633056402
    physical_device_desc: "device: XLA_CPU device"
    , name: "/device:GPU:0"
    device_type: "GPU"
    memory_limit: 4022219571
    locality {
      bus_id: 1
      links {
      }
    }
    incarnation: 3545744142882031683
    physical_device_desc: "device: 0, name: Quadro P2000, pci bus id: 0000:01:00.0, compute capability: 6.1"
    , name: "/device:XLA_GPU:0"
    device_type: "XLA_GPU"
    memory_limit: 17179869184
    locality {
    }
    incarnation: 9092531367089995880
    physical_device_desc: "device: XLA_GPU device"
    ]
    # GPUs Available:  1
    




    '2.3.1'



#### Set hyperparameters


```python
# output directory name:
output_dir = 'model_output/cnn2'
input_dir =  'Z:/Research/dfuller/Walkabilly/studies/smarphone_accel/data/Ethica_Jaeger_Merged/pocket/'
input_file_name = 'pocket-NN-data.npz'

# from the data preparation section we have:
window_size_second = 3
frequency = 30
lenght_of_each_seq = window_size_second * frequency

```


```python
# sklearn hyperparams
params = {
    'n_conv_1':[256, 512, 768], # filters, a.k.a. kernels
    'k_conv_1':[3, 5], # kernel length
    'n_conv_2':[256, 512, 768], # filters, a.k.a. kernels
    'k_conv_2':[3, 5], # kernel length
    'n_conv_3':[256, 512, 768], # filters, a.k.a. kernels
    'k_conv_3':[3, 5], # kernel length
    'maxpooling_pool_size':[2, 4],
    'avepooling_pool_size':[2, 4],
    'n_dense_1':[256, 512],
    'dropout_1':[0.2, 0.4],
    'n_dense_2':[256, 512],
    'dropout_2':[0.2, 0.4],
    'activation':['elu', 'relu']
}

# training:
n_tune_iter = 20
cv = 4
epochs = 30
batch_size = 256

```

#### Load data

##### For this notebook we use the acceleration data gathered from the pocket location. It was prepared in the DataPrep-Deep notebook


```python
# read the raw file and get the keys:
raw_data = np.load(file=input_dir+input_file_name,allow_pickle=True)
for k in raw_data.keys():
    print(k)
```

    acceleration_data
    metadata
    labels
    


```python
# import the data

accel_array = raw_data['acceleration_data']
meta_array = raw_data['metadata']
labels_array = raw_data['labels']
input_shape = list(accel_array.shape)

```

#### Preprocess data

#### Convert the  labels to integer.
In the raw data format of the labels is String and there are 6 classes. 'Lying', 'Sitting', 'Self Pace walk', 'Running 3 METs',
       'Running 5 METs', 'Running 7 METs' <br>





```python
n_class = len(np.unique(labels_array))
class_list, labels_array_int = np.unique(labels_array,return_inverse=True)
```


```python
y = to_categorical(labels_array_int, num_classes=n_class)

```

### Splitting and shuffeling the data


```python
X_train, X_valid, y_train, y_valid = train_test_split(
     accel_array, y, test_size=0.1, random_state=65)
```


#### Design neural network architecture


```python
params
```




    {'n_conv_1': [256, 512, 768],
     'k_conv_1': [3, 5],
     'n_conv_2': [256, 512, 768],
     'k_conv_2': [3, 5],
     'n_conv_3': [256, 512, 768],
     'k_conv_3': [3, 5],
     'maxpooling_pool_size': [2, 4],
     'avepooling_pool_size': [2, 4],
     'n_dense_1': [256, 512],
     'dropout_1': [0.2, 0.4],
     'n_dense_2': [256, 512],
     'dropout_2': [0.2, 0.4],
     'activation': ['elu', 'relu']}




```python
def create_model(n_conv_1=256, k_conv_1=3, n_conv_2=256, k_conv_2=3, n_conv_3=256, k_conv_3=3,
                 maxpooling_pool_size = 2, avepooling_pool_size = 2, n_dense_1=256, dropout_1=0.2,
                 n_dense_2=256, dropout_2=0.2, activation= 'elu'
                ):
    model = Sequential()
    model.add(Conv1D(n_conv_1, k_conv_1, activation=activation, input_shape=input_shape[1:]))
    model.add(MaxPool1D(pool_size = maxpooling_pool_size))
    model.add(Conv1D(n_conv_2, k_conv_2, activation=activation))
    model.add(AveragePooling1D(pool_size = avepooling_pool_size))
    model.add(Conv1D(n_conv_3, k_conv_3, activation=activation))
    # model.add(GlobalMaxPooling1D())
    model.add(GlobalAveragePooling1D())
    model.add(Dense(n_dense_1, activation=activation))
    model.add(Dropout(dropout_1))
    model.add(Dense(n_dense_2, activation=activation))
    model.add(Dropout(dropout_2))
    model.add(Dense(n_class, activation='softmax'))
    model.summary()
    model.compile(loss='categorical_crossentropy', optimizer='nadam', metrics=['accuracy'])

    return model
```


```python
model_default = create_model()
model_default.summary()
```

    Model: "sequential"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d (Conv1D)              (None, 88, 256)           2560      
    _________________________________________________________________
    max_pooling1d (MaxPooling1D) (None, 44, 256)           0         
    _________________________________________________________________
    conv1d_1 (Conv1D)            (None, 42, 256)           196864    
    _________________________________________________________________
    average_pooling1d (AveragePo (None, 21, 256)           0         
    _________________________________________________________________
    conv1d_2 (Conv1D)            (None, 19, 256)           196864    
    _________________________________________________________________
    global_average_pooling1d (Gl (None, 256)               0         
    _________________________________________________________________
    dense (Dense)                (None, 256)               65792     
    _________________________________________________________________
    dropout (Dropout)            (None, 256)               0         
    _________________________________________________________________
    dense_1 (Dense)              (None, 256)               65792     
    _________________________________________________________________
    dropout_1 (Dropout)          (None, 256)               0         
    _________________________________________________________________
    dense_2 (Dense)              (None, 6)                 1542      
    =================================================================
    Total params: 529,414
    Trainable params: 529,414
    Non-trainable params: 0
    _________________________________________________________________
    Model: "sequential"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d (Conv1D)              (None, 88, 256)           2560      
    _________________________________________________________________
    max_pooling1d (MaxPooling1D) (None, 44, 256)           0         
    _________________________________________________________________
    conv1d_1 (Conv1D)            (None, 42, 256)           196864    
    _________________________________________________________________
    average_pooling1d (AveragePo (None, 21, 256)           0         
    _________________________________________________________________
    conv1d_2 (Conv1D)            (None, 19, 256)           196864    
    _________________________________________________________________
    global_average_pooling1d (Gl (None, 256)               0         
    _________________________________________________________________
    dense (Dense)                (None, 256)               65792     
    _________________________________________________________________
    dropout (Dropout)            (None, 256)               0         
    _________________________________________________________________
    dense_1 (Dense)              (None, 256)               65792     
    _________________________________________________________________
    dropout_1 (Dropout)          (None, 256)               0         
    _________________________________________________________________
    dense_2 (Dense)              (None, 6)                 1542      
    =================================================================
    Total params: 529,414
    Trainable params: 529,414
    Non-trainable params: 0
    _________________________________________________________________
    


```python
model = KerasClassifier(build_fn=create_model, epochs=epochs, batch_size=batch_size)
```


```python
%%time
rscv = RandomizedSearchCV(model, param_distributions=params, cv=cv, n_iter=n_tune_iter)
rscv_results = rscv.fit(X_train,y_train)
```

    Model: "sequential_1"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_3 (Conv1D)            (None, 86, 512)           8192      
    _________________________________________________________________
    max_pooling1d_1 (MaxPooling1 (None, 21, 512)           0         
    _________________________________________________________________
    conv1d_4 (Conv1D)            (None, 19, 768)           1180416   
    _________________________________________________________________
    average_pooling1d_1 (Average (None, 9, 768)            0         
    _________________________________________________________________
    conv1d_5 (Conv1D)            (None, 5, 768)            2949888   
    _________________________________________________________________
    global_average_pooling1d_1 ( (None, 768)               0         
    _________________________________________________________________
    dense_3 (Dense)              (None, 512)               393728    
    _________________________________________________________________
    dropout_2 (Dropout)          (None, 512)               0         
    _________________________________________________________________
    dense_4 (Dense)              (None, 512)               262656    
    _________________________________________________________________
    dropout_3 (Dropout)          (None, 512)               0         
    _________________________________________________________________
    dense_5 (Dense)              (None, 6)                 3078      
    =================================================================
    Total params: 4,797,958
    Trainable params: 4,797,958
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
      2/171 [..............................] - ETA: 5s - loss: 1.7773 - accuracy: 0.1523WARNING:tensorflow:Callbacks method `on_train_batch_end` is slow compared to the batch time (batch time: 0.0230s vs `on_train_batch_end` time: 0.0409s). Check your callbacks.
    171/171 [==============================] - 10s 61ms/step - loss: 1.1308 - accuracy: 0.5167
    Epoch 2/30
    171/171 [==============================] - 10s 57ms/step - loss: 0.7620 - accuracy: 0.6869
    Epoch 3/30
    171/171 [==============================] - 10s 57ms/step - loss: 0.4997 - accuracy: 0.8084
    Epoch 4/30
    171/171 [==============================] - 10s 57ms/step - loss: 0.3971 - accuracy: 0.8524
    Epoch 5/30
    171/171 [==============================] - 10s 60ms/step - loss: 0.3439 - accuracy: 0.8706
    Epoch 6/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.3095 - accuracy: 0.8841
    Epoch 7/30
    171/171 [==============================] - 9s 54ms/step - loss: 0.2996 - accuracy: 0.8862
    Epoch 8/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.2722 - accuracy: 0.8992
    Epoch 9/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.2471 - accuracy: 0.9083
    Epoch 10/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.2432 - accuracy: 0.9083
    Epoch 11/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.2230 - accuracy: 0.9153
    Epoch 12/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.2184 - accuracy: 0.9177
    Epoch 13/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.2031 - accuracy: 0.9239
    Epoch 14/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.1900 - accuracy: 0.9282
    Epoch 15/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.1861 - accuracy: 0.9285
    Epoch 16/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.1754 - accuracy: 0.9330
    Epoch 17/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.1653 - accuracy: 0.9366
    Epoch 18/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.1563 - accuracy: 0.9392
    Epoch 19/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.1612 - accuracy: 0.9384
    Epoch 20/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.1519 - accuracy: 0.9406
    Epoch 21/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.1466 - accuracy: 0.9446
    Epoch 22/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.1349 - accuracy: 0.9481
    Epoch 23/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.1375 - accuracy: 0.9473
    Epoch 24/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.1310 - accuracy: 0.9505
    Epoch 25/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.1227 - accuracy: 0.9531
    Epoch 26/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.1229 - accuracy: 0.9525
    Epoch 27/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.1126 - accuracy: 0.9573
    Epoch 28/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.1132 - accuracy: 0.9564
    Epoch 29/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.1165 - accuracy: 0.9552
    Epoch 30/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.1049 - accuracy: 0.9602
    57/57 [==============================] - 1s 20ms/step - loss: 0.2568 - accuracy: 0.9340
    Model: "sequential_2"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_6 (Conv1D)            (None, 86, 512)           8192      
    _________________________________________________________________
    max_pooling1d_2 (MaxPooling1 (None, 21, 512)           0         
    _________________________________________________________________
    conv1d_7 (Conv1D)            (None, 19, 768)           1180416   
    _________________________________________________________________
    average_pooling1d_2 (Average (None, 9, 768)            0         
    _________________________________________________________________
    conv1d_8 (Conv1D)            (None, 5, 768)            2949888   
    _________________________________________________________________
    global_average_pooling1d_2 ( (None, 768)               0         
    _________________________________________________________________
    dense_6 (Dense)              (None, 512)               393728    
    _________________________________________________________________
    dropout_4 (Dropout)          (None, 512)               0         
    _________________________________________________________________
    dense_7 (Dense)              (None, 512)               262656    
    _________________________________________________________________
    dropout_5 (Dropout)          (None, 512)               0         
    _________________________________________________________________
    dense_8 (Dense)              (None, 6)                 3078      
    =================================================================
    Total params: 4,797,958
    Trainable params: 4,797,958
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 10s 56ms/step - loss: 1.1357 - accuracy: 0.5219
    Epoch 2/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.7615 - accuracy: 0.6885
    Epoch 3/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.5230 - accuracy: 0.7994
    Epoch 4/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.4134 - accuracy: 0.8478
    Epoch 5/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.3493 - accuracy: 0.8690
    Epoch 6/30
    171/171 [==============================] - 9s 56ms/step - loss: 0.3317 - accuracy: 0.8760
    Epoch 7/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.2917 - accuracy: 0.8900
    Epoch 8/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.3008 - accuracy: 0.8882
    Epoch 9/30
    171/171 [==============================] - 9s 56ms/step - loss: 0.2505 - accuracy: 0.9062
    Epoch 10/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.2331 - accuracy: 0.9118
    Epoch 11/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.2411 - accuracy: 0.9116
    Epoch 12/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.2140 - accuracy: 0.9167
    Epoch 13/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.2014 - accuracy: 0.9249
    Epoch 14/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.1953 - accuracy: 0.9273
    Epoch 15/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.1775 - accuracy: 0.9327
    Epoch 16/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.2009 - accuracy: 0.9269
    Epoch 17/30
    171/171 [==============================] - 9s 56ms/step - loss: 0.1663 - accuracy: 0.9375
    Epoch 18/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.1587 - accuracy: 0.9394
    Epoch 19/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.1511 - accuracy: 0.9431
    Epoch 20/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.1447 - accuracy: 0.9459
    Epoch 21/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.1472 - accuracy: 0.9443
    Epoch 22/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.1335 - accuracy: 0.9486
    Epoch 23/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.1356 - accuracy: 0.9498
    Epoch 24/30
    171/171 [==============================] - 9s 56ms/step - loss: 0.1261 - accuracy: 0.9526
    Epoch 25/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.1234 - accuracy: 0.9536
    Epoch 26/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.1178 - accuracy: 0.9553
    Epoch 27/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.1172 - accuracy: 0.9555
    Epoch 28/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.1184 - accuracy: 0.9546
    Epoch 29/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.1119 - accuracy: 0.9582
    Epoch 30/30
    171/171 [==============================] - 9s 56ms/step - loss: 0.1087 - accuracy: 0.9593
    57/57 [==============================] - 1s 18ms/step - loss: 0.2915 - accuracy: 0.9271
    Model: "sequential_3"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_9 (Conv1D)            (None, 86, 512)           8192      
    _________________________________________________________________
    max_pooling1d_3 (MaxPooling1 (None, 21, 512)           0         
    _________________________________________________________________
    conv1d_10 (Conv1D)           (None, 19, 768)           1180416   
    _________________________________________________________________
    average_pooling1d_3 (Average (None, 9, 768)            0         
    _________________________________________________________________
    conv1d_11 (Conv1D)           (None, 5, 768)            2949888   
    _________________________________________________________________
    global_average_pooling1d_3 ( (None, 768)               0         
    _________________________________________________________________
    dense_9 (Dense)              (None, 512)               393728    
    _________________________________________________________________
    dropout_6 (Dropout)          (None, 512)               0         
    _________________________________________________________________
    dense_10 (Dense)             (None, 512)               262656    
    _________________________________________________________________
    dropout_7 (Dropout)          (None, 512)               0         
    _________________________________________________________________
    dense_11 (Dense)             (None, 6)                 3078      
    =================================================================
    Total params: 4,797,958
    Trainable params: 4,797,958
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 10s 59ms/step - loss: 1.1265 - accuracy: 0.5216
    Epoch 2/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.7369 - accuracy: 0.7031
    Epoch 3/30
    171/171 [==============================] - 9s 56ms/step - loss: 0.5084 - accuracy: 0.8096
    Epoch 4/30
    171/171 [==============================] - 9s 56ms/step - loss: 0.3902 - accuracy: 0.8514
    Epoch 5/30
    171/171 [==============================] - 9s 56ms/step - loss: 0.3475 - accuracy: 0.8676
    Epoch 6/30
    171/171 [==============================] - 9s 56ms/step - loss: 0.3197 - accuracy: 0.8821
    Epoch 7/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.2847 - accuracy: 0.8932
    Epoch 8/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.2592 - accuracy: 0.9041
    Epoch 9/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.2655 - accuracy: 0.9035
    Epoch 10/30
    171/171 [==============================] - 9s 56ms/step - loss: 0.2319 - accuracy: 0.9139
    Epoch 11/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.2141 - accuracy: 0.9199
    Epoch 12/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.2021 - accuracy: 0.9242
    Epoch 13/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.2111 - accuracy: 0.9226
    Epoch 14/30
    171/171 [==============================] - 9s 56ms/step - loss: 0.1898 - accuracy: 0.9298
    Epoch 15/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.1725 - accuracy: 0.9352
    Epoch 16/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.1729 - accuracy: 0.9346
    Epoch 17/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.1569 - accuracy: 0.9399
    Epoch 18/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1516 - accuracy: 0.9427
    Epoch 19/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.1477 - accuracy: 0.9444
    Epoch 20/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.1468 - accuracy: 0.9450
    Epoch 21/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.1345 - accuracy: 0.9488
    Epoch 22/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.1307 - accuracy: 0.9501
    Epoch 23/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.1264 - accuracy: 0.9532
    Epoch 24/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.1227 - accuracy: 0.9538
    Epoch 25/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.1144 - accuracy: 0.9570
    Epoch 26/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.1126 - accuracy: 0.9574
    Epoch 27/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.1130 - accuracy: 0.9578
    Epoch 28/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.1121 - accuracy: 0.9585
    Epoch 29/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.1077 - accuracy: 0.9597
    Epoch 30/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.1209 - accuracy: 0.9569
    57/57 [==============================] - 1s 20ms/step - loss: 0.2705 - accuracy: 0.9309
    Model: "sequential_4"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_12 (Conv1D)           (None, 86, 512)           8192      
    _________________________________________________________________
    max_pooling1d_4 (MaxPooling1 (None, 21, 512)           0         
    _________________________________________________________________
    conv1d_13 (Conv1D)           (None, 19, 768)           1180416   
    _________________________________________________________________
    average_pooling1d_4 (Average (None, 9, 768)            0         
    _________________________________________________________________
    conv1d_14 (Conv1D)           (None, 5, 768)            2949888   
    _________________________________________________________________
    global_average_pooling1d_4 ( (None, 768)               0         
    _________________________________________________________________
    dense_12 (Dense)             (None, 512)               393728    
    _________________________________________________________________
    dropout_8 (Dropout)          (None, 512)               0         
    _________________________________________________________________
    dense_13 (Dense)             (None, 512)               262656    
    _________________________________________________________________
    dropout_9 (Dropout)          (None, 512)               0         
    _________________________________________________________________
    dense_14 (Dense)             (None, 6)                 3078      
    =================================================================
    Total params: 4,797,958
    Trainable params: 4,797,958
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
      2/171 [..............................] - ETA: 8s - loss: 1.7898 - accuracy: 0.1328WARNING:tensorflow:Callbacks method `on_train_batch_end` is slow compared to the batch time (batch time: 0.0217s vs `on_train_batch_end` time: 0.0369s). Check your callbacks.
    171/171 [==============================] - 10s 56ms/step - loss: 1.1176 - accuracy: 0.5212
    Epoch 2/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.7613 - accuracy: 0.6890
    Epoch 3/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.4935 - accuracy: 0.8096
    Epoch 4/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.4282 - accuracy: 0.8409
    Epoch 5/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.3509 - accuracy: 0.8659
    Epoch 6/30
    171/171 [==============================] - 9s 56ms/step - loss: 0.3206 - accuracy: 0.8800
    Epoch 7/30
    171/171 [==============================] - 9s 56ms/step - loss: 0.2898 - accuracy: 0.8920
    Epoch 8/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.2754 - accuracy: 0.8985
    Epoch 9/30
    171/171 [==============================] - 9s 56ms/step - loss: 0.2551 - accuracy: 0.9055
    Epoch 10/30
    171/171 [==============================] - 9s 56ms/step - loss: 0.2468 - accuracy: 0.9089
    Epoch 11/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.2213 - accuracy: 0.9166
    Epoch 12/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.2250 - accuracy: 0.9191
    Epoch 13/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.2058 - accuracy: 0.9244
    Epoch 14/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.1839 - accuracy: 0.9323
    Epoch 15/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.1873 - accuracy: 0.9331
    Epoch 16/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.1660 - accuracy: 0.9373
    Epoch 17/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.2390 - accuracy: 0.9278
    Epoch 18/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.2180 - accuracy: 0.9237
    Epoch 19/30
    171/171 [==============================] - 9s 56ms/step - loss: 0.1544 - accuracy: 0.9433
    Epoch 20/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.1497 - accuracy: 0.9451
    Epoch 21/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.1411 - accuracy: 0.9480
    Epoch 22/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.1415 - accuracy: 0.9476
    Epoch 23/30
    171/171 [==============================] - 9s 56ms/step - loss: 0.1336 - accuracy: 0.9509
    Epoch 24/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.1395 - accuracy: 0.9479
    Epoch 25/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.1227 - accuracy: 0.9536
    Epoch 26/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.1196 - accuracy: 0.9548
    Epoch 27/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.1192 - accuracy: 0.9563
    Epoch 28/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.1116 - accuracy: 0.9585
    Epoch 29/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.1086 - accuracy: 0.9603
    Epoch 30/30
    171/171 [==============================] - 9s 55ms/step - loss: 0.1050 - accuracy: 0.9613
    57/57 [==============================] - 1s 18ms/step - loss: 0.2525 - accuracy: 0.9298
    Model: "sequential_5"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_15 (Conv1D)           (None, 86, 768)           12288     
    _________________________________________________________________
    max_pooling1d_5 (MaxPooling1 (None, 21, 768)           0         
    _________________________________________________________________
    conv1d_16 (Conv1D)           (None, 17, 256)           983296    
    _________________________________________________________________
    average_pooling1d_5 (Average (None, 8, 256)            0         
    _________________________________________________________________
    conv1d_17 (Conv1D)           (None, 4, 768)            983808    
    _________________________________________________________________
    global_average_pooling1d_5 ( (None, 768)               0         
    _________________________________________________________________
    dense_15 (Dense)             (None, 512)               393728    
    _________________________________________________________________
    dropout_10 (Dropout)         (None, 512)               0         
    _________________________________________________________________
    dense_16 (Dense)             (None, 256)               131328    
    _________________________________________________________________
    dropout_11 (Dropout)         (None, 256)               0         
    _________________________________________________________________
    dense_17 (Dense)             (None, 6)                 1542      
    =================================================================
    Total params: 2,505,990
    Trainable params: 2,505,990
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 8s 46ms/step - loss: 1.3300 - accuracy: 0.4427
    Epoch 2/30
    171/171 [==============================] - 7s 43ms/step - loss: 1.1243 - accuracy: 0.5357
    Epoch 3/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.9596 - accuracy: 0.6153
    Epoch 4/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.8103 - accuracy: 0.6833
    Epoch 5/30
    171/171 [==============================] - 7s 43ms/step - loss: 1.1334 - accuracy: 0.6050
    Epoch 6/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.7490 - accuracy: 0.7118
    Epoch 7/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.6585 - accuracy: 0.7443
    Epoch 8/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.6022 - accuracy: 0.7613
    Epoch 9/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.5729 - accuracy: 0.7720
    Epoch 10/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.5324 - accuracy: 0.7887
    Epoch 11/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.5023 - accuracy: 0.7990
    Epoch 12/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.4766 - accuracy: 0.8088
    Epoch 13/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.4508 - accuracy: 0.8201
    Epoch 14/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.4440 - accuracy: 0.8233
    Epoch 15/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.4300 - accuracy: 0.8311 0s - loss: 0.4304 - accura
    Epoch 16/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.4029 - accuracy: 0.8408
    Epoch 17/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.3886 - accuracy: 0.8471
    Epoch 18/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.3638 - accuracy: 0.8584
    Epoch 19/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.3558 - accuracy: 0.8605
    Epoch 20/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.3450 - accuracy: 0.8631
    Epoch 21/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.3416 - accuracy: 0.8667
    Epoch 22/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.3256 - accuracy: 0.8721
    Epoch 23/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.3198 - accuracy: 0.8761
    Epoch 24/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.3038 - accuracy: 0.8801
    Epoch 25/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.3357 - accuracy: 0.8723
    Epoch 26/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.3113 - accuracy: 0.8801
    Epoch 27/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.2832 - accuracy: 0.8887
    Epoch 28/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.2704 - accuracy: 0.8918
    Epoch 29/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.2681 - accuracy: 0.8944
    Epoch 30/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.2701 - accuracy: 0.8937
    57/57 [==============================] - 1s 17ms/step - loss: 0.3264 - accuracy: 0.8795
    Model: "sequential_6"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_18 (Conv1D)           (None, 86, 768)           12288     
    _________________________________________________________________
    max_pooling1d_6 (MaxPooling1 (None, 21, 768)           0         
    _________________________________________________________________
    conv1d_19 (Conv1D)           (None, 17, 256)           983296    
    _________________________________________________________________
    average_pooling1d_6 (Average (None, 8, 256)            0         
    _________________________________________________________________
    conv1d_20 (Conv1D)           (None, 4, 768)            983808    
    _________________________________________________________________
    global_average_pooling1d_6 ( (None, 768)               0         
    _________________________________________________________________
    dense_18 (Dense)             (None, 512)               393728    
    _________________________________________________________________
    dropout_12 (Dropout)         (None, 512)               0         
    _________________________________________________________________
    dense_19 (Dense)             (None, 256)               131328    
    _________________________________________________________________
    dropout_13 (Dropout)         (None, 256)               0         
    _________________________________________________________________
    dense_20 (Dense)             (None, 6)                 1542      
    =================================================================
    Total params: 2,505,990
    Trainable params: 2,505,990
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
      1/171 [..............................] - ETA: 5s - loss: 1.8027 - accuracy: 0.1367WARNING:tensorflow:Callbacks method `on_train_batch_end` is slow compared to the batch time (batch time: 0.0156s vs `on_train_batch_end` time: 0.0312s). Check your callbacks.
    171/171 [==============================] - 7s 43ms/step - loss: 1.3471 - accuracy: 0.4349
    Epoch 2/30
    171/171 [==============================] - 7s 43ms/step - loss: 1.1390 - accuracy: 0.5266
    Epoch 3/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.9636 - accuracy: 0.6116
    Epoch 4/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.9127 - accuracy: 0.6508
    Epoch 5/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.7356 - accuracy: 0.7134
    Epoch 6/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.6699 - accuracy: 0.7388
    Epoch 7/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.6185 - accuracy: 0.7570
    Epoch 8/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.5890 - accuracy: 0.7694
    Epoch 9/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.5349 - accuracy: 0.7879
    Epoch 10/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.5171 - accuracy: 0.7921
    Epoch 11/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.5071 - accuracy: 0.7989
    Epoch 12/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.4678 - accuracy: 0.8114
    Epoch 13/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.4432 - accuracy: 0.8235
    Epoch 14/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.4421 - accuracy: 0.8234
    Epoch 15/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.4153 - accuracy: 0.8324
    Epoch 16/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.3940 - accuracy: 0.8433
    Epoch 17/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.3792 - accuracy: 0.8488
    Epoch 18/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.3542 - accuracy: 0.8595
    Epoch 19/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.3467 - accuracy: 0.8602
    Epoch 20/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.3783 - accuracy: 0.8523
    Epoch 21/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.3201 - accuracy: 0.8717
    Epoch 22/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.3087 - accuracy: 0.8757
    Epoch 23/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.3017 - accuracy: 0.8787
    Epoch 24/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.2907 - accuracy: 0.8826
    Epoch 25/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.2811 - accuracy: 0.8852
    Epoch 26/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.2750 - accuracy: 0.8881
    Epoch 27/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.2701 - accuracy: 0.8902
    Epoch 28/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.2704 - accuracy: 0.8917
    Epoch 29/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.2510 - accuracy: 0.8977
    Epoch 30/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.2420 - accuracy: 0.9013
    57/57 [==============================] - 1s 14ms/step - loss: 0.3199 - accuracy: 0.8999
    Model: "sequential_7"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_21 (Conv1D)           (None, 86, 768)           12288     
    _________________________________________________________________
    max_pooling1d_7 (MaxPooling1 (None, 21, 768)           0         
    _________________________________________________________________
    conv1d_22 (Conv1D)           (None, 17, 256)           983296    
    _________________________________________________________________
    average_pooling1d_7 (Average (None, 8, 256)            0         
    _________________________________________________________________
    conv1d_23 (Conv1D)           (None, 4, 768)            983808    
    _________________________________________________________________
    global_average_pooling1d_7 ( (None, 768)               0         
    _________________________________________________________________
    dense_21 (Dense)             (None, 512)               393728    
    _________________________________________________________________
    dropout_14 (Dropout)         (None, 512)               0         
    _________________________________________________________________
    dense_22 (Dense)             (None, 256)               131328    
    _________________________________________________________________
    dropout_15 (Dropout)         (None, 256)               0         
    _________________________________________________________________
    dense_23 (Dense)             (None, 6)                 1542      
    =================================================================
    Total params: 2,505,990
    Trainable params: 2,505,990
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 8s 46ms/step - loss: 1.3329 - accuracy: 0.4388
    Epoch 2/30
    171/171 [==============================] - 7s 43ms/step - loss: 1.1094 - accuracy: 0.5417
    Epoch 3/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.9184 - accuracy: 0.6311
    Epoch 4/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.8021 - accuracy: 0.6889
    Epoch 5/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.9624 - accuracy: 0.6544
    Epoch 6/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.7015 - accuracy: 0.7353
    Epoch 7/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.6219 - accuracy: 0.7620
    Epoch 8/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.5650 - accuracy: 0.7776
    Epoch 9/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.5336 - accuracy: 0.7879
    Epoch 10/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.5095 - accuracy: 0.8000
    Epoch 11/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.4837 - accuracy: 0.8076
    Epoch 12/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.4518 - accuracy: 0.8166
    Epoch 13/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.4292 - accuracy: 0.8292
    Epoch 14/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.4132 - accuracy: 0.8347
    Epoch 15/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.4053 - accuracy: 0.8383
    Epoch 16/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.3901 - accuracy: 0.8432
    Epoch 17/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.3723 - accuracy: 0.8531
    Epoch 18/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.3492 - accuracy: 0.8595
    Epoch 19/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.3336 - accuracy: 0.8671
    Epoch 20/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.3262 - accuracy: 0.8701
    Epoch 21/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.3141 - accuracy: 0.8755
    Epoch 22/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.3110 - accuracy: 0.8759
    Epoch 23/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.2900 - accuracy: 0.8832
    Epoch 24/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.2829 - accuracy: 0.8862
    Epoch 25/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.2711 - accuracy: 0.8911
    Epoch 26/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.2616 - accuracy: 0.8954
    Epoch 27/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.2638 - accuracy: 0.8955
    Epoch 28/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.2401 - accuracy: 0.9029
    Epoch 29/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.2476 - accuracy: 0.9008
    Epoch 30/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.2373 - accuracy: 0.9049
    57/57 [==============================] - 1s 18ms/step - loss: 0.3228 - accuracy: 0.8938
    Model: "sequential_8"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_24 (Conv1D)           (None, 86, 768)           12288     
    _________________________________________________________________
    max_pooling1d_8 (MaxPooling1 (None, 21, 768)           0         
    _________________________________________________________________
    conv1d_25 (Conv1D)           (None, 17, 256)           983296    
    _________________________________________________________________
    average_pooling1d_8 (Average (None, 8, 256)            0         
    _________________________________________________________________
    conv1d_26 (Conv1D)           (None, 4, 768)            983808    
    _________________________________________________________________
    global_average_pooling1d_8 ( (None, 768)               0         
    _________________________________________________________________
    dense_24 (Dense)             (None, 512)               393728    
    _________________________________________________________________
    dropout_16 (Dropout)         (None, 512)               0         
    _________________________________________________________________
    dense_25 (Dense)             (None, 256)               131328    
    _________________________________________________________________
    dropout_17 (Dropout)         (None, 256)               0         
    _________________________________________________________________
    dense_26 (Dense)             (None, 6)                 1542      
    =================================================================
    Total params: 2,505,990
    Trainable params: 2,505,990
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 7s 43ms/step - loss: 1.3792 - accuracy: 0.4313
    Epoch 2/30
    171/171 [==============================] - 7s 43ms/step - loss: 1.1128 - accuracy: 0.5376
    Epoch 3/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.9679 - accuracy: 0.6053
    Epoch 4/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.8552 - accuracy: 0.6670
    Epoch 5/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.7413 - accuracy: 0.7115
    Epoch 6/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.6847 - accuracy: 0.7375
    Epoch 7/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.6262 - accuracy: 0.7554
    Epoch 8/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.5837 - accuracy: 0.7703
    Epoch 9/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.5375 - accuracy: 0.7859
    Epoch 10/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.5180 - accuracy: 0.7907
    Epoch 11/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.4853 - accuracy: 0.8054
    Epoch 12/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.4620 - accuracy: 0.8122
    Epoch 13/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.4372 - accuracy: 0.8265
    Epoch 14/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.4238 - accuracy: 0.8296
    Epoch 15/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.3959 - accuracy: 0.8406 1s -
    Epoch 16/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.3795 - accuracy: 0.8482
    Epoch 17/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.3708 - accuracy: 0.8530
    Epoch 18/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.3818 - accuracy: 0.8523
    Epoch 19/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.3371 - accuracy: 0.8675
    Epoch 20/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.3192 - accuracy: 0.8739
    Epoch 21/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.3119 - accuracy: 0.8771
    Epoch 22/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.2936 - accuracy: 0.8814
    Epoch 23/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.2832 - accuracy: 0.8858
    Epoch 24/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.2774 - accuracy: 0.8870
    Epoch 25/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.2683 - accuracy: 0.8906
    Epoch 26/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.2562 - accuracy: 0.8960
    Epoch 27/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.2581 - accuracy: 0.8960
    Epoch 28/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.2470 - accuracy: 0.9000
    Epoch 29/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.2398 - accuracy: 0.9024
    Epoch 30/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.2493 - accuracy: 0.9024
    57/57 [==============================] - 1s 14ms/step - loss: 0.3072 - accuracy: 0.9018
    Model: "sequential_9"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_27 (Conv1D)           (None, 88, 768)           7680      
    _________________________________________________________________
    max_pooling1d_9 (MaxPooling1 (None, 44, 768)           0         
    _________________________________________________________________
    conv1d_28 (Conv1D)           (None, 42, 768)           1770240   
    _________________________________________________________________
    average_pooling1d_9 (Average (None, 21, 768)           0         
    _________________________________________________________________
    conv1d_29 (Conv1D)           (None, 19, 256)           590080    
    _________________________________________________________________
    global_average_pooling1d_9 ( (None, 256)               0         
    _________________________________________________________________
    dense_27 (Dense)             (None, 512)               131584    
    _________________________________________________________________
    dropout_18 (Dropout)         (None, 512)               0         
    _________________________________________________________________
    dense_28 (Dense)             (None, 256)               131328    
    _________________________________________________________________
    dropout_19 (Dropout)         (None, 256)               0         
    _________________________________________________________________
    dense_29 (Dense)             (None, 6)                 1542      
    =================================================================
    Total params: 2,632,454
    Trainable params: 2,632,454
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
      2/171 [..............................] - ETA: 8s - loss: 1.8783 - accuracy: 0.2012WARNING:tensorflow:Callbacks method `on_train_batch_end` is slow compared to the batch time (batch time: 0.0371s vs `on_train_batch_end` time: 0.0578s). Check your callbacks.
    171/171 [==============================] - 16s 93ms/step - loss: 1.3439 - accuracy: 0.4314
    Epoch 2/30
    171/171 [==============================] - 15s 90ms/step - loss: 1.1144 - accuracy: 0.5251
    Epoch 3/30
    171/171 [==============================] - 15s 90ms/step - loss: 1.0271 - accuracy: 0.5746
    Epoch 4/30
    171/171 [==============================] - 15s 91ms/step - loss: 0.8889 - accuracy: 0.6433
    Epoch 5/30
    171/171 [==============================] - 15s 90ms/step - loss: 0.8159 - accuracy: 0.6837
    Epoch 6/30
    171/171 [==============================] - 15s 91ms/step - loss: 0.7363 - accuracy: 0.7159
    Epoch 7/30
    171/171 [==============================] - 15s 90ms/step - loss: 0.6416 - accuracy: 0.7478
    Epoch 8/30
    171/171 [==============================] - 15s 91ms/step - loss: 0.6086 - accuracy: 0.7604
    Epoch 9/30
    171/171 [==============================] - 15s 90ms/step - loss: 0.5453 - accuracy: 0.7822
    Epoch 10/30
    171/171 [==============================] - 15s 90ms/step - loss: 0.5233 - accuracy: 0.7915
    Epoch 11/30
    171/171 [==============================] - 15s 90ms/step - loss: 0.4982 - accuracy: 0.8010
    Epoch 12/30
    171/171 [==============================] - 15s 91ms/step - loss: 0.4810 - accuracy: 0.8093
    Epoch 13/30
    171/171 [==============================] - 15s 90ms/step - loss: 0.4564 - accuracy: 0.8166
    Epoch 14/30
    171/171 [==============================] - 15s 91ms/step - loss: 0.4498 - accuracy: 0.8220
    Epoch 15/30
    171/171 [==============================] - 15s 90ms/step - loss: 0.4203 - accuracy: 0.8339
    Epoch 16/30
    171/171 [==============================] - 15s 90ms/step - loss: 0.5689 - accuracy: 0.7849
    Epoch 17/30
    171/171 [==============================] - 15s 91ms/step - loss: 0.4740 - accuracy: 0.8173
    Epoch 18/30
    171/171 [==============================] - 15s 91ms/step - loss: 0.3947 - accuracy: 0.8446
    Epoch 19/30
    171/171 [==============================] - 16s 92ms/step - loss: 0.3785 - accuracy: 0.8516
    Epoch 20/30
    171/171 [==============================] - 16s 96ms/step - loss: 0.3664 - accuracy: 0.8564
    Epoch 21/30
    171/171 [==============================] - 16s 95ms/step - loss: 0.3523 - accuracy: 0.8614
    Epoch 22/30
    171/171 [==============================] - 16s 94ms/step - loss: 0.3421 - accuracy: 0.8674
    Epoch 23/30
    171/171 [==============================] - 16s 94ms/step - loss: 0.3315 - accuracy: 0.8716
    Epoch 24/30
    171/171 [==============================] - 16s 95ms/step - loss: 0.3401 - accuracy: 0.8675
    Epoch 25/30
    171/171 [==============================] - 16s 94ms/step - loss: 0.3154 - accuracy: 0.8768
    Epoch 26/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.3053 - accuracy: 0.8792
    Epoch 27/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.2993 - accuracy: 0.8816
    Epoch 28/30
    171/171 [==============================] - 16s 92ms/step - loss: 0.2983 - accuracy: 0.8839
    Epoch 29/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.2847 - accuracy: 0.8862
    Epoch 30/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.2837 - accuracy: 0.8882
    57/57 [==============================] - 2s 35ms/step - loss: 0.2681 - accuracy: 0.8971
    Model: "sequential_10"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_30 (Conv1D)           (None, 88, 768)           7680      
    _________________________________________________________________
    max_pooling1d_10 (MaxPooling (None, 44, 768)           0         
    _________________________________________________________________
    conv1d_31 (Conv1D)           (None, 42, 768)           1770240   
    _________________________________________________________________
    average_pooling1d_10 (Averag (None, 21, 768)           0         
    _________________________________________________________________
    conv1d_32 (Conv1D)           (None, 19, 256)           590080    
    _________________________________________________________________
    global_average_pooling1d_10  (None, 256)               0         
    _________________________________________________________________
    dense_30 (Dense)             (None, 512)               131584    
    _________________________________________________________________
    dropout_20 (Dropout)         (None, 512)               0         
    _________________________________________________________________
    dense_31 (Dense)             (None, 256)               131328    
    _________________________________________________________________
    dropout_21 (Dropout)         (None, 256)               0         
    _________________________________________________________________
    dense_32 (Dense)             (None, 6)                 1542      
    =================================================================
    Total params: 2,632,454
    Trainable params: 2,632,454
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 16s 91ms/step - loss: 1.3300 - accuracy: 0.4328
    Epoch 2/30
    171/171 [==============================] - 16s 91ms/step - loss: 1.1027 - accuracy: 0.5302
    Epoch 3/30
    171/171 [==============================] - 16s 91ms/step - loss: 1.0242 - accuracy: 0.5753
    Epoch 4/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.9499 - accuracy: 0.6227
    Epoch 5/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.8122 - accuracy: 0.6837
    Epoch 6/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.7454 - accuracy: 0.7110
    Epoch 7/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.6660 - accuracy: 0.7404
    Epoch 8/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.6308 - accuracy: 0.7563
    Epoch 9/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.5694 - accuracy: 0.7748
    Epoch 10/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.5230 - accuracy: 0.7941
    Epoch 11/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.5054 - accuracy: 0.7970
    Epoch 12/30
    171/171 [==============================] - 16s 92ms/step - loss: 0.5150 - accuracy: 0.7995
    Epoch 13/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.4999 - accuracy: 0.8055
    Epoch 14/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.4508 - accuracy: 0.8216
    Epoch 15/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.4515 - accuracy: 0.8230
    Epoch 16/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.5102 - accuracy: 0.8052
    Epoch 17/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.4255 - accuracy: 0.8332
    Epoch 18/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.3957 - accuracy: 0.8456
    Epoch 19/30
    171/171 [==============================] - 16s 92ms/step - loss: 0.3852 - accuracy: 0.8479
    Epoch 20/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.3794 - accuracy: 0.8538
    Epoch 21/30
    171/171 [==============================] - 16s 92ms/step - loss: 0.3662 - accuracy: 0.8579
    Epoch 22/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.3484 - accuracy: 0.8623
    Epoch 23/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.3362 - accuracy: 0.8690
    Epoch 24/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.3313 - accuracy: 0.8701
    Epoch 25/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.3264 - accuracy: 0.8714
    Epoch 26/30
    171/171 [==============================] - 16s 92ms/step - loss: 0.3141 - accuracy: 0.8762
    Epoch 27/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.3028 - accuracy: 0.8812
    Epoch 28/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.2936 - accuracy: 0.8847
    Epoch 29/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.2880 - accuracy: 0.8866
    Epoch 30/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.2905 - accuracy: 0.8863
    57/57 [==============================] - 2s 31ms/step - loss: 0.3082 - accuracy: 0.8835
    Model: "sequential_11"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_33 (Conv1D)           (None, 88, 768)           7680      
    _________________________________________________________________
    max_pooling1d_11 (MaxPooling (None, 44, 768)           0         
    _________________________________________________________________
    conv1d_34 (Conv1D)           (None, 42, 768)           1770240   
    _________________________________________________________________
    average_pooling1d_11 (Averag (None, 21, 768)           0         
    _________________________________________________________________
    conv1d_35 (Conv1D)           (None, 19, 256)           590080    
    _________________________________________________________________
    global_average_pooling1d_11  (None, 256)               0         
    _________________________________________________________________
    dense_33 (Dense)             (None, 512)               131584    
    _________________________________________________________________
    dropout_22 (Dropout)         (None, 512)               0         
    _________________________________________________________________
    dense_34 (Dense)             (None, 256)               131328    
    _________________________________________________________________
    dropout_23 (Dropout)         (None, 256)               0         
    _________________________________________________________________
    dense_35 (Dense)             (None, 6)                 1542      
    =================================================================
    Total params: 2,632,454
    Trainable params: 2,632,454
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 16s 94ms/step - loss: 1.3421 - accuracy: 0.4325
    Epoch 2/30
    171/171 [==============================] - 16s 91ms/step - loss: 1.1004 - accuracy: 0.5350
    Epoch 3/30
    171/171 [==============================] - 16s 91ms/step - loss: 1.0195 - accuracy: 0.5858
    Epoch 4/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.8733 - accuracy: 0.6550
    Epoch 5/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.7854 - accuracy: 0.6936
    Epoch 6/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.7357 - accuracy: 0.7134
    Epoch 7/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.6623 - accuracy: 0.7442
    Epoch 8/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.6133 - accuracy: 0.7607
    Epoch 9/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.5893 - accuracy: 0.7726
    Epoch 10/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.5348 - accuracy: 0.7883
    Epoch 11/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.5070 - accuracy: 0.7996
    Epoch 12/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.4806 - accuracy: 0.8098
    Epoch 13/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.4564 - accuracy: 0.8175
    Epoch 14/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.4590 - accuracy: 0.8203
    Epoch 15/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.4179 - accuracy: 0.8367
    Epoch 16/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.4035 - accuracy: 0.8427
    Epoch 17/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.4017 - accuracy: 0.8434
    Epoch 18/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.3845 - accuracy: 0.8503
    Epoch 19/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.3675 - accuracy: 0.8592
    Epoch 20/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.3645 - accuracy: 0.8590
    Epoch 21/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.3616 - accuracy: 0.8599
    Epoch 22/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.3486 - accuracy: 0.8648
    Epoch 23/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.3328 - accuracy: 0.8690
    Epoch 24/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.3244 - accuracy: 0.8727
    Epoch 25/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.3159 - accuracy: 0.8754
    Epoch 26/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.3150 - accuracy: 0.8748
    Epoch 27/30
    171/171 [==============================] - 16s 92ms/step - loss: 0.3077 - accuracy: 0.8793
    Epoch 28/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.3053 - accuracy: 0.8794
    Epoch 29/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.2901 - accuracy: 0.8862
    Epoch 30/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.2796 - accuracy: 0.8902
    57/57 [==============================] - 2s 35ms/step - loss: 0.3236 - accuracy: 0.8786
    Model: "sequential_12"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_36 (Conv1D)           (None, 88, 768)           7680      
    _________________________________________________________________
    max_pooling1d_12 (MaxPooling (None, 44, 768)           0         
    _________________________________________________________________
    conv1d_37 (Conv1D)           (None, 42, 768)           1770240   
    _________________________________________________________________
    average_pooling1d_12 (Averag (None, 21, 768)           0         
    _________________________________________________________________
    conv1d_38 (Conv1D)           (None, 19, 256)           590080    
    _________________________________________________________________
    global_average_pooling1d_12  (None, 256)               0         
    _________________________________________________________________
    dense_36 (Dense)             (None, 512)               131584    
    _________________________________________________________________
    dropout_24 (Dropout)         (None, 512)               0         
    _________________________________________________________________
    dense_37 (Dense)             (None, 256)               131328    
    _________________________________________________________________
    dropout_25 (Dropout)         (None, 256)               0         
    _________________________________________________________________
    dense_38 (Dense)             (None, 6)                 1542      
    =================================================================
    Total params: 2,632,454
    Trainable params: 2,632,454
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 16s 91ms/step - loss: 1.3403 - accuracy: 0.4252
    Epoch 2/30
    171/171 [==============================] - 16s 91ms/step - loss: 1.1122 - accuracy: 0.5267
    Epoch 3/30
    171/171 [==============================] - 16s 91ms/step - loss: 1.0069 - accuracy: 0.5816
    Epoch 4/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.9121 - accuracy: 0.6359
    Epoch 5/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.8724 - accuracy: 0.6691
    Epoch 6/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.7484 - accuracy: 0.7099
    Epoch 7/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.6742 - accuracy: 0.7357
    Epoch 8/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.6339 - accuracy: 0.7517
    Epoch 9/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.5648 - accuracy: 0.7753
    Epoch 10/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.5267 - accuracy: 0.7891
    Epoch 11/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.5042 - accuracy: 0.7990
    Epoch 12/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.5037 - accuracy: 0.8000
    Epoch 13/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.4596 - accuracy: 0.8139
    Epoch 14/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.4657 - accuracy: 0.8150
    Epoch 15/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.4290 - accuracy: 0.8302
    Epoch 16/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.4125 - accuracy: 0.8365
    Epoch 17/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.3925 - accuracy: 0.8473
    Epoch 18/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.3881 - accuracy: 0.8470
    Epoch 19/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.3746 - accuracy: 0.8527
    Epoch 20/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.3557 - accuracy: 0.8595
    Epoch 21/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.3940 - accuracy: 0.8520
    Epoch 22/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.3437 - accuracy: 0.8652
    Epoch 23/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.3320 - accuracy: 0.8683
    Epoch 24/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.3378 - accuracy: 0.8672
    Epoch 25/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.3180 - accuracy: 0.8722
    Epoch 26/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.3089 - accuracy: 0.8769
    Epoch 27/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.3078 - accuracy: 0.8802
    Epoch 28/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.2977 - accuracy: 0.8815
    Epoch 29/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.2868 - accuracy: 0.8863
    Epoch 30/30
    171/171 [==============================] - 16s 91ms/step - loss: 0.2796 - accuracy: 0.8891
    57/57 [==============================] - 2s 31ms/step - loss: 0.2657 - accuracy: 0.9016
    Model: "sequential_13"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_39 (Conv1D)           (None, 88, 256)           2560      
    _________________________________________________________________
    max_pooling1d_13 (MaxPooling (None, 44, 256)           0         
    _________________________________________________________________
    conv1d_40 (Conv1D)           (None, 42, 512)           393728    
    _________________________________________________________________
    average_pooling1d_13 (Averag (None, 10, 512)           0         
    _________________________________________________________________
    conv1d_41 (Conv1D)           (None, 8, 256)            393472    
    _________________________________________________________________
    global_average_pooling1d_13  (None, 256)               0         
    _________________________________________________________________
    dense_39 (Dense)             (None, 512)               131584    
    _________________________________________________________________
    dropout_26 (Dropout)         (None, 512)               0         
    _________________________________________________________________
    dense_40 (Dense)             (None, 512)               262656    
    _________________________________________________________________
    dropout_27 (Dropout)         (None, 512)               0         
    _________________________________________________________________
    dense_41 (Dense)             (None, 6)                 3078      
    =================================================================
    Total params: 1,187,078
    Trainable params: 1,187,078
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 5s 30ms/step - loss: 1.1482 - accuracy: 0.5172
    Epoch 2/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.8050 - accuracy: 0.6704
    Epoch 3/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.5775 - accuracy: 0.7786
    Epoch 4/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.4124 - accuracy: 0.8469
    Epoch 5/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.3692 - accuracy: 0.8659
    Epoch 6/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.3105 - accuracy: 0.8836
    Epoch 7/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.2940 - accuracy: 0.8894
    Epoch 8/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.2668 - accuracy: 0.8988
    Epoch 9/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.2647 - accuracy: 0.9018
    Epoch 10/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.2443 - accuracy: 0.9082
    Epoch 11/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.2281 - accuracy: 0.9155
    Epoch 12/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.2388 - accuracy: 0.9132
    Epoch 13/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.2183 - accuracy: 0.9185
    Epoch 14/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.2041 - accuracy: 0.9239
    Epoch 15/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.2032 - accuracy: 0.9258
    Epoch 16/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1868 - accuracy: 0.9317
    Epoch 17/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.2186 - accuracy: 0.9220
    Epoch 18/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1971 - accuracy: 0.9256
    Epoch 19/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1735 - accuracy: 0.9333
    Epoch 20/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1685 - accuracy: 0.9373
    Epoch 21/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1679 - accuracy: 0.9377
    Epoch 22/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1577 - accuracy: 0.9401
    Epoch 23/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1668 - accuracy: 0.9388
    Epoch 24/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1453 - accuracy: 0.9446
    Epoch 25/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1430 - accuracy: 0.9458
    Epoch 26/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1381 - accuracy: 0.9481
    Epoch 27/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1610 - accuracy: 0.9436
    Epoch 28/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1351 - accuracy: 0.9490
    Epoch 29/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1280 - accuracy: 0.9521
    Epoch 30/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1246 - accuracy: 0.9527
    57/57 [==============================] - 1s 12ms/step - loss: 0.2175 - accuracy: 0.9324
    Model: "sequential_14"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_42 (Conv1D)           (None, 88, 256)           2560      
    _________________________________________________________________
    max_pooling1d_14 (MaxPooling (None, 44, 256)           0         
    _________________________________________________________________
    conv1d_43 (Conv1D)           (None, 42, 512)           393728    
    _________________________________________________________________
    average_pooling1d_14 (Averag (None, 10, 512)           0         
    _________________________________________________________________
    conv1d_44 (Conv1D)           (None, 8, 256)            393472    
    _________________________________________________________________
    global_average_pooling1d_14  (None, 256)               0         
    _________________________________________________________________
    dense_42 (Dense)             (None, 512)               131584    
    _________________________________________________________________
    dropout_28 (Dropout)         (None, 512)               0         
    _________________________________________________________________
    dense_43 (Dense)             (None, 512)               262656    
    _________________________________________________________________
    dropout_29 (Dropout)         (None, 512)               0         
    _________________________________________________________________
    dense_44 (Dense)             (None, 6)                 3078      
    =================================================================
    Total params: 1,187,078
    Trainable params: 1,187,078
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 5s 29ms/step - loss: 1.1399 - accuracy: 0.5165
    Epoch 2/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.8031 - accuracy: 0.6671
    Epoch 3/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.5693 - accuracy: 0.7792
    Epoch 4/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.4441 - accuracy: 0.8390
    Epoch 5/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.3464 - accuracy: 0.8706
    Epoch 6/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.3101 - accuracy: 0.8838
    Epoch 7/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.3087 - accuracy: 0.8871
    Epoch 8/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.2724 - accuracy: 0.8979
    Epoch 9/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.2562 - accuracy: 0.9056
    Epoch 10/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.2463 - accuracy: 0.9092 0s - l
    Epoch 11/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.2515 - accuracy: 0.9102
    Epoch 12/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.2163 - accuracy: 0.9199
    Epoch 13/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.2256 - accuracy: 0.9176
    Epoch 14/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.2137 - accuracy: 0.9214
    Epoch 15/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1911 - accuracy: 0.9291
    Epoch 16/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1875 - accuracy: 0.9291
    Epoch 17/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1766 - accuracy: 0.9339
    Epoch 18/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1867 - accuracy: 0.9319
    Epoch 19/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1710 - accuracy: 0.9353
    Epoch 20/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1813 - accuracy: 0.9337
    Epoch 21/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1617 - accuracy: 0.9383
    Epoch 22/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1577 - accuracy: 0.9397
    Epoch 23/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1728 - accuracy: 0.9391
    Epoch 24/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1461 - accuracy: 0.9436
    Epoch 25/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1530 - accuracy: 0.9417
    Epoch 26/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1526 - accuracy: 0.9433
    Epoch 27/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1359 - accuracy: 0.9486
    Epoch 28/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1355 - accuracy: 0.9471
    Epoch 29/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1265 - accuracy: 0.9516
    Epoch 30/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1275 - accuracy: 0.9513
    57/57 [==============================] - 1s 11ms/step - loss: 0.1924 - accuracy: 0.9391
    Model: "sequential_15"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_45 (Conv1D)           (None, 88, 256)           2560      
    _________________________________________________________________
    max_pooling1d_15 (MaxPooling (None, 44, 256)           0         
    _________________________________________________________________
    conv1d_46 (Conv1D)           (None, 42, 512)           393728    
    _________________________________________________________________
    average_pooling1d_15 (Averag (None, 10, 512)           0         
    _________________________________________________________________
    conv1d_47 (Conv1D)           (None, 8, 256)            393472    
    _________________________________________________________________
    global_average_pooling1d_15  (None, 256)               0         
    _________________________________________________________________
    dense_45 (Dense)             (None, 512)               131584    
    _________________________________________________________________
    dropout_30 (Dropout)         (None, 512)               0         
    _________________________________________________________________
    dense_46 (Dense)             (None, 512)               262656    
    _________________________________________________________________
    dropout_31 (Dropout)         (None, 512)               0         
    _________________________________________________________________
    dense_47 (Dense)             (None, 6)                 3078      
    =================================================================
    Total params: 1,187,078
    Trainable params: 1,187,078
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 5s 30ms/step - loss: 1.1313 - accuracy: 0.5206
    Epoch 2/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.7786 - accuracy: 0.6781
    Epoch 3/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.5826 - accuracy: 0.7809
    Epoch 4/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.4139 - accuracy: 0.8464
    Epoch 5/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.3303 - accuracy: 0.8755
    Epoch 6/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.3418 - accuracy: 0.8734
    Epoch 7/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.2856 - accuracy: 0.8913
    Epoch 8/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.2597 - accuracy: 0.9022
    Epoch 9/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.2623 - accuracy: 0.9027
    Epoch 10/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.2372 - accuracy: 0.9106
    Epoch 11/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.2418 - accuracy: 0.9120
    Epoch 12/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.2108 - accuracy: 0.9220
    Epoch 13/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.2055 - accuracy: 0.9224
    Epoch 14/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.2143 - accuracy: 0.9234
    Epoch 15/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1869 - accuracy: 0.9309
    Epoch 16/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1818 - accuracy: 0.9330
    Epoch 17/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1728 - accuracy: 0.9357
    Epoch 18/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1720 - accuracy: 0.9362
    Epoch 19/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1669 - accuracy: 0.9383
    Epoch 20/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1754 - accuracy: 0.9363
    Epoch 21/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1565 - accuracy: 0.9425
    Epoch 22/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1834 - accuracy: 0.9361
    Epoch 23/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1460 - accuracy: 0.9466
    Epoch 24/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1387 - accuracy: 0.9479
    Epoch 25/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1390 - accuracy: 0.9484
    Epoch 26/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1328 - accuracy: 0.9499
    Epoch 27/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1278 - accuracy: 0.9520
    Epoch 28/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1265 - accuracy: 0.9528
    Epoch 29/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1243 - accuracy: 0.9539
    Epoch 30/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1439 - accuracy: 0.9486
    57/57 [==============================] - 1s 12ms/step - loss: 0.2216 - accuracy: 0.9292
    Model: "sequential_16"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_48 (Conv1D)           (None, 88, 256)           2560      
    _________________________________________________________________
    max_pooling1d_16 (MaxPooling (None, 44, 256)           0         
    _________________________________________________________________
    conv1d_49 (Conv1D)           (None, 42, 512)           393728    
    _________________________________________________________________
    average_pooling1d_16 (Averag (None, 10, 512)           0         
    _________________________________________________________________
    conv1d_50 (Conv1D)           (None, 8, 256)            393472    
    _________________________________________________________________
    global_average_pooling1d_16  (None, 256)               0         
    _________________________________________________________________
    dense_48 (Dense)             (None, 512)               131584    
    _________________________________________________________________
    dropout_32 (Dropout)         (None, 512)               0         
    _________________________________________________________________
    dense_49 (Dense)             (None, 512)               262656    
    _________________________________________________________________
    dropout_33 (Dropout)         (None, 512)               0         
    _________________________________________________________________
    dense_50 (Dense)             (None, 6)                 3078      
    =================================================================
    Total params: 1,187,078
    Trainable params: 1,187,078
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 5s 29ms/step - loss: 1.1439 - accuracy: 0.5123
    Epoch 2/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.8183 - accuracy: 0.6653
    Epoch 3/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.5760 - accuracy: 0.7780
    Epoch 4/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.4286 - accuracy: 0.8449
    Epoch 5/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.3531 - accuracy: 0.8692
    Epoch 6/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.3079 - accuracy: 0.8827
    Epoch 7/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.3114 - accuracy: 0.8838
    Epoch 8/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.2675 - accuracy: 0.8995
    Epoch 9/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.2645 - accuracy: 0.9017
    Epoch 10/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.2670 - accuracy: 0.9032
    Epoch 11/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.2297 - accuracy: 0.9146
    Epoch 12/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.2371 - accuracy: 0.9136
    Epoch 13/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.2079 - accuracy: 0.9220
    Epoch 14/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.2019 - accuracy: 0.9246
    Epoch 15/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1960 - accuracy: 0.9261
    Epoch 16/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.2020 - accuracy: 0.9261
    Epoch 17/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1863 - accuracy: 0.9305
    Epoch 18/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1769 - accuracy: 0.9343
    Epoch 19/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1671 - accuracy: 0.9369
    Epoch 20/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1741 - accuracy: 0.9351
    Epoch 21/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1597 - accuracy: 0.9397
    Epoch 22/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1548 - accuracy: 0.9422
    Epoch 23/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1479 - accuracy: 0.9440
    Epoch 24/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1468 - accuracy: 0.9444
    Epoch 25/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1472 - accuracy: 0.9455
    Epoch 26/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1350 - accuracy: 0.9491
    Epoch 27/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1345 - accuracy: 0.9488
    Epoch 28/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1304 - accuracy: 0.9507
    Epoch 29/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1273 - accuracy: 0.9520
    Epoch 30/30
    171/171 [==============================] - 5s 29ms/step - loss: 0.1252 - accuracy: 0.9531
    57/57 [==============================] - 1s 11ms/step - loss: 0.2075 - accuracy: 0.9347
    Model: "sequential_17"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_51 (Conv1D)           (None, 88, 256)           2560      
    _________________________________________________________________
    max_pooling1d_17 (MaxPooling (None, 22, 256)           0         
    _________________________________________________________________
    conv1d_52 (Conv1D)           (None, 18, 512)           655872    
    _________________________________________________________________
    average_pooling1d_17 (Averag (None, 9, 512)            0         
    _________________________________________________________________
    conv1d_53 (Conv1D)           (None, 5, 512)            1311232   
    _________________________________________________________________
    global_average_pooling1d_17  (None, 512)               0         
    _________________________________________________________________
    dense_51 (Dense)             (None, 512)               262656    
    _________________________________________________________________
    dropout_34 (Dropout)         (None, 512)               0         
    _________________________________________________________________
    dense_52 (Dense)             (None, 256)               131328    
    _________________________________________________________________
    dropout_35 (Dropout)         (None, 256)               0         
    _________________________________________________________________
    dense_53 (Dense)             (None, 6)                 1542      
    =================================================================
    Total params: 2,365,190
    Trainable params: 2,365,190
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
      1/171 [..............................] - ETA: 1s - loss: 1.7944 - accuracy: 0.1523WARNING:tensorflow:Callbacks method `on_train_batch_end` is slow compared to the batch time (batch time: 0.0128s vs `on_train_batch_end` time: 0.0199s). Check your callbacks.
    171/171 [==============================] - 5s 32ms/step - loss: 1.2843 - accuracy: 0.4587
    Epoch 2/30
    171/171 [==============================] - 5s 30ms/step - loss: 1.0757 - accuracy: 0.5473
    Epoch 3/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.9448 - accuracy: 0.6105
    Epoch 4/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.8038 - accuracy: 0.6792
    Epoch 5/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.7016 - accuracy: 0.7218
    Epoch 6/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.6718 - accuracy: 0.7374
    Epoch 7/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.5746 - accuracy: 0.7713
    Epoch 8/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.5282 - accuracy: 0.7875
    Epoch 9/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.5126 - accuracy: 0.7970
    Epoch 10/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.4644 - accuracy: 0.8154
    Epoch 11/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.4389 - accuracy: 0.8253
    Epoch 12/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.4242 - accuracy: 0.8325
    Epoch 13/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.4028 - accuracy: 0.8425
    Epoch 14/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.3886 - accuracy: 0.8471
    Epoch 15/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.3540 - accuracy: 0.8606
    Epoch 16/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.3372 - accuracy: 0.8661
    Epoch 17/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.3222 - accuracy: 0.8738
    Epoch 18/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.3214 - accuracy: 0.8739
    Epoch 19/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.2987 - accuracy: 0.8827
    Epoch 20/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.2875 - accuracy: 0.8884
    Epoch 21/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.2697 - accuracy: 0.8949
    Epoch 22/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.2648 - accuracy: 0.8949
    Epoch 23/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.2583 - accuracy: 0.9003
    Epoch 24/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.2459 - accuracy: 0.9051
    Epoch 25/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.2399 - accuracy: 0.9069
    Epoch 26/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.2303 - accuracy: 0.9108
    Epoch 27/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.2263 - accuracy: 0.9121
    Epoch 28/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.2165 - accuracy: 0.9148
    Epoch 29/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.2095 - accuracy: 0.9190
    Epoch 30/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.2074 - accuracy: 0.9200
    57/57 [==============================] - 1s 12ms/step - loss: 0.2989 - accuracy: 0.9065
    Model: "sequential_18"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_54 (Conv1D)           (None, 88, 256)           2560      
    _________________________________________________________________
    max_pooling1d_18 (MaxPooling (None, 22, 256)           0         
    _________________________________________________________________
    conv1d_55 (Conv1D)           (None, 18, 512)           655872    
    _________________________________________________________________
    average_pooling1d_18 (Averag (None, 9, 512)            0         
    _________________________________________________________________
    conv1d_56 (Conv1D)           (None, 5, 512)            1311232   
    _________________________________________________________________
    global_average_pooling1d_18  (None, 512)               0         
    _________________________________________________________________
    dense_54 (Dense)             (None, 512)               262656    
    _________________________________________________________________
    dropout_36 (Dropout)         (None, 512)               0         
    _________________________________________________________________
    dense_55 (Dense)             (None, 256)               131328    
    _________________________________________________________________
    dropout_37 (Dropout)         (None, 256)               0         
    _________________________________________________________________
    dense_56 (Dense)             (None, 6)                 1542      
    =================================================================
    Total params: 2,365,190
    Trainable params: 2,365,190
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 5s 30ms/step - loss: 1.2704 - accuracy: 0.4642
    Epoch 2/30
    171/171 [==============================] - 5s 30ms/step - loss: 1.1158 - accuracy: 0.5339
    Epoch 3/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.9401 - accuracy: 0.6175
    Epoch 4/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.8086 - accuracy: 0.6793
    Epoch 5/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.7058 - accuracy: 0.7180
    Epoch 6/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.7450 - accuracy: 0.7171
    Epoch 7/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.6177 - accuracy: 0.7534
    Epoch 8/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.5693 - accuracy: 0.7746
    Epoch 9/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.5188 - accuracy: 0.7926
    Epoch 10/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.4847 - accuracy: 0.8059
    Epoch 11/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.4540 - accuracy: 0.8208
    Epoch 12/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.4284 - accuracy: 0.8300
    Epoch 13/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.4008 - accuracy: 0.8420
    Epoch 14/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.4142 - accuracy: 0.8402
    Epoch 15/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.3715 - accuracy: 0.8553
    Epoch 16/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.3488 - accuracy: 0.8624
    Epoch 17/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.3365 - accuracy: 0.8679
    Epoch 18/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.3128 - accuracy: 0.8760
    Epoch 19/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.3023 - accuracy: 0.8808
    Epoch 20/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.2927 - accuracy: 0.8843
    Epoch 21/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.2821 - accuracy: 0.8876
    Epoch 22/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.2852 - accuracy: 0.8903
    Epoch 23/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.2685 - accuracy: 0.8945
    Epoch 24/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.2540 - accuracy: 0.8989
    Epoch 25/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.2469 - accuracy: 0.9034
    Epoch 26/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.2400 - accuracy: 0.9062
    Epoch 27/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.2298 - accuracy: 0.9099
    Epoch 28/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.2248 - accuracy: 0.9113
    Epoch 29/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.2232 - accuracy: 0.9129
    Epoch 30/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.2158 - accuracy: 0.9152
    57/57 [==============================] - 1s 10ms/step - loss: 0.2922 - accuracy: 0.9046
    Model: "sequential_19"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_57 (Conv1D)           (None, 88, 256)           2560      
    _________________________________________________________________
    max_pooling1d_19 (MaxPooling (None, 22, 256)           0         
    _________________________________________________________________
    conv1d_58 (Conv1D)           (None, 18, 512)           655872    
    _________________________________________________________________
    average_pooling1d_19 (Averag (None, 9, 512)            0         
    _________________________________________________________________
    conv1d_59 (Conv1D)           (None, 5, 512)            1311232   
    _________________________________________________________________
    global_average_pooling1d_19  (None, 512)               0         
    _________________________________________________________________
    dense_57 (Dense)             (None, 512)               262656    
    _________________________________________________________________
    dropout_38 (Dropout)         (None, 512)               0         
    _________________________________________________________________
    dense_58 (Dense)             (None, 256)               131328    
    _________________________________________________________________
    dropout_39 (Dropout)         (None, 256)               0         
    _________________________________________________________________
    dense_59 (Dense)             (None, 6)                 1542      
    =================================================================
    Total params: 2,365,190
    Trainable params: 2,365,190
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 6s 32ms/step - loss: 1.2762 - accuracy: 0.4555
    Epoch 2/30
    171/171 [==============================] - 5s 30ms/step - loss: 1.0950 - accuracy: 0.5462
    Epoch 3/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.9372 - accuracy: 0.6202
    Epoch 4/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.7927 - accuracy: 0.6855
    Epoch 5/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.6949 - accuracy: 0.7270
    Epoch 6/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.6401 - accuracy: 0.7436
    Epoch 7/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.5866 - accuracy: 0.7657
    Epoch 8/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.5409 - accuracy: 0.7838
    Epoch 9/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.4990 - accuracy: 0.7999
    Epoch 10/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.4725 - accuracy: 0.8114
    Epoch 11/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.6330 - accuracy: 0.7638
    Epoch 12/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.5339 - accuracy: 0.7918
    Epoch 13/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.4332 - accuracy: 0.8300
    Epoch 14/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.4144 - accuracy: 0.8375
    Epoch 15/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.3726 - accuracy: 0.8537
    Epoch 16/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.3527 - accuracy: 0.8611
    Epoch 17/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.3352 - accuracy: 0.8696 0s - loss: 0
    Epoch 18/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.3190 - accuracy: 0.8743 0s - loss:
    Epoch 19/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.3075 - accuracy: 0.8804
    Epoch 20/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.2909 - accuracy: 0.8860
    Epoch 21/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.2772 - accuracy: 0.8913 0s - l
    Epoch 22/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.2724 - accuracy: 0.8934
    Epoch 23/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.2632 - accuracy: 0.8973
    Epoch 24/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.2555 - accuracy: 0.9003
    Epoch 25/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.2675 - accuracy: 0.8978
    Epoch 26/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.2382 - accuracy: 0.9068
    Epoch 27/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.2291 - accuracy: 0.9115
    Epoch 28/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.2192 - accuracy: 0.9154
    Epoch 29/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.2106 - accuracy: 0.9179 1s
    Epoch 30/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.2153 - accuracy: 0.9178
    57/57 [==============================] - 1s 12ms/step - loss: 0.3154 - accuracy: 0.8967
    Model: "sequential_20"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_60 (Conv1D)           (None, 88, 256)           2560      
    _________________________________________________________________
    max_pooling1d_20 (MaxPooling (None, 22, 256)           0         
    _________________________________________________________________
    conv1d_61 (Conv1D)           (None, 18, 512)           655872    
    _________________________________________________________________
    average_pooling1d_20 (Averag (None, 9, 512)            0         
    _________________________________________________________________
    conv1d_62 (Conv1D)           (None, 5, 512)            1311232   
    _________________________________________________________________
    global_average_pooling1d_20  (None, 512)               0         
    _________________________________________________________________
    dense_60 (Dense)             (None, 512)               262656    
    _________________________________________________________________
    dropout_40 (Dropout)         (None, 512)               0         
    _________________________________________________________________
    dense_61 (Dense)             (None, 256)               131328    
    _________________________________________________________________
    dropout_41 (Dropout)         (None, 256)               0         
    _________________________________________________________________
    dense_62 (Dense)             (None, 6)                 1542      
    =================================================================
    Total params: 2,365,190
    Trainable params: 2,365,190
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
      1/171 [..............................] - ETA: 2s - loss: 1.7876 - accuracy: 0.1719WARNING:tensorflow:Callbacks method `on_train_batch_end` is slow compared to the batch time (batch time: 0.0119s vs `on_train_batch_end` time: 0.0200s). Check your callbacks.
    171/171 [==============================] - 5s 30ms/step - loss: 1.2726 - accuracy: 0.4588
    Epoch 2/30
    171/171 [==============================] - 5s 30ms/step - loss: 1.1202 - accuracy: 0.5325
    Epoch 3/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.9551 - accuracy: 0.6112
    Epoch 4/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.8006 - accuracy: 0.6808
    Epoch 5/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.7110 - accuracy: 0.7194
    Epoch 6/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.7042 - accuracy: 0.7271
    Epoch 7/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.6054 - accuracy: 0.7571
    Epoch 8/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.5509 - accuracy: 0.7823
    Epoch 9/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.5101 - accuracy: 0.7963
    Epoch 10/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.4814 - accuracy: 0.8080
    Epoch 11/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.4754 - accuracy: 0.8112
    Epoch 12/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.4356 - accuracy: 0.8280
    Epoch 13/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.4042 - accuracy: 0.8389
    Epoch 14/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.3831 - accuracy: 0.8473
    Epoch 15/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.3830 - accuracy: 0.8502
    Epoch 16/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.3517 - accuracy: 0.8612
    Epoch 17/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.3356 - accuracy: 0.8681
    Epoch 18/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.3228 - accuracy: 0.8724
    Epoch 19/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.3060 - accuracy: 0.8801
    Epoch 20/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.2969 - accuracy: 0.8836
    Epoch 21/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.2816 - accuracy: 0.8894
    Epoch 22/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.2720 - accuracy: 0.8939
    Epoch 23/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.2627 - accuracy: 0.8983
    Epoch 24/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.2709 - accuracy: 0.8937
    Epoch 25/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.2405 - accuracy: 0.9058
    Epoch 26/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.2369 - accuracy: 0.9069
    Epoch 27/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.2261 - accuracy: 0.9114
    Epoch 28/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.2308 - accuracy: 0.9105
    Epoch 29/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.2110 - accuracy: 0.9155
    Epoch 30/30
    171/171 [==============================] - 5s 30ms/step - loss: 0.2096 - accuracy: 0.9188
    57/57 [==============================] - 1s 10ms/step - loss: 0.3076 - accuracy: 0.9067
    Model: "sequential_21"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_63 (Conv1D)           (None, 86, 512)           8192      
    _________________________________________________________________
    max_pooling1d_21 (MaxPooling (None, 43, 512)           0         
    _________________________________________________________________
    conv1d_64 (Conv1D)           (None, 39, 512)           1311232   
    _________________________________________________________________
    average_pooling1d_21 (Averag (None, 19, 512)           0         
    _________________________________________________________________
    conv1d_65 (Conv1D)           (None, 17, 768)           1180416   
    _________________________________________________________________
    global_average_pooling1d_21  (None, 768)               0         
    _________________________________________________________________
    dense_63 (Dense)             (None, 256)               196864    
    _________________________________________________________________
    dropout_42 (Dropout)         (None, 256)               0         
    _________________________________________________________________
    dense_64 (Dense)             (None, 256)               65792     
    _________________________________________________________________
    dropout_43 (Dropout)         (None, 256)               0         
    _________________________________________________________________
    dense_65 (Dense)             (None, 6)                 1542      
    =================================================================
    Total params: 2,764,038
    Trainable params: 2,764,038
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 12s 71ms/step - loss: 1.3266 - accuracy: 0.4385
    Epoch 2/30
    171/171 [==============================] - 12s 70ms/step - loss: 1.1332 - accuracy: 0.5282
    Epoch 3/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.9489 - accuracy: 0.6181
    Epoch 4/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.8186 - accuracy: 0.6781
    Epoch 5/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.7502 - accuracy: 0.7073
    Epoch 6/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.6727 - accuracy: 0.7371
    Epoch 7/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.6173 - accuracy: 0.7590
    Epoch 8/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.5615 - accuracy: 0.7800
    Epoch 9/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.5517 - accuracy: 0.7818
    Epoch 10/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.5220 - accuracy: 0.7940
    Epoch 11/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.4802 - accuracy: 0.8089
    Epoch 12/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.4599 - accuracy: 0.8161
    Epoch 13/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.4413 - accuracy: 0.8255
    Epoch 14/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.4461 - accuracy: 0.8261
    Epoch 15/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.4371 - accuracy: 0.8279
    Epoch 16/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.4023 - accuracy: 0.8405
    Epoch 17/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.3848 - accuracy: 0.8466
    Epoch 18/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.3830 - accuracy: 0.8502
    Epoch 19/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.3921 - accuracy: 0.8495
    Epoch 20/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.3547 - accuracy: 0.8615
    Epoch 21/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.3437 - accuracy: 0.8636
    Epoch 22/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.3463 - accuracy: 0.8668
    Epoch 23/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.3946 - accuracy: 0.8525
    Epoch 24/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.3480 - accuracy: 0.8657
    Epoch 25/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.3212 - accuracy: 0.8743
    Epoch 26/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.3041 - accuracy: 0.8799
    Epoch 27/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.2978 - accuracy: 0.8834
    Epoch 28/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.2935 - accuracy: 0.8835
    Epoch 29/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.2810 - accuracy: 0.8895
    Epoch 30/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.2762 - accuracy: 0.8906
    57/57 [==============================] - 1s 25ms/step - loss: 0.2747 - accuracy: 0.8999
    Model: "sequential_22"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_66 (Conv1D)           (None, 86, 512)           8192      
    _________________________________________________________________
    max_pooling1d_22 (MaxPooling (None, 43, 512)           0         
    _________________________________________________________________
    conv1d_67 (Conv1D)           (None, 39, 512)           1311232   
    _________________________________________________________________
    average_pooling1d_22 (Averag (None, 19, 512)           0         
    _________________________________________________________________
    conv1d_68 (Conv1D)           (None, 17, 768)           1180416   
    _________________________________________________________________
    global_average_pooling1d_22  (None, 768)               0         
    _________________________________________________________________
    dense_66 (Dense)             (None, 256)               196864    
    _________________________________________________________________
    dropout_44 (Dropout)         (None, 256)               0         
    _________________________________________________________________
    dense_67 (Dense)             (None, 256)               65792     
    _________________________________________________________________
    dropout_45 (Dropout)         (None, 256)               0         
    _________________________________________________________________
    dense_68 (Dense)             (None, 6)                 1542      
    =================================================================
    Total params: 2,764,038
    Trainable params: 2,764,038
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 12s 70ms/step - loss: 1.3271 - accuracy: 0.4381
    Epoch 2/30
    171/171 [==============================] - 12s 70ms/step - loss: 1.1143 - accuracy: 0.5356
    Epoch 3/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.9559 - accuracy: 0.6191
    Epoch 4/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.8246 - accuracy: 0.6789
    Epoch 5/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.7529 - accuracy: 0.7047
    Epoch 6/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.6643 - accuracy: 0.7369
    Epoch 7/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.6146 - accuracy: 0.7580
    Epoch 8/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.5615 - accuracy: 0.7802
    Epoch 9/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.5271 - accuracy: 0.7927
    Epoch 10/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.4991 - accuracy: 0.8021
    Epoch 11/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.4686 - accuracy: 0.8136
    Epoch 12/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.5205 - accuracy: 0.7973
    Epoch 13/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.4803 - accuracy: 0.8120
    Epoch 14/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.4349 - accuracy: 0.8291
    Epoch 15/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.4116 - accuracy: 0.8389
    Epoch 16/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.4018 - accuracy: 0.8455
    Epoch 17/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.4174 - accuracy: 0.8385
    Epoch 18/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.3776 - accuracy: 0.8521
    Epoch 19/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.3718 - accuracy: 0.8539
    Epoch 20/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.3522 - accuracy: 0.8640
    Epoch 21/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.3364 - accuracy: 0.8687
    Epoch 22/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.3354 - accuracy: 0.8684
    Epoch 23/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.3238 - accuracy: 0.8730
    Epoch 24/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.3333 - accuracy: 0.8695
    Epoch 25/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.3634 - accuracy: 0.8642
    Epoch 26/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.3078 - accuracy: 0.8801
    Epoch 27/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.3022 - accuracy: 0.8822
    Epoch 28/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.2947 - accuracy: 0.8824
    Epoch 29/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.2767 - accuracy: 0.8904
    Epoch 30/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.2657 - accuracy: 0.8946
    57/57 [==============================] - 1s 23ms/step - loss: 0.2911 - accuracy: 0.8939
    Model: "sequential_23"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_69 (Conv1D)           (None, 86, 512)           8192      
    _________________________________________________________________
    max_pooling1d_23 (MaxPooling (None, 43, 512)           0         
    _________________________________________________________________
    conv1d_70 (Conv1D)           (None, 39, 512)           1311232   
    _________________________________________________________________
    average_pooling1d_23 (Averag (None, 19, 512)           0         
    _________________________________________________________________
    conv1d_71 (Conv1D)           (None, 17, 768)           1180416   
    _________________________________________________________________
    global_average_pooling1d_23  (None, 768)               0         
    _________________________________________________________________
    dense_69 (Dense)             (None, 256)               196864    
    _________________________________________________________________
    dropout_46 (Dropout)         (None, 256)               0         
    _________________________________________________________________
    dense_70 (Dense)             (None, 256)               65792     
    _________________________________________________________________
    dropout_47 (Dropout)         (None, 256)               0         
    _________________________________________________________________
    dense_71 (Dense)             (None, 6)                 1542      
    =================================================================
    Total params: 2,764,038
    Trainable params: 2,764,038
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 12s 71ms/step - loss: 1.3356 - accuracy: 0.4329
    Epoch 2/30
    171/171 [==============================] - 12s 70ms/step - loss: 1.1280 - accuracy: 0.5267
    Epoch 3/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.9462 - accuracy: 0.6209
    Epoch 4/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.8208 - accuracy: 0.6805
    Epoch 5/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.7536 - accuracy: 0.7070
    Epoch 6/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.6824 - accuracy: 0.7354
    Epoch 7/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.6218 - accuracy: 0.7582
    Epoch 8/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.5694 - accuracy: 0.7738
    Epoch 9/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.5560 - accuracy: 0.7865
    Epoch 10/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.5142 - accuracy: 0.7971
    Epoch 11/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.4864 - accuracy: 0.8072
    Epoch 12/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.4674 - accuracy: 0.8137
    Epoch 13/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.4414 - accuracy: 0.8222
    Epoch 14/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.4373 - accuracy: 0.8276
    Epoch 15/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.4436 - accuracy: 0.8270
    Epoch 16/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.4513 - accuracy: 0.8252
    Epoch 17/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.3937 - accuracy: 0.8439
    Epoch 18/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.3892 - accuracy: 0.8479
    Epoch 19/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.3722 - accuracy: 0.8544
    Epoch 20/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.3635 - accuracy: 0.8574
    Epoch 21/30
    171/171 [==============================] - 12s 71ms/step - loss: 0.3720 - accuracy: 0.8550
    Epoch 22/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.3518 - accuracy: 0.8614
    Epoch 23/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.4620 - accuracy: 0.8316
    Epoch 24/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.3622 - accuracy: 0.8582
    Epoch 25/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.3280 - accuracy: 0.8709
    Epoch 26/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.3139 - accuracy: 0.8766
    Epoch 27/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.3101 - accuracy: 0.8772
    Epoch 28/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.3071 - accuracy: 0.8776
    Epoch 29/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.2998 - accuracy: 0.8806
    Epoch 30/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.2858 - accuracy: 0.8865
    57/57 [==============================] - 1s 25ms/step - loss: 0.3128 - accuracy: 0.8794
    Model: "sequential_24"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_72 (Conv1D)           (None, 86, 512)           8192      
    _________________________________________________________________
    max_pooling1d_24 (MaxPooling (None, 43, 512)           0         
    _________________________________________________________________
    conv1d_73 (Conv1D)           (None, 39, 512)           1311232   
    _________________________________________________________________
    average_pooling1d_24 (Averag (None, 19, 512)           0         
    _________________________________________________________________
    conv1d_74 (Conv1D)           (None, 17, 768)           1180416   
    _________________________________________________________________
    global_average_pooling1d_24  (None, 768)               0         
    _________________________________________________________________
    dense_72 (Dense)             (None, 256)               196864    
    _________________________________________________________________
    dropout_48 (Dropout)         (None, 256)               0         
    _________________________________________________________________
    dense_73 (Dense)             (None, 256)               65792     
    _________________________________________________________________
    dropout_49 (Dropout)         (None, 256)               0         
    _________________________________________________________________
    dense_74 (Dense)             (None, 6)                 1542      
    =================================================================
    Total params: 2,764,038
    Trainable params: 2,764,038
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 12s 70ms/step - loss: 1.3183 - accuracy: 0.4397
    Epoch 2/30
    171/171 [==============================] - 12s 70ms/step - loss: 1.1111 - accuracy: 0.5358
    Epoch 3/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.9344 - accuracy: 0.6266
    Epoch 4/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.8214 - accuracy: 0.6769
    Epoch 5/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.7505 - accuracy: 0.7064
    Epoch 6/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.6774 - accuracy: 0.7333
    Epoch 7/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.6059 - accuracy: 0.7644
    Epoch 8/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.7725 - accuracy: 0.7096
    Epoch 9/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.5549 - accuracy: 0.7809
    Epoch 10/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.5078 - accuracy: 0.7981
    Epoch 11/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.4829 - accuracy: 0.8075
    Epoch 12/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.4941 - accuracy: 0.8048
    Epoch 13/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.4499 - accuracy: 0.8214
    Epoch 14/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.4356 - accuracy: 0.8264
    Epoch 15/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.4410 - accuracy: 0.8286
    Epoch 16/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.4058 - accuracy: 0.8391
    Epoch 17/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.4028 - accuracy: 0.8407
    Epoch 18/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.3786 - accuracy: 0.8505
    Epoch 19/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.3920 - accuracy: 0.8463
    Epoch 20/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.3733 - accuracy: 0.8521
    Epoch 21/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.3483 - accuracy: 0.8627
    Epoch 22/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.3470 - accuracy: 0.8622
    Epoch 23/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.3684 - accuracy: 0.8591
    Epoch 24/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.3283 - accuracy: 0.87220s - loss: 0.3281 - accura
    Epoch 25/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.3164 - accuracy: 0.8763
    Epoch 26/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.3106 - accuracy: 0.8773
    Epoch 27/30
    171/171 [==============================] - 12s 71ms/step - loss: 0.3029 - accuracy: 0.8801
    Epoch 28/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.3074 - accuracy: 0.8782
    Epoch 29/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.2884 - accuracy: 0.8867
    Epoch 30/30
    171/171 [==============================] - 12s 70ms/step - loss: 0.2865 - accuracy: 0.8874
    57/57 [==============================] - 1s 23ms/step - loss: 0.2791 - accuracy: 0.8923
    Model: "sequential_25"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_75 (Conv1D)           (None, 88, 512)           5120      
    _________________________________________________________________
    max_pooling1d_25 (MaxPooling (None, 22, 512)           0         
    _________________________________________________________________
    conv1d_76 (Conv1D)           (None, 20, 512)           786944    
    _________________________________________________________________
    average_pooling1d_25 (Averag (None, 10, 512)           0         
    _________________________________________________________________
    conv1d_77 (Conv1D)           (None, 8, 256)            393472    
    _________________________________________________________________
    global_average_pooling1d_25  (None, 256)               0         
    _________________________________________________________________
    dense_75 (Dense)             (None, 256)               65792     
    _________________________________________________________________
    dropout_50 (Dropout)         (None, 256)               0         
    _________________________________________________________________
    dense_76 (Dense)             (None, 512)               131584    
    _________________________________________________________________
    dropout_51 (Dropout)         (None, 512)               0         
    _________________________________________________________________
    dense_77 (Dense)             (None, 6)                 3078      
    =================================================================
    Total params: 1,385,990
    Trainable params: 1,385,990
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 6s 36ms/step - loss: 1.2290 - accuracy: 0.4756
    Epoch 2/30
    171/171 [==============================] - 6s 33ms/step - loss: 1.0508 - accuracy: 0.5573
    Epoch 3/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.9493 - accuracy: 0.6100
    Epoch 4/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.8384 - accuracy: 0.6572
    Epoch 5/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.7634 - accuracy: 0.6944
    Epoch 6/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.6933 - accuracy: 0.7239
    Epoch 7/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.6190 - accuracy: 0.7562
    Epoch 8/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.5787 - accuracy: 0.7731
    Epoch 9/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.5269 - accuracy: 0.7947
    Epoch 10/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.4956 - accuracy: 0.8115
    Epoch 11/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.4679 - accuracy: 0.8224
    Epoch 12/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.4348 - accuracy: 0.8354
    Epoch 13/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.4227 - accuracy: 0.8411
    Epoch 14/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.4062 - accuracy: 0.8463
    Epoch 15/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.3866 - accuracy: 0.8546
    Epoch 16/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.3686 - accuracy: 0.8606
    Epoch 17/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.3499 - accuracy: 0.8654
    Epoch 18/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.3382 - accuracy: 0.8701
    Epoch 19/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.3304 - accuracy: 0.8749
    Epoch 20/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.3275 - accuracy: 0.8751
    Epoch 21/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.3109 - accuracy: 0.8796
    Epoch 22/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.3034 - accuracy: 0.8832
    Epoch 23/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.2917 - accuracy: 0.8889
    Epoch 24/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.2927 - accuracy: 0.8879
    Epoch 25/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.2782 - accuracy: 0.8918
    Epoch 26/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.2846 - accuracy: 0.8922
    Epoch 27/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.2674 - accuracy: 0.8978
    Epoch 28/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.2632 - accuracy: 0.8996
    Epoch 29/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.2583 - accuracy: 0.9016
    Epoch 30/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.2477 - accuracy: 0.9037
    57/57 [==============================] - 1s 15ms/step - loss: 0.2546 - accuracy: 0.9089
    Model: "sequential_26"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_78 (Conv1D)           (None, 88, 512)           5120      
    _________________________________________________________________
    max_pooling1d_26 (MaxPooling (None, 22, 512)           0         
    _________________________________________________________________
    conv1d_79 (Conv1D)           (None, 20, 512)           786944    
    _________________________________________________________________
    average_pooling1d_26 (Averag (None, 10, 512)           0         
    _________________________________________________________________
    conv1d_80 (Conv1D)           (None, 8, 256)            393472    
    _________________________________________________________________
    global_average_pooling1d_26  (None, 256)               0         
    _________________________________________________________________
    dense_78 (Dense)             (None, 256)               65792     
    _________________________________________________________________
    dropout_52 (Dropout)         (None, 256)               0         
    _________________________________________________________________
    dense_79 (Dense)             (None, 512)               131584    
    _________________________________________________________________
    dropout_53 (Dropout)         (None, 512)               0         
    _________________________________________________________________
    dense_80 (Dense)             (None, 6)                 3078      
    =================================================================
    Total params: 1,385,990
    Trainable params: 1,385,990
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 6s 33ms/step - loss: 1.2237 - accuracy: 0.4746
    Epoch 2/30
    171/171 [==============================] - 6s 33ms/step - loss: 1.0460 - accuracy: 0.5606
    Epoch 3/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.9467 - accuracy: 0.6099
    Epoch 4/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.8589 - accuracy: 0.6476
    Epoch 5/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.7753 - accuracy: 0.6833
    Epoch 6/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.7499 - accuracy: 0.7045
    Epoch 7/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.6580 - accuracy: 0.7379
    Epoch 8/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.6059 - accuracy: 0.7635
    Epoch 9/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.5473 - accuracy: 0.7852
    Epoch 10/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.5076 - accuracy: 0.8019
    Epoch 11/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.4786 - accuracy: 0.8155
    Epoch 12/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.4446 - accuracy: 0.8290
    Epoch 13/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.4272 - accuracy: 0.8380
    Epoch 14/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.4005 - accuracy: 0.8472
    Epoch 15/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.3844 - accuracy: 0.8557
    Epoch 16/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.3758 - accuracy: 0.8582
    Epoch 17/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.3564 - accuracy: 0.8638
    Epoch 18/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.3435 - accuracy: 0.8675
    Epoch 19/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.3295 - accuracy: 0.8720
    Epoch 20/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.3203 - accuracy: 0.8771
    Epoch 21/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.3116 - accuracy: 0.8821
    Epoch 22/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.2982 - accuracy: 0.8855
    Epoch 23/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.3002 - accuracy: 0.8864
    Epoch 24/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.2924 - accuracy: 0.8890
    Epoch 25/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.2835 - accuracy: 0.8915
    Epoch 26/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.2842 - accuracy: 0.8924
    Epoch 27/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.2668 - accuracy: 0.8981
    Epoch 28/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.2604 - accuracy: 0.8995
    Epoch 29/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.2582 - accuracy: 0.9018
    Epoch 30/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.2506 - accuracy: 0.9042
    57/57 [==============================] - 1s 12ms/step - loss: 0.2637 - accuracy: 0.9100
    Model: "sequential_27"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_81 (Conv1D)           (None, 88, 512)           5120      
    _________________________________________________________________
    max_pooling1d_27 (MaxPooling (None, 22, 512)           0         
    _________________________________________________________________
    conv1d_82 (Conv1D)           (None, 20, 512)           786944    
    _________________________________________________________________
    average_pooling1d_27 (Averag (None, 10, 512)           0         
    _________________________________________________________________
    conv1d_83 (Conv1D)           (None, 8, 256)            393472    
    _________________________________________________________________
    global_average_pooling1d_27  (None, 256)               0         
    _________________________________________________________________
    dense_81 (Dense)             (None, 256)               65792     
    _________________________________________________________________
    dropout_54 (Dropout)         (None, 256)               0         
    _________________________________________________________________
    dense_82 (Dense)             (None, 512)               131584    
    _________________________________________________________________
    dropout_55 (Dropout)         (None, 512)               0         
    _________________________________________________________________
    dense_83 (Dense)             (None, 6)                 3078      
    =================================================================
    Total params: 1,385,990
    Trainable params: 1,385,990
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 6s 36ms/step - loss: 1.2221 - accuracy: 0.4807
    Epoch 2/30
    171/171 [==============================] - 6s 33ms/step - loss: 1.0230 - accuracy: 0.5747
    Epoch 3/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.9295 - accuracy: 0.6208
    Epoch 4/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.8453 - accuracy: 0.6561
    Epoch 5/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.7688 - accuracy: 0.6922
    Epoch 6/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.7124 - accuracy: 0.7212
    Epoch 7/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.6196 - accuracy: 0.7538 0s - loss: 0.6
    Epoch 8/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.5861 - accuracy: 0.7739
    Epoch 9/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.5267 - accuracy: 0.7988
    Epoch 10/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.4899 - accuracy: 0.8139
    Epoch 11/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.4548 - accuracy: 0.8277
    Epoch 12/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.4365 - accuracy: 0.8361
    Epoch 13/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.4175 - accuracy: 0.8447
    Epoch 14/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.3942 - accuracy: 0.8518
    Epoch 15/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.3799 - accuracy: 0.8588
    Epoch 16/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.3680 - accuracy: 0.8620
    Epoch 17/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.3531 - accuracy: 0.8677
    Epoch 18/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.3334 - accuracy: 0.8740
    Epoch 19/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.3239 - accuracy: 0.8786
    Epoch 20/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.3124 - accuracy: 0.8816
    Epoch 21/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.3143 - accuracy: 0.8802
    Epoch 22/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.3083 - accuracy: 0.8841
    Epoch 23/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.2895 - accuracy: 0.8902
    Epoch 24/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.2861 - accuracy: 0.8920
    Epoch 25/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.2836 - accuracy: 0.8906
    Epoch 26/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.2798 - accuracy: 0.8942
    Epoch 27/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.2643 - accuracy: 0.8983
    Epoch 28/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.2540 - accuracy: 0.9029 1s
    Epoch 29/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.2532 - accuracy: 0.9036
    Epoch 30/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.2433 - accuracy: 0.9068
    57/57 [==============================] - 1s 15ms/step - loss: 0.2596 - accuracy: 0.9071
    Model: "sequential_28"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_84 (Conv1D)           (None, 88, 512)           5120      
    _________________________________________________________________
    max_pooling1d_28 (MaxPooling (None, 22, 512)           0         
    _________________________________________________________________
    conv1d_85 (Conv1D)           (None, 20, 512)           786944    
    _________________________________________________________________
    average_pooling1d_28 (Averag (None, 10, 512)           0         
    _________________________________________________________________
    conv1d_86 (Conv1D)           (None, 8, 256)            393472    
    _________________________________________________________________
    global_average_pooling1d_28  (None, 256)               0         
    _________________________________________________________________
    dense_84 (Dense)             (None, 256)               65792     
    _________________________________________________________________
    dropout_56 (Dropout)         (None, 256)               0         
    _________________________________________________________________
    dense_85 (Dense)             (None, 512)               131584    
    _________________________________________________________________
    dropout_57 (Dropout)         (None, 512)               0         
    _________________________________________________________________
    dense_86 (Dense)             (None, 6)                 3078      
    =================================================================
    Total params: 1,385,990
    Trainable params: 1,385,990
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 6s 33ms/step - loss: 1.2206 - accuracy: 0.4762
    Epoch 2/30
    171/171 [==============================] - 6s 33ms/step - loss: 1.0404 - accuracy: 0.5677
    Epoch 3/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.9429 - accuracy: 0.6154
    Epoch 4/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.8603 - accuracy: 0.6548
    Epoch 5/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.7825 - accuracy: 0.6847
    Epoch 6/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.8216 - accuracy: 0.6941
    Epoch 7/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.6582 - accuracy: 0.7391
    Epoch 8/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.6031 - accuracy: 0.7648
    Epoch 9/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.5567 - accuracy: 0.7827
    Epoch 10/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.5095 - accuracy: 0.7999
    Epoch 11/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.4861 - accuracy: 0.8134
    Epoch 12/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.4533 - accuracy: 0.8260
    Epoch 13/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.4323 - accuracy: 0.8356
    Epoch 14/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.4041 - accuracy: 0.8455
    Epoch 15/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.3994 - accuracy: 0.8503
    Epoch 16/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.3724 - accuracy: 0.8576
    Epoch 17/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.3554 - accuracy: 0.8647
    Epoch 18/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.3533 - accuracy: 0.8677
    Epoch 19/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.3329 - accuracy: 0.8745
    Epoch 20/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.3344 - accuracy: 0.8744
    Epoch 21/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.3133 - accuracy: 0.8811
    Epoch 22/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.3101 - accuracy: 0.8834
    Epoch 23/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.3110 - accuracy: 0.8833
    Epoch 24/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.2971 - accuracy: 0.8866
    Epoch 25/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.2856 - accuracy: 0.8938
    Epoch 26/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.2774 - accuracy: 0.8928
    Epoch 27/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.2699 - accuracy: 0.8971
    Epoch 28/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.2821 - accuracy: 0.8945
    Epoch 29/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.2704 - accuracy: 0.8993
    Epoch 30/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.2566 - accuracy: 0.9036
    57/57 [==============================] - 1s 12ms/step - loss: 0.2515 - accuracy: 0.9082
    Model: "sequential_29"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_87 (Conv1D)           (None, 86, 768)           12288     
    _________________________________________________________________
    max_pooling1d_29 (MaxPooling (None, 43, 768)           0         
    _________________________________________________________________
    conv1d_88 (Conv1D)           (None, 39, 512)           1966592   
    _________________________________________________________________
    average_pooling1d_29 (Averag (None, 19, 512)           0         
    _________________________________________________________________
    conv1d_89 (Conv1D)           (None, 17, 512)           786944    
    _________________________________________________________________
    global_average_pooling1d_29  (None, 512)               0         
    _________________________________________________________________
    dense_87 (Dense)             (None, 512)               262656    
    _________________________________________________________________
    dropout_58 (Dropout)         (None, 512)               0         
    _________________________________________________________________
    dense_88 (Dense)             (None, 512)               262656    
    _________________________________________________________________
    dropout_59 (Dropout)         (None, 512)               0         
    _________________________________________________________________
    dense_89 (Dense)             (None, 6)                 3078      
    =================================================================
    Total params: 3,294,214
    Trainable params: 3,294,214
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 15s 88ms/step - loss: 1.1384 - accuracy: 0.5185
    Epoch 2/30
    171/171 [==============================] - 15s 85ms/step - loss: 0.7755 - accuracy: 0.6788
    Epoch 3/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.5810 - accuracy: 0.7717
    Epoch 4/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.4173 - accuracy: 0.8421
    Epoch 5/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.3534 - accuracy: 0.8657
    Epoch 6/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.3364 - accuracy: 0.8728
    Epoch 7/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.2951 - accuracy: 0.8885
    Epoch 8/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.2647 - accuracy: 0.8997
    Epoch 9/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.2666 - accuracy: 0.9036
    Epoch 10/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.2333 - accuracy: 0.9125
    Epoch 11/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.2409 - accuracy: 0.9143
    Epoch 12/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.2110 - accuracy: 0.9226
    Epoch 13/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1966 - accuracy: 0.9282
    Epoch 14/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1887 - accuracy: 0.9298
    Epoch 15/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1911 - accuracy: 0.9298
    Epoch 16/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1708 - accuracy: 0.9368
    Epoch 17/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.2313 - accuracy: 0.9221
    Epoch 18/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1639 - accuracy: 0.9388
    Epoch 19/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1589 - accuracy: 0.9389
    Epoch 20/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1462 - accuracy: 0.9446
    Epoch 21/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1492 - accuracy: 0.9444
    Epoch 22/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1830 - accuracy: 0.9359
    Epoch 23/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1377 - accuracy: 0.9483
    Epoch 24/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1313 - accuracy: 0.9506
    Epoch 25/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1254 - accuracy: 0.9526
    Epoch 26/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1208 - accuracy: 0.9540
    Epoch 27/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1268 - accuracy: 0.9514
    Epoch 28/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1201 - accuracy: 0.9543
    Epoch 29/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1090 - accuracy: 0.9583
    Epoch 30/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1081 - accuracy: 0.9590
    57/57 [==============================] - 2s 32ms/step - loss: 0.2003 - accuracy: 0.9419
    Model: "sequential_30"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_90 (Conv1D)           (None, 86, 768)           12288     
    _________________________________________________________________
    max_pooling1d_30 (MaxPooling (None, 43, 768)           0         
    _________________________________________________________________
    conv1d_91 (Conv1D)           (None, 39, 512)           1966592   
    _________________________________________________________________
    average_pooling1d_30 (Averag (None, 19, 512)           0         
    _________________________________________________________________
    conv1d_92 (Conv1D)           (None, 17, 512)           786944    
    _________________________________________________________________
    global_average_pooling1d_30  (None, 512)               0         
    _________________________________________________________________
    dense_90 (Dense)             (None, 512)               262656    
    _________________________________________________________________
    dropout_60 (Dropout)         (None, 512)               0         
    _________________________________________________________________
    dense_91 (Dense)             (None, 512)               262656    
    _________________________________________________________________
    dropout_61 (Dropout)         (None, 512)               0         
    _________________________________________________________________
    dense_92 (Dense)             (None, 6)                 3078      
    =================================================================
    Total params: 3,294,214
    Trainable params: 3,294,214
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 15s 85ms/step - loss: 1.1392 - accuracy: 0.5149
    Epoch 2/30
    171/171 [==============================] - 14s 85ms/step - loss: 0.7798 - accuracy: 0.6758
    Epoch 3/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.5479 - accuracy: 0.7907
    Epoch 4/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.4797 - accuracy: 0.8236
    Epoch 5/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.3481 - accuracy: 0.8674
    Epoch 6/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.3352 - accuracy: 0.8747
    Epoch 7/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.2810 - accuracy: 0.8924
    Epoch 8/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.2689 - accuracy: 0.9003
    Epoch 9/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.2636 - accuracy: 0.9015
    Epoch 10/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.2296 - accuracy: 0.9145
    Epoch 11/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.2242 - accuracy: 0.9164
    Epoch 12/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.2226 - accuracy: 0.9179
    Epoch 13/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1961 - accuracy: 0.9266
    Epoch 14/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1887 - accuracy: 0.9287
    Epoch 15/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.2237 - accuracy: 0.9214
    Epoch 16/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1872 - accuracy: 0.9305
    Epoch 17/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1769 - accuracy: 0.9341
    Epoch 18/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1649 - accuracy: 0.9374
    Epoch 19/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1582 - accuracy: 0.9395
    Epoch 20/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1468 - accuracy: 0.9444
    Epoch 21/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1573 - accuracy: 0.9425
    Epoch 22/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1435 - accuracy: 0.9460
    Epoch 23/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1331 - accuracy: 0.9495
    Epoch 24/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1317 - accuracy: 0.9505
    Epoch 25/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1307 - accuracy: 0.9504
    Epoch 26/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1350 - accuracy: 0.9505
    Epoch 27/30
    171/171 [==============================] - 14s 85ms/step - loss: 0.1210 - accuracy: 0.9538
    Epoch 28/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1271 - accuracy: 0.9530
    Epoch 29/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1268 - accuracy: 0.9528
    Epoch 30/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1131 - accuracy: 0.9564
    57/57 [==============================] - 2s 28ms/step - loss: 0.2596 - accuracy: 0.9336
    Model: "sequential_31"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_93 (Conv1D)           (None, 86, 768)           12288     
    _________________________________________________________________
    max_pooling1d_31 (MaxPooling (None, 43, 768)           0         
    _________________________________________________________________
    conv1d_94 (Conv1D)           (None, 39, 512)           1966592   
    _________________________________________________________________
    average_pooling1d_31 (Averag (None, 19, 512)           0         
    _________________________________________________________________
    conv1d_95 (Conv1D)           (None, 17, 512)           786944    
    _________________________________________________________________
    global_average_pooling1d_31  (None, 512)               0         
    _________________________________________________________________
    dense_93 (Dense)             (None, 512)               262656    
    _________________________________________________________________
    dropout_62 (Dropout)         (None, 512)               0         
    _________________________________________________________________
    dense_94 (Dense)             (None, 512)               262656    
    _________________________________________________________________
    dropout_63 (Dropout)         (None, 512)               0         
    _________________________________________________________________
    dense_95 (Dense)             (None, 6)                 3078      
    =================================================================
    Total params: 3,294,214
    Trainable params: 3,294,214
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 15s 88ms/step - loss: 1.1470 - accuracy: 0.5167
    Epoch 2/30
    171/171 [==============================] - 14s 85ms/step - loss: 0.7868 - accuracy: 0.6727
    Epoch 3/30
    171/171 [==============================] - 14s 85ms/step - loss: 0.5690 - accuracy: 0.7771
    Epoch 4/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.4281 - accuracy: 0.8413
    Epoch 5/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.3560 - accuracy: 0.8639
    Epoch 6/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.3660 - accuracy: 0.8643
    Epoch 7/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.2913 - accuracy: 0.8888
    Epoch 8/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.2714 - accuracy: 0.8971
    Epoch 9/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.2529 - accuracy: 0.9046
    Epoch 10/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.2344 - accuracy: 0.9113
    Epoch 11/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.2218 - accuracy: 0.9174
    Epoch 12/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.2114 - accuracy: 0.9197
    Epoch 13/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.2211 - accuracy: 0.9190
    Epoch 14/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1921 - accuracy: 0.9277
    Epoch 15/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1813 - accuracy: 0.9323
    Epoch 16/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1764 - accuracy: 0.9336
    Epoch 17/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1721 - accuracy: 0.9350
    Epoch 18/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1597 - accuracy: 0.9403
    Epoch 19/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1634 - accuracy: 0.9398
    Epoch 20/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1461 - accuracy: 0.9449
    Epoch 21/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1423 - accuracy: 0.9460
    Epoch 22/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1504 - accuracy: 0.9445
    Epoch 23/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1343 - accuracy: 0.9491
    Epoch 24/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1295 - accuracy: 0.9513
    Epoch 25/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1277 - accuracy: 0.95181s - los
    Epoch 26/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1418 - accuracy: 0.9485
    Epoch 27/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1237 - accuracy: 0.9534
    Epoch 28/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1245 - accuracy: 0.95391s -
    Epoch 29/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1123 - accuracy: 0.9578
    Epoch 30/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1064 - accuracy: 0.9596
    57/57 [==============================] - 2s 30ms/step - loss: 0.2163 - accuracy: 0.9369
    Model: "sequential_32"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_96 (Conv1D)           (None, 86, 768)           12288     
    _________________________________________________________________
    max_pooling1d_32 (MaxPooling (None, 43, 768)           0         
    _________________________________________________________________
    conv1d_97 (Conv1D)           (None, 39, 512)           1966592   
    _________________________________________________________________
    average_pooling1d_32 (Averag (None, 19, 512)           0         
    _________________________________________________________________
    conv1d_98 (Conv1D)           (None, 17, 512)           786944    
    _________________________________________________________________
    global_average_pooling1d_32  (None, 512)               0         
    _________________________________________________________________
    dense_96 (Dense)             (None, 512)               262656    
    _________________________________________________________________
    dropout_64 (Dropout)         (None, 512)               0         
    _________________________________________________________________
    dense_97 (Dense)             (None, 512)               262656    
    _________________________________________________________________
    dropout_65 (Dropout)         (None, 512)               0         
    _________________________________________________________________
    dense_98 (Dense)             (None, 6)                 3078      
    =================================================================
    Total params: 3,294,214
    Trainable params: 3,294,214
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 15s 85ms/step - loss: 1.1419 - accuracy: 0.5200
    Epoch 2/30
    171/171 [==============================] - 14s 85ms/step - loss: 0.8046 - accuracy: 0.6633
    Epoch 3/30
    171/171 [==============================] - 14s 85ms/step - loss: 0.5861 - accuracy: 0.7680
    Epoch 4/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.4348 - accuracy: 0.8354
    Epoch 5/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.3848 - accuracy: 0.8561
    Epoch 6/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.3300 - accuracy: 0.8771
    Epoch 7/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.2948 - accuracy: 0.8898
    Epoch 8/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.2828 - accuracy: 0.8965
    Epoch 9/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.2746 - accuracy: 0.9003
    Epoch 10/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.2421 - accuracy: 0.9102
    Epoch 11/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.2289 - accuracy: 0.9144
    Epoch 12/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.2498 - accuracy: 0.9120
    Epoch 13/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.2039 - accuracy: 0.9257
    Epoch 14/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1937 - accuracy: 0.9284
    Epoch 15/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1885 - accuracy: 0.9304
    Epoch 16/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1772 - accuracy: 0.9338
    Epoch 17/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1687 - accuracy: 0.9373
    Epoch 18/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1657 - accuracy: 0.9396
    Epoch 19/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1632 - accuracy: 0.9396
    Epoch 20/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1567 - accuracy: 0.9411
    Epoch 21/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.2028 - accuracy: 0.9285
    Epoch 22/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1769 - accuracy: 0.9370
    Epoch 23/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1428 - accuracy: 0.9471
    Epoch 24/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1397 - accuracy: 0.9485
    Epoch 25/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1323 - accuracy: 0.9510
    Epoch 26/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1264 - accuracy: 0.9516
    Epoch 27/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1269 - accuracy: 0.9531
    Epoch 28/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1202 - accuracy: 0.9538
    Epoch 29/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1151 - accuracy: 0.9563
    Epoch 30/30
    171/171 [==============================] - 14s 84ms/step - loss: 0.1194 - accuracy: 0.9558
    57/57 [==============================] - 2s 28ms/step - loss: 0.1904 - accuracy: 0.9416
    Model: "sequential_33"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_99 (Conv1D)           (None, 86, 768)           12288     
    _________________________________________________________________
    max_pooling1d_33 (MaxPooling (None, 43, 768)           0         
    _________________________________________________________________
    conv1d_100 (Conv1D)          (None, 41, 256)           590080    
    _________________________________________________________________
    average_pooling1d_33 (Averag (None, 20, 256)           0         
    _________________________________________________________________
    conv1d_101 (Conv1D)          (None, 18, 512)           393728    
    _________________________________________________________________
    global_average_pooling1d_33  (None, 512)               0         
    _________________________________________________________________
    dense_99 (Dense)             (None, 256)               131328    
    _________________________________________________________________
    dropout_66 (Dropout)         (None, 256)               0         
    _________________________________________________________________
    dense_100 (Dense)            (None, 256)               65792     
    _________________________________________________________________
    dropout_67 (Dropout)         (None, 256)               0         
    _________________________________________________________________
    dense_101 (Dense)            (None, 6)                 1542      
    =================================================================
    Total params: 1,194,758
    Trainable params: 1,194,758
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 9s 51ms/step - loss: 1.1341 - accuracy: 0.5179
    Epoch 2/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.8263 - accuracy: 0.6523
    Epoch 3/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.5940 - accuracy: 0.7624
    Epoch 4/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.4369 - accuracy: 0.8339
    Epoch 5/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.3785 - accuracy: 0.8586
    Epoch 6/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.3409 - accuracy: 0.8740
    Epoch 7/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.3039 - accuracy: 0.8854
    Epoch 8/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.2875 - accuracy: 0.8917
    Epoch 9/30
    171/171 [==============================] - 8s 48ms/step - loss: 0.2701 - accuracy: 0.8990
    Epoch 10/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.2537 - accuracy: 0.9051
    Epoch 11/30
    171/171 [==============================] - 8s 48ms/step - loss: 0.2817 - accuracy: 0.8994
    Epoch 12/30
    171/171 [==============================] - 8s 48ms/step - loss: 0.2298 - accuracy: 0.9146
    Epoch 13/30
    171/171 [==============================] - 8s 48ms/step - loss: 0.2138 - accuracy: 0.9202
    Epoch 14/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.2025 - accuracy: 0.9246
    Epoch 15/30
    171/171 [==============================] - 8s 48ms/step - loss: 0.2293 - accuracy: 0.9178
    Epoch 16/30
    171/171 [==============================] - 8s 48ms/step - loss: 0.1961 - accuracy: 0.9292
    Epoch 17/30
    171/171 [==============================] - 8s 48ms/step - loss: 0.1854 - accuracy: 0.9311
    Epoch 18/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.1761 - accuracy: 0.9351
    Epoch 19/30
    171/171 [==============================] - 8s 48ms/step - loss: 0.1761 - accuracy: 0.9354
    Epoch 20/30
    171/171 [==============================] - 8s 48ms/step - loss: 0.1937 - accuracy: 0.9327
    Epoch 21/30
    171/171 [==============================] - 8s 48ms/step - loss: 0.1593 - accuracy: 0.9404
    Epoch 22/30
    171/171 [==============================] - 8s 48ms/step - loss: 0.1579 - accuracy: 0.9413
    Epoch 23/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.1495 - accuracy: 0.9440
    Epoch 24/30
    171/171 [==============================] - 8s 48ms/step - loss: 0.1531 - accuracy: 0.9450
    Epoch 25/30
    171/171 [==============================] - 8s 48ms/step - loss: 0.1467 - accuracy: 0.9464
    Epoch 26/30
    171/171 [==============================] - 8s 48ms/step - loss: 0.1370 - accuracy: 0.9482
    Epoch 27/30
    171/171 [==============================] - 8s 48ms/step - loss: 0.1318 - accuracy: 0.9508
    Epoch 28/30
    171/171 [==============================] - 8s 48ms/step - loss: 0.1323 - accuracy: 0.9505
    Epoch 29/30
    171/171 [==============================] - 8s 48ms/step - loss: 0.1295 - accuracy: 0.9512
    Epoch 30/30
    171/171 [==============================] - 8s 48ms/step - loss: 0.1326 - accuracy: 0.9507
    57/57 [==============================] - 1s 20ms/step - loss: 0.1974 - accuracy: 0.9336
    Model: "sequential_34"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_102 (Conv1D)          (None, 86, 768)           12288     
    _________________________________________________________________
    max_pooling1d_34 (MaxPooling (None, 43, 768)           0         
    _________________________________________________________________
    conv1d_103 (Conv1D)          (None, 41, 256)           590080    
    _________________________________________________________________
    average_pooling1d_34 (Averag (None, 20, 256)           0         
    _________________________________________________________________
    conv1d_104 (Conv1D)          (None, 18, 512)           393728    
    _________________________________________________________________
    global_average_pooling1d_34  (None, 512)               0         
    _________________________________________________________________
    dense_102 (Dense)            (None, 256)               131328    
    _________________________________________________________________
    dropout_68 (Dropout)         (None, 256)               0         
    _________________________________________________________________
    dense_103 (Dense)            (None, 256)               65792     
    _________________________________________________________________
    dropout_69 (Dropout)         (None, 256)               0         
    _________________________________________________________________
    dense_104 (Dense)            (None, 6)                 1542      
    =================================================================
    Total params: 1,194,758
    Trainable params: 1,194,758
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 8s 49ms/step - loss: 1.1243 - accuracy: 0.5255
    Epoch 2/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.8243 - accuracy: 0.6553
    Epoch 3/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.5991 - accuracy: 0.7638
    Epoch 4/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.4532 - accuracy: 0.8290
    Epoch 5/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.3686 - accuracy: 0.8620
    Epoch 6/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.3483 - accuracy: 0.8689
    Epoch 7/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.3004 - accuracy: 0.8880
    Epoch 8/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.3306 - accuracy: 0.8778
    Epoch 9/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.2654 - accuracy: 0.8997
    Epoch 10/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.2564 - accuracy: 0.9034
    Epoch 11/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.2473 - accuracy: 0.9073
    Epoch 12/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.2288 - accuracy: 0.9149
    Epoch 13/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.2180 - accuracy: 0.9181
    Epoch 14/30
    171/171 [==============================] - 8s 48ms/step - loss: 0.2278 - accuracy: 0.9175
    Epoch 15/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.2068 - accuracy: 0.9250
    Epoch 16/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.1896 - accuracy: 0.9305
    Epoch 17/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.1851 - accuracy: 0.9310
    Epoch 18/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.2018 - accuracy: 0.9301
    Epoch 19/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.1745 - accuracy: 0.9354
    Epoch 20/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.1746 - accuracy: 0.9373
    Epoch 21/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.1582 - accuracy: 0.9414
    Epoch 22/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.1547 - accuracy: 0.9428
    Epoch 23/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.1563 - accuracy: 0.9428
    Epoch 24/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.1482 - accuracy: 0.9438
    Epoch 25/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.1557 - accuracy: 0.9428
    Epoch 26/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.1418 - accuracy: 0.9465
    Epoch 27/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.1365 - accuracy: 0.9495
    Epoch 28/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.1472 - accuracy: 0.9466
    Epoch 29/30
    171/171 [==============================] - 8s 48ms/step - loss: 0.1288 - accuracy: 0.9513
    Epoch 30/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.1255 - accuracy: 0.9536
    57/57 [==============================] - 1s 17ms/step - loss: 0.2122 - accuracy: 0.9311
    Model: "sequential_35"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_105 (Conv1D)          (None, 86, 768)           12288     
    _________________________________________________________________
    max_pooling1d_35 (MaxPooling (None, 43, 768)           0         
    _________________________________________________________________
    conv1d_106 (Conv1D)          (None, 41, 256)           590080    
    _________________________________________________________________
    average_pooling1d_35 (Averag (None, 20, 256)           0         
    _________________________________________________________________
    conv1d_107 (Conv1D)          (None, 18, 512)           393728    
    _________________________________________________________________
    global_average_pooling1d_35  (None, 512)               0         
    _________________________________________________________________
    dense_105 (Dense)            (None, 256)               131328    
    _________________________________________________________________
    dropout_70 (Dropout)         (None, 256)               0         
    _________________________________________________________________
    dense_106 (Dense)            (None, 256)               65792     
    _________________________________________________________________
    dropout_71 (Dropout)         (None, 256)               0         
    _________________________________________________________________
    dense_107 (Dense)            (None, 6)                 1542      
    =================================================================
    Total params: 1,194,758
    Trainable params: 1,194,758
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 9s 51ms/step - loss: 1.1370 - accuracy: 0.5214
    Epoch 2/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.8231 - accuracy: 0.6612
    Epoch 3/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.6159 - accuracy: 0.7586
    Epoch 4/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.4542 - accuracy: 0.8320
    Epoch 5/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.3775 - accuracy: 0.8579
    Epoch 6/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.3629 - accuracy: 0.8694
    Epoch 7/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.3181 - accuracy: 0.8826
    Epoch 8/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.2940 - accuracy: 0.8900
    Epoch 9/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.2693 - accuracy: 0.8983
    Epoch 10/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.2523 - accuracy: 0.9054
    Epoch 11/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.3304 - accuracy: 0.8835
    Epoch 12/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.2413 - accuracy: 0.9102
    Epoch 13/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.2211 - accuracy: 0.9196
    Epoch 14/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.2079 - accuracy: 0.9256
    Epoch 15/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.2000 - accuracy: 0.9272
    Epoch 16/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.1974 - accuracy: 0.9277
    Epoch 17/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.1839 - accuracy: 0.9330
    Epoch 18/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.2049 - accuracy: 0.9266
    Epoch 19/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.2150 - accuracy: 0.9264
    Epoch 20/30
    171/171 [==============================] - 8s 48ms/step - loss: 0.1726 - accuracy: 0.9374
    Epoch 21/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.1638 - accuracy: 0.9394
    Epoch 22/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.1571 - accuracy: 0.9417
    Epoch 23/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.1543 - accuracy: 0.9436
    Epoch 24/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.1479 - accuracy: 0.9458
    Epoch 25/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.1440 - accuracy: 0.9466
    Epoch 26/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.1431 - accuracy: 0.9459
    Epoch 27/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.1371 - accuracy: 0.9494
    Epoch 28/30
    171/171 [==============================] - 8s 48ms/step - loss: 0.1420 - accuracy: 0.9484
    Epoch 29/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.1319 - accuracy: 0.9505
    Epoch 30/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.1249 - accuracy: 0.9532
    57/57 [==============================] - 1s 20ms/step - loss: 0.2255 - accuracy: 0.9294
    Model: "sequential_36"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_108 (Conv1D)          (None, 86, 768)           12288     
    _________________________________________________________________
    max_pooling1d_36 (MaxPooling (None, 43, 768)           0         
    _________________________________________________________________
    conv1d_109 (Conv1D)          (None, 41, 256)           590080    
    _________________________________________________________________
    average_pooling1d_36 (Averag (None, 20, 256)           0         
    _________________________________________________________________
    conv1d_110 (Conv1D)          (None, 18, 512)           393728    
    _________________________________________________________________
    global_average_pooling1d_36  (None, 512)               0         
    _________________________________________________________________
    dense_108 (Dense)            (None, 256)               131328    
    _________________________________________________________________
    dropout_72 (Dropout)         (None, 256)               0         
    _________________________________________________________________
    dense_109 (Dense)            (None, 256)               65792     
    _________________________________________________________________
    dropout_73 (Dropout)         (None, 256)               0         
    _________________________________________________________________
    dense_110 (Dense)            (None, 6)                 1542      
    =================================================================
    Total params: 1,194,758
    Trainable params: 1,194,758
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 8s 49ms/step - loss: 1.1345 - accuracy: 0.5198
    Epoch 2/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.8374 - accuracy: 0.6523
    Epoch 3/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.6219 - accuracy: 0.7580
    Epoch 4/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.4599 - accuracy: 0.8230
    Epoch 5/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.3842 - accuracy: 0.8553
    Epoch 6/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.3560 - accuracy: 0.8670
    Epoch 7/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.3120 - accuracy: 0.8821
    Epoch 8/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.2906 - accuracy: 0.8911
    Epoch 9/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.2776 - accuracy: 0.8965
    Epoch 10/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.3147 - accuracy: 0.8884
    Epoch 11/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.2538 - accuracy: 0.9062
    Epoch 12/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.2394 - accuracy: 0.9107
    Epoch 13/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.2325 - accuracy: 0.9136
    Epoch 14/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.2235 - accuracy: 0.9173
    Epoch 15/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.2111 - accuracy: 0.9207
    Epoch 16/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.2110 - accuracy: 0.9230
    Epoch 17/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.1907 - accuracy: 0.9296
    Epoch 18/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.1825 - accuracy: 0.9318
    Epoch 19/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.2560 - accuracy: 0.9154
    Epoch 20/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.1783 - accuracy: 0.9353
    Epoch 21/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.1760 - accuracy: 0.9358
    Epoch 22/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.1655 - accuracy: 0.9394
    Epoch 23/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.1575 - accuracy: 0.9404
    Epoch 24/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.1545 - accuracy: 0.9428
    Epoch 25/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.1469 - accuracy: 0.9459
    Epoch 26/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.1496 - accuracy: 0.9438
    Epoch 27/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.1408 - accuracy: 0.9470
    Epoch 28/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.1408 - accuracy: 0.9486
    Epoch 29/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.1348 - accuracy: 0.9493
    Epoch 30/30
    171/171 [==============================] - 8s 49ms/step - loss: 0.1316 - accuracy: 0.9502
    57/57 [==============================] - 1s 18ms/step - loss: 0.2006 - accuracy: 0.9346
    Model: "sequential_37"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_111 (Conv1D)          (None, 86, 256)           4096      
    _________________________________________________________________
    max_pooling1d_37 (MaxPooling (None, 21, 256)           0         
    _________________________________________________________________
    conv1d_112 (Conv1D)          (None, 17, 768)           983808    
    _________________________________________________________________
    average_pooling1d_37 (Averag (None, 8, 768)            0         
    _________________________________________________________________
    conv1d_113 (Conv1D)          (None, 4, 768)            2949888   
    _________________________________________________________________
    global_average_pooling1d_37  (None, 768)               0         
    _________________________________________________________________
    dense_111 (Dense)            (None, 256)               196864    
    _________________________________________________________________
    dropout_74 (Dropout)         (None, 256)               0         
    _________________________________________________________________
    dense_112 (Dense)            (None, 512)               131584    
    _________________________________________________________________
    dropout_75 (Dropout)         (None, 512)               0         
    _________________________________________________________________
    dense_113 (Dense)            (None, 6)                 3078      
    =================================================================
    Total params: 4,269,318
    Trainable params: 4,269,318
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 8s 48ms/step - loss: 1.1493 - accuracy: 0.5121
    Epoch 2/30
    171/171 [==============================] - 8s 44ms/step - loss: 0.7982 - accuracy: 0.6761
    Epoch 3/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.5369 - accuracy: 0.7942
    Epoch 4/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.4435 - accuracy: 0.8353
    Epoch 5/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.3591 - accuracy: 0.8651
    Epoch 6/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.3152 - accuracy: 0.8806
    Epoch 7/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.3376 - accuracy: 0.8758
    Epoch 8/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.2867 - accuracy: 0.8943
    Epoch 9/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.2584 - accuracy: 0.9024
    Epoch 10/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.2597 - accuracy: 0.9045
    Epoch 11/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.2384 - accuracy: 0.9111
    Epoch 12/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.2262 - accuracy: 0.9151
    Epoch 13/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.2471 - accuracy: 0.9121
    Epoch 14/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.2096 - accuracy: 0.9219
    Epoch 15/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1923 - accuracy: 0.9291
    Epoch 16/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.2136 - accuracy: 0.9237
    Epoch 17/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1796 - accuracy: 0.9318
    Epoch 18/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1710 - accuracy: 0.9349
    Epoch 19/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.1617 - accuracy: 0.9393
    Epoch 20/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1638 - accuracy: 0.9389
    Epoch 21/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1518 - accuracy: 0.9421
    Epoch 22/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1508 - accuracy: 0.9441
    Epoch 23/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1446 - accuracy: 0.9454
    Epoch 24/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1404 - accuracy: 0.9476
    Epoch 25/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1316 - accuracy: 0.9497
    Epoch 26/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1436 - accuracy: 0.9484
    Epoch 27/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1224 - accuracy: 0.9527
    Epoch 28/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1252 - accuracy: 0.9532
    Epoch 29/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1202 - accuracy: 0.9556
    Epoch 30/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1228 - accuracy: 0.9531
    57/57 [==============================] - 1s 16ms/step - loss: 0.2934 - accuracy: 0.9173
    Model: "sequential_38"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_114 (Conv1D)          (None, 86, 256)           4096      
    _________________________________________________________________
    max_pooling1d_38 (MaxPooling (None, 21, 256)           0         
    _________________________________________________________________
    conv1d_115 (Conv1D)          (None, 17, 768)           983808    
    _________________________________________________________________
    average_pooling1d_38 (Averag (None, 8, 768)            0         
    _________________________________________________________________
    conv1d_116 (Conv1D)          (None, 4, 768)            2949888   
    _________________________________________________________________
    global_average_pooling1d_38  (None, 768)               0         
    _________________________________________________________________
    dense_114 (Dense)            (None, 256)               196864    
    _________________________________________________________________
    dropout_76 (Dropout)         (None, 256)               0         
    _________________________________________________________________
    dense_115 (Dense)            (None, 512)               131584    
    _________________________________________________________________
    dropout_77 (Dropout)         (None, 512)               0         
    _________________________________________________________________
    dense_116 (Dense)            (None, 6)                 3078      
    =================================================================
    Total params: 4,269,318
    Trainable params: 4,269,318
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
      1/171 [..............................] - ETA: 5s - loss: 1.7952 - accuracy: 0.1602WARNING:tensorflow:Callbacks method `on_train_batch_end` is slow compared to the batch time (batch time: 0.0150s vs `on_train_batch_end` time: 0.0339s). Check your callbacks.
    171/171 [==============================] - 8s 44ms/step - loss: 1.1429 - accuracy: 0.5152
    Epoch 2/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.7785 - accuracy: 0.6872
    Epoch 3/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.5335 - accuracy: 0.7994
    Epoch 4/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.4121 - accuracy: 0.8471
    Epoch 5/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.3610 - accuracy: 0.8674
    Epoch 6/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.3187 - accuracy: 0.8803
    Epoch 7/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.3034 - accuracy: 0.8858
    Epoch 8/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.2840 - accuracy: 0.8955
    Epoch 9/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.2814 - accuracy: 0.8990
    Epoch 10/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.2543 - accuracy: 0.9075
    Epoch 11/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.2279 - accuracy: 0.9148
    Epoch 12/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.2489 - accuracy: 0.9127
    Epoch 13/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.2166 - accuracy: 0.9204
    Epoch 14/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1983 - accuracy: 0.9277
    Epoch 15/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1927 - accuracy: 0.9292
    Epoch 16/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1776 - accuracy: 0.9347
    Epoch 17/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1697 - accuracy: 0.9355
    Epoch 18/30
    171/171 [==============================] - 7s 43ms/step - loss: 0.1909 - accuracy: 0.9319
    Epoch 19/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1609 - accuracy: 0.9399
    Epoch 20/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1571 - accuracy: 0.9415
    Epoch 21/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1495 - accuracy: 0.9440
    Epoch 22/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1407 - accuracy: 0.9458
    Epoch 23/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1387 - accuracy: 0.9474
    Epoch 24/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1326 - accuracy: 0.9496
    Epoch 25/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1411 - accuracy: 0.9486
    Epoch 26/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1241 - accuracy: 0.9533
    Epoch 27/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1209 - accuracy: 0.9544
    Epoch 28/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1138 - accuracy: 0.9570
    Epoch 29/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1220 - accuracy: 0.9552
    Epoch 30/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1165 - accuracy: 0.9571
    57/57 [==============================] - 1s 12ms/step - loss: 0.2502 - accuracy: 0.9285
    Model: "sequential_39"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_117 (Conv1D)          (None, 86, 256)           4096      
    _________________________________________________________________
    max_pooling1d_39 (MaxPooling (None, 21, 256)           0         
    _________________________________________________________________
    conv1d_118 (Conv1D)          (None, 17, 768)           983808    
    _________________________________________________________________
    average_pooling1d_39 (Averag (None, 8, 768)            0         
    _________________________________________________________________
    conv1d_119 (Conv1D)          (None, 4, 768)            2949888   
    _________________________________________________________________
    global_average_pooling1d_39  (None, 768)               0         
    _________________________________________________________________
    dense_117 (Dense)            (None, 256)               196864    
    _________________________________________________________________
    dropout_78 (Dropout)         (None, 256)               0         
    _________________________________________________________________
    dense_118 (Dense)            (None, 512)               131584    
    _________________________________________________________________
    dropout_79 (Dropout)         (None, 512)               0         
    _________________________________________________________________
    dense_119 (Dense)            (None, 6)                 3078      
    =================================================================
    Total params: 4,269,318
    Trainable params: 4,269,318
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 8s 48ms/step - loss: 1.1305 - accuracy: 0.5206
    Epoch 2/30
    171/171 [==============================] - 8s 44ms/step - loss: 0.7624 - accuracy: 0.6968
    Epoch 3/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.5179 - accuracy: 0.8070
    Epoch 4/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.4037 - accuracy: 0.8498
    Epoch 5/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.3688 - accuracy: 0.8620
    Epoch 6/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.3154 - accuracy: 0.8803
    Epoch 7/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.3095 - accuracy: 0.8847
    Epoch 8/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.2943 - accuracy: 0.8935
    Epoch 9/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.2935 - accuracy: 0.8928
    Epoch 10/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.2422 - accuracy: 0.9098
    Epoch 11/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.2467 - accuracy: 0.9110
    Epoch 12/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.2162 - accuracy: 0.9200
    Epoch 13/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.2045 - accuracy: 0.9231
    Epoch 14/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1933 - accuracy: 0.9280
    Epoch 15/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1855 - accuracy: 0.9311
    Epoch 16/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1861 - accuracy: 0.9318
    Epoch 17/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1691 - accuracy: 0.9371
    Epoch 18/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1655 - accuracy: 0.9381
    Epoch 19/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1571 - accuracy: 0.9415
    Epoch 20/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1676 - accuracy: 0.9395
    Epoch 21/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1480 - accuracy: 0.9441
    Epoch 22/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1410 - accuracy: 0.9461
    Epoch 23/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1412 - accuracy: 0.9472
    Epoch 24/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1337 - accuracy: 0.9501
    Epoch 25/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1288 - accuracy: 0.9510
    Epoch 26/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1227 - accuracy: 0.9535
    Epoch 27/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1589 - accuracy: 0.9481
    Epoch 28/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1246 - accuracy: 0.9540
    Epoch 29/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1169 - accuracy: 0.9559
    Epoch 30/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1163 - accuracy: 0.9559
    57/57 [==============================] - 1s 16ms/step - loss: 0.3088 - accuracy: 0.9211
    Model: "sequential_40"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_120 (Conv1D)          (None, 86, 256)           4096      
    _________________________________________________________________
    max_pooling1d_40 (MaxPooling (None, 21, 256)           0         
    _________________________________________________________________
    conv1d_121 (Conv1D)          (None, 17, 768)           983808    
    _________________________________________________________________
    average_pooling1d_40 (Averag (None, 8, 768)            0         
    _________________________________________________________________
    conv1d_122 (Conv1D)          (None, 4, 768)            2949888   
    _________________________________________________________________
    global_average_pooling1d_40  (None, 768)               0         
    _________________________________________________________________
    dense_120 (Dense)            (None, 256)               196864    
    _________________________________________________________________
    dropout_80 (Dropout)         (None, 256)               0         
    _________________________________________________________________
    dense_121 (Dense)            (None, 512)               131584    
    _________________________________________________________________
    dropout_81 (Dropout)         (None, 512)               0         
    _________________________________________________________________
    dense_122 (Dense)            (None, 6)                 3078      
    =================================================================
    Total params: 4,269,318
    Trainable params: 4,269,318
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 8s 44ms/step - loss: 1.1248 - accuracy: 0.5190
    Epoch 2/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.7684 - accuracy: 0.6884
    Epoch 3/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.5072 - accuracy: 0.8050
    Epoch 4/30
    171/171 [==============================] - 8s 44ms/step - loss: 0.4255 - accuracy: 0.8409
    Epoch 5/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.3482 - accuracy: 0.8695
    Epoch 6/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.3428 - accuracy: 0.8748
    Epoch 7/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.2857 - accuracy: 0.8952
    Epoch 8/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.2808 - accuracy: 0.8954
    Epoch 9/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.2617 - accuracy: 0.9023
    Epoch 10/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.2413 - accuracy: 0.9097
    Epoch 11/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.2262 - accuracy: 0.9155
    Epoch 12/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.2119 - accuracy: 0.9207
    Epoch 13/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.3695 - accuracy: 0.8726
    Epoch 14/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.2312 - accuracy: 0.9179
    Epoch 15/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.2041 - accuracy: 0.9264
    Epoch 16/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1841 - accuracy: 0.9306
    Epoch 17/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1772 - accuracy: 0.9344
    Epoch 18/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1737 - accuracy: 0.9362
    Epoch 19/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1619 - accuracy: 0.9396
    Epoch 20/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1649 - accuracy: 0.9412
    Epoch 21/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1499 - accuracy: 0.9447
    Epoch 22/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1390 - accuracy: 0.9476
    Epoch 23/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1374 - accuracy: 0.9482
    Epoch 24/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1339 - accuracy: 0.9493
    Epoch 25/30
    171/171 [==============================] - 8s 44ms/step - loss: 0.1345 - accuracy: 0.9500
    Epoch 26/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1272 - accuracy: 0.9524
    Epoch 27/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1194 - accuracy: 0.9558
    Epoch 28/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1194 - accuracy: 0.9542
    Epoch 29/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1253 - accuracy: 0.9534
    Epoch 30/30
    171/171 [==============================] - 7s 44ms/step - loss: 0.1184 - accuracy: 0.9555
    57/57 [==============================] - 1s 12ms/step - loss: 0.2505 - accuracy: 0.9346
    Model: "sequential_41"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_123 (Conv1D)          (None, 86, 768)           12288     
    _________________________________________________________________
    max_pooling1d_41 (MaxPooling (None, 43, 768)           0         
    _________________________________________________________________
    conv1d_124 (Conv1D)          (None, 41, 512)           1180160   
    _________________________________________________________________
    average_pooling1d_41 (Averag (None, 20, 512)           0         
    _________________________________________________________________
    conv1d_125 (Conv1D)          (None, 18, 256)           393472    
    _________________________________________________________________
    global_average_pooling1d_41  (None, 256)               0         
    _________________________________________________________________
    dense_123 (Dense)            (None, 256)               65792     
    _________________________________________________________________
    dropout_82 (Dropout)         (None, 256)               0         
    _________________________________________________________________
    dense_124 (Dense)            (None, 256)               65792     
    _________________________________________________________________
    dropout_83 (Dropout)         (None, 256)               0         
    _________________________________________________________________
    dense_125 (Dense)            (None, 6)                 1542      
    =================================================================
    Total params: 1,719,046
    Trainable params: 1,719,046
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 12s 69ms/step - loss: 1.1422 - accuracy: 0.5173
    Epoch 2/30
    171/171 [==============================] - 11s 67ms/step - loss: 0.8262 - accuracy: 0.6510
    Epoch 3/30
    171/171 [==============================] - 11s 67ms/step - loss: 0.6315 - accuracy: 0.7472
    Epoch 4/30
    171/171 [==============================] - 11s 67ms/step - loss: 0.4717 - accuracy: 0.8242
    Epoch 5/30
    171/171 [==============================] - 11s 67ms/step - loss: 0.3868 - accuracy: 0.8546
    Epoch 6/30
    171/171 [==============================] - 11s 67ms/step - loss: 0.3623 - accuracy: 0.8657
    Epoch 7/30
    171/171 [==============================] - 11s 67ms/step - loss: 0.3143 - accuracy: 0.8820
    Epoch 8/30
    171/171 [==============================] - 11s 67ms/step - loss: 0.2936 - accuracy: 0.8891
    Epoch 9/30
    171/171 [==============================] - 11s 67ms/step - loss: 0.2945 - accuracy: 0.8904
    Epoch 10/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.2622 - accuracy: 0.9034
    Epoch 11/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.2452 - accuracy: 0.9086
    Epoch 12/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.2368 - accuracy: 0.9123
    Epoch 13/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.2203 - accuracy: 0.9174
    Epoch 14/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.2593 - accuracy: 0.9099
    Epoch 15/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.2088 - accuracy: 0.9239
    Epoch 16/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.2003 - accuracy: 0.9280
    Epoch 17/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.3038 - accuracy: 0.8983
    Epoch 18/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.1922 - accuracy: 0.9302
    Epoch 19/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.1850 - accuracy: 0.9324
    Epoch 20/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.1785 - accuracy: 0.9340
    Epoch 21/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.1684 - accuracy: 0.9386
    Epoch 22/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.1646 - accuracy: 0.9395
    Epoch 23/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.1575 - accuracy: 0.9413
    Epoch 24/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.1574 - accuracy: 0.9413
    Epoch 25/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.1520 - accuracy: 0.9435
    Epoch 26/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.1477 - accuracy: 0.9450
    Epoch 27/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.1559 - accuracy: 0.9425
    Epoch 28/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.1426 - accuracy: 0.9467
    Epoch 29/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.1367 - accuracy: 0.9497
    Epoch 30/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.1322 - accuracy: 0.9508
    57/57 [==============================] - 1s 25ms/step - loss: 0.1949 - accuracy: 0.9372
    Model: "sequential_42"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_126 (Conv1D)          (None, 86, 768)           12288     
    _________________________________________________________________
    max_pooling1d_42 (MaxPooling (None, 43, 768)           0         
    _________________________________________________________________
    conv1d_127 (Conv1D)          (None, 41, 512)           1180160   
    _________________________________________________________________
    average_pooling1d_42 (Averag (None, 20, 512)           0         
    _________________________________________________________________
    conv1d_128 (Conv1D)          (None, 18, 256)           393472    
    _________________________________________________________________
    global_average_pooling1d_42  (None, 256)               0         
    _________________________________________________________________
    dense_126 (Dense)            (None, 256)               65792     
    _________________________________________________________________
    dropout_84 (Dropout)         (None, 256)               0         
    _________________________________________________________________
    dense_127 (Dense)            (None, 256)               65792     
    _________________________________________________________________
    dropout_85 (Dropout)         (None, 256)               0         
    _________________________________________________________________
    dense_128 (Dense)            (None, 6)                 1542      
    =================================================================
    Total params: 1,719,046
    Trainable params: 1,719,046
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 11s 67ms/step - loss: 1.1441 - accuracy: 0.5148
    Epoch 2/30
    171/171 [==============================] - 11s 67ms/step - loss: 0.8269 - accuracy: 0.6593
    Epoch 3/30
    171/171 [==============================] - 11s 67ms/step - loss: 0.6011 - accuracy: 0.7683
    Epoch 4/30
    171/171 [==============================] - 11s 67ms/step - loss: 0.4485 - accuracy: 0.8343
    Epoch 5/30
    171/171 [==============================] - 11s 67ms/step - loss: 0.3678 - accuracy: 0.8634
    Epoch 6/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.3459 - accuracy: 0.8738
    Epoch 7/30
    171/171 [==============================] - 11s 67ms/step - loss: 0.3055 - accuracy: 0.8857
    Epoch 8/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.2937 - accuracy: 0.8917
    Epoch 9/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.3462 - accuracy: 0.8760
    Epoch 10/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.2585 - accuracy: 0.9045
    Epoch 11/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.2387 - accuracy: 0.9126
    Epoch 12/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.2264 - accuracy: 0.9172
    Epoch 13/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.2472 - accuracy: 0.9135
    Epoch 14/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.2088 - accuracy: 0.9230
    Epoch 15/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.2186 - accuracy: 0.9219
    Epoch 16/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.1972 - accuracy: 0.9276
    Epoch 17/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.1898 - accuracy: 0.9303
    Epoch 18/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.1798 - accuracy: 0.9328
    Epoch 19/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.1806 - accuracy: 0.9340
    Epoch 20/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.1741 - accuracy: 0.9362
    Epoch 21/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.1939 - accuracy: 0.9318
    Epoch 22/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.1597 - accuracy: 0.9401
    Epoch 23/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.1547 - accuracy: 0.9423
    Epoch 24/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.1581 - accuracy: 0.9402
    Epoch 25/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.1669 - accuracy: 0.9393
    Epoch 26/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.1509 - accuracy: 0.94280s - loss: 0.1508 
    Epoch 27/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.1414 - accuracy: 0.9455
    Epoch 28/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.1421 - accuracy: 0.9462
    Epoch 29/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.1353 - accuracy: 0.9492
    Epoch 30/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.1308 - accuracy: 0.9503
    57/57 [==============================] - 1s 23ms/step - loss: 0.1921 - accuracy: 0.9370
    Model: "sequential_43"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_129 (Conv1D)          (None, 86, 768)           12288     
    _________________________________________________________________
    max_pooling1d_43 (MaxPooling (None, 43, 768)           0         
    _________________________________________________________________
    conv1d_130 (Conv1D)          (None, 41, 512)           1180160   
    _________________________________________________________________
    average_pooling1d_43 (Averag (None, 20, 512)           0         
    _________________________________________________________________
    conv1d_131 (Conv1D)          (None, 18, 256)           393472    
    _________________________________________________________________
    global_average_pooling1d_43  (None, 256)               0         
    _________________________________________________________________
    dense_129 (Dense)            (None, 256)               65792     
    _________________________________________________________________
    dropout_86 (Dropout)         (None, 256)               0         
    _________________________________________________________________
    dense_130 (Dense)            (None, 256)               65792     
    _________________________________________________________________
    dropout_87 (Dropout)         (None, 256)               0         
    _________________________________________________________________
    dense_131 (Dense)            (None, 6)                 1542      
    =================================================================
    Total params: 1,719,046
    Trainable params: 1,719,046
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 12s 69ms/step - loss: 1.1298 - accuracy: 0.5272
    Epoch 2/30
    171/171 [==============================] - 11s 67ms/step - loss: 0.8043 - accuracy: 0.6682
    Epoch 3/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.5975 - accuracy: 0.7667
    Epoch 4/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.4477 - accuracy: 0.8316
    Epoch 5/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.3845 - accuracy: 0.8580
    Epoch 6/30
    171/171 [==============================] - 11s 67ms/step - loss: 0.3267 - accuracy: 0.8761
    Epoch 7/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.3174 - accuracy: 0.8828
    Epoch 8/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.2826 - accuracy: 0.89330s - los
    Epoch 9/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.2773 - accuracy: 0.8979
    Epoch 10/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.2480 - accuracy: 0.9090
    Epoch 11/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.2444 - accuracy: 0.9100
    Epoch 12/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.2508 - accuracy: 0.9078
    Epoch 13/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.2286 - accuracy: 0.9127
    Epoch 14/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.3697 - accuracy: 0.8752
    Epoch 15/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.2181 - accuracy: 0.9207
    Epoch 16/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.2105 - accuracy: 0.9223
    Epoch 17/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.1925 - accuracy: 0.9296
    Epoch 18/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.1836 - accuracy: 0.9333
    Epoch 19/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.1775 - accuracy: 0.9354
    Epoch 20/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.2098 - accuracy: 0.9279
    Epoch 21/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.2039 - accuracy: 0.9265
    Epoch 22/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.1666 - accuracy: 0.9392
    Epoch 23/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.1679 - accuracy: 0.9390
    Epoch 24/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.1589 - accuracy: 0.9428
    Epoch 25/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.1499 - accuracy: 0.9453
    Epoch 26/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.1569 - accuracy: 0.9437
    Epoch 27/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.1386 - accuracy: 0.9497
    Epoch 28/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.1373 - accuracy: 0.9490
    Epoch 29/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.1337 - accuracy: 0.9505
    Epoch 30/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.1283 - accuracy: 0.9523
    57/57 [==============================] - 1s 25ms/step - loss: 0.1971 - accuracy: 0.9337
    Model: "sequential_44"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_132 (Conv1D)          (None, 86, 768)           12288     
    _________________________________________________________________
    max_pooling1d_44 (MaxPooling (None, 43, 768)           0         
    _________________________________________________________________
    conv1d_133 (Conv1D)          (None, 41, 512)           1180160   
    _________________________________________________________________
    average_pooling1d_44 (Averag (None, 20, 512)           0         
    _________________________________________________________________
    conv1d_134 (Conv1D)          (None, 18, 256)           393472    
    _________________________________________________________________
    global_average_pooling1d_44  (None, 256)               0         
    _________________________________________________________________
    dense_132 (Dense)            (None, 256)               65792     
    _________________________________________________________________
    dropout_88 (Dropout)         (None, 256)               0         
    _________________________________________________________________
    dense_133 (Dense)            (None, 256)               65792     
    _________________________________________________________________
    dropout_89 (Dropout)         (None, 256)               0         
    _________________________________________________________________
    dense_134 (Dense)            (None, 6)                 1542      
    =================================================================
    Total params: 1,719,046
    Trainable params: 1,719,046
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 11s 67ms/step - loss: 1.1279 - accuracy: 0.5240
    Epoch 2/30
    171/171 [==============================] - 11s 67ms/step - loss: 0.8142 - accuracy: 0.6618
    Epoch 3/30
    171/171 [==============================] - 11s 67ms/step - loss: 0.5964 - accuracy: 0.7674
    Epoch 4/30
    171/171 [==============================] - 11s 67ms/step - loss: 0.4464 - accuracy: 0.8293
    Epoch 5/30
    171/171 [==============================] - 11s 67ms/step - loss: 0.3688 - accuracy: 0.8609
    Epoch 6/30
    171/171 [==============================] - 11s 67ms/step - loss: 0.3386 - accuracy: 0.8711
    Epoch 7/30
    171/171 [==============================] - 11s 67ms/step - loss: 0.3111 - accuracy: 0.8824
    Epoch 8/30
    171/171 [==============================] - 11s 67ms/step - loss: 0.2977 - accuracy: 0.8891
    Epoch 9/30
    171/171 [==============================] - 11s 67ms/step - loss: 0.2702 - accuracy: 0.9001
    Epoch 10/30
    171/171 [==============================] - 11s 67ms/step - loss: 0.2477 - accuracy: 0.9075
    Epoch 11/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.2467 - accuracy: 0.9099
    Epoch 12/30
    171/171 [==============================] - 11s 67ms/step - loss: 0.2307 - accuracy: 0.9135
    Epoch 13/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.2302 - accuracy: 0.9153
    Epoch 14/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.2126 - accuracy: 0.9214
    Epoch 15/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.2032 - accuracy: 0.9249
    Epoch 16/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.1945 - accuracy: 0.9278
    Epoch 17/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.2484 - accuracy: 0.9164
    Epoch 18/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.1843 - accuracy: 0.9315
    Epoch 19/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.1701 - accuracy: 0.9363
    Epoch 20/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.1663 - accuracy: 0.9378
    Epoch 21/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.2514 - accuracy: 0.9185
    Epoch 22/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.1730 - accuracy: 0.9369
    Epoch 23/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.1620 - accuracy: 0.9391
    Epoch 24/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.1508 - accuracy: 0.9433
    Epoch 25/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.1527 - accuracy: 0.9435
    Epoch 26/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.1387 - accuracy: 0.9475
    Epoch 27/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.1363 - accuracy: 0.9476
    Epoch 28/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.1563 - accuracy: 0.9448
    Epoch 29/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.1438 - accuracy: 0.9464
    Epoch 30/30
    171/171 [==============================] - 11s 66ms/step - loss: 0.1309 - accuracy: 0.9508
    57/57 [==============================] - 1s 23ms/step - loss: 0.1799 - accuracy: 0.9395
    Model: "sequential_45"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_135 (Conv1D)          (None, 88, 768)           7680      
    _________________________________________________________________
    max_pooling1d_45 (MaxPooling (None, 22, 768)           0         
    _________________________________________________________________
    conv1d_136 (Conv1D)          (None, 18, 512)           1966592   
    _________________________________________________________________
    average_pooling1d_45 (Averag (None, 9, 512)            0         
    _________________________________________________________________
    conv1d_137 (Conv1D)          (None, 7, 512)            786944    
    _________________________________________________________________
    global_average_pooling1d_45  (None, 512)               0         
    _________________________________________________________________
    dense_135 (Dense)            (None, 512)               262656    
    _________________________________________________________________
    dropout_90 (Dropout)         (None, 512)               0         
    _________________________________________________________________
    dense_136 (Dense)            (None, 512)               262656    
    _________________________________________________________________
    dropout_91 (Dropout)         (None, 512)               0         
    _________________________________________________________________
    dense_137 (Dense)            (None, 6)                 3078      
    =================================================================
    Total params: 3,289,606
    Trainable params: 3,289,606
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 10s 58ms/step - loss: 1.1573 - accuracy: 0.5049
    Epoch 2/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.8079 - accuracy: 0.6678
    Epoch 3/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.5323 - accuracy: 0.7947
    Epoch 4/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.4041 - accuracy: 0.8491
    Epoch 5/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.3582 - accuracy: 0.8643
    Epoch 6/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.3285 - accuracy: 0.8746
    Epoch 7/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.2898 - accuracy: 0.8892
    Epoch 8/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.2700 - accuracy: 0.8979
    Epoch 9/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.2655 - accuracy: 0.9007
    Epoch 10/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.2445 - accuracy: 0.9102
    Epoch 11/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.3091 - accuracy: 0.8913
    Epoch 12/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.2375 - accuracy: 0.9141
    Epoch 13/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.2063 - accuracy: 0.9245
    Epoch 14/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1930 - accuracy: 0.9285
    Epoch 15/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1896 - accuracy: 0.9301
    Epoch 16/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1785 - accuracy: 0.9332
    Epoch 17/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1754 - accuracy: 0.9354
    Epoch 18/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1595 - accuracy: 0.9404
    Epoch 19/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1695 - accuracy: 0.9389
    Epoch 20/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1583 - accuracy: 0.9412
    Epoch 21/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1442 - accuracy: 0.9462
    Epoch 22/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1421 - accuracy: 0.9475
    Epoch 23/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1513 - accuracy: 0.9466
    Epoch 24/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1276 - accuracy: 0.9530
    Epoch 25/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1240 - accuracy: 0.9542
    Epoch 26/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1180 - accuracy: 0.9562
    Epoch 27/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1151 - accuracy: 0.9570
    Epoch 28/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1103 - accuracy: 0.9586
    Epoch 29/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1121 - accuracy: 0.9587
    Epoch 30/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1060 - accuracy: 0.9607
    57/57 [==============================] - 1s 20ms/step - loss: 0.2342 - accuracy: 0.9369
    Model: "sequential_46"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_138 (Conv1D)          (None, 88, 768)           7680      
    _________________________________________________________________
    max_pooling1d_46 (MaxPooling (None, 22, 768)           0         
    _________________________________________________________________
    conv1d_139 (Conv1D)          (None, 18, 512)           1966592   
    _________________________________________________________________
    average_pooling1d_46 (Averag (None, 9, 512)            0         
    _________________________________________________________________
    conv1d_140 (Conv1D)          (None, 7, 512)            786944    
    _________________________________________________________________
    global_average_pooling1d_46  (None, 512)               0         
    _________________________________________________________________
    dense_138 (Dense)            (None, 512)               262656    
    _________________________________________________________________
    dropout_92 (Dropout)         (None, 512)               0         
    _________________________________________________________________
    dense_139 (Dense)            (None, 512)               262656    
    _________________________________________________________________
    dropout_93 (Dropout)         (None, 512)               0         
    _________________________________________________________________
    dense_140 (Dense)            (None, 6)                 3078      
    =================================================================
    Total params: 3,289,606
    Trainable params: 3,289,606
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
      2/171 [..............................] - ETA: 9s - loss: 1.7827 - accuracy: 0.1504WARNING:tensorflow:Callbacks method `on_train_batch_end` is slow compared to the batch time (batch time: 0.0234s vs `on_train_batch_end` time: 0.0381s). Check your callbacks.
    171/171 [==============================] - 10s 56ms/step - loss: 1.1578 - accuracy: 0.5046
    Epoch 2/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.7850 - accuracy: 0.6815
    Epoch 3/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.5087 - accuracy: 0.8082
    Epoch 4/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.3922 - accuracy: 0.8529
    Epoch 5/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.3546 - accuracy: 0.8660
    Epoch 6/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.3085 - accuracy: 0.8832
    Epoch 7/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.2867 - accuracy: 0.8914
    Epoch 8/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.2703 - accuracy: 0.8974
    Epoch 9/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.2570 - accuracy: 0.9044
    Epoch 10/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.2388 - accuracy: 0.9097
    Epoch 11/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.2257 - accuracy: 0.9148
    Epoch 12/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.2177 - accuracy: 0.9195
    Epoch 13/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1995 - accuracy: 0.9256
    Epoch 14/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.2002 - accuracy: 0.9265
    Epoch 15/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1773 - accuracy: 0.9345
    Epoch 16/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1694 - accuracy: 0.9363
    Epoch 17/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1757 - accuracy: 0.9360
    Epoch 18/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1578 - accuracy: 0.9405
    Epoch 19/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1495 - accuracy: 0.9438
    Epoch 20/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1698 - accuracy: 0.9399
    Epoch 21/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1458 - accuracy: 0.9466
    Epoch 22/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1378 - accuracy: 0.9482
    Epoch 23/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1270 - accuracy: 0.9517
    Epoch 24/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1243 - accuracy: 0.9536
    Epoch 25/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1187 - accuracy: 0.9559
    Epoch 26/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1188 - accuracy: 0.9550
    Epoch 27/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1158 - accuracy: 0.9570
    Epoch 28/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1108 - accuracy: 0.9581
    Epoch 29/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1107 - accuracy: 0.9586
    Epoch 30/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1054 - accuracy: 0.9602
    57/57 [==============================] - 1s 18ms/step - loss: 0.2380 - accuracy: 0.9378
    Model: "sequential_47"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_141 (Conv1D)          (None, 88, 768)           7680      
    _________________________________________________________________
    max_pooling1d_47 (MaxPooling (None, 22, 768)           0         
    _________________________________________________________________
    conv1d_142 (Conv1D)          (None, 18, 512)           1966592   
    _________________________________________________________________
    average_pooling1d_47 (Averag (None, 9, 512)            0         
    _________________________________________________________________
    conv1d_143 (Conv1D)          (None, 7, 512)            786944    
    _________________________________________________________________
    global_average_pooling1d_47  (None, 512)               0         
    _________________________________________________________________
    dense_141 (Dense)            (None, 512)               262656    
    _________________________________________________________________
    dropout_94 (Dropout)         (None, 512)               0         
    _________________________________________________________________
    dense_142 (Dense)            (None, 512)               262656    
    _________________________________________________________________
    dropout_95 (Dropout)         (None, 512)               0         
    _________________________________________________________________
    dense_143 (Dense)            (None, 6)                 3078      
    =================================================================
    Total params: 3,289,606
    Trainable params: 3,289,606
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 10s 58ms/step - loss: 1.1672 - accuracy: 0.5012
    Epoch 2/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.8276 - accuracy: 0.6592
    Epoch 3/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.5396 - accuracy: 0.7962
    Epoch 4/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.4200 - accuracy: 0.8431
    Epoch 5/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.3467 - accuracy: 0.8674
    Epoch 6/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.3086 - accuracy: 0.8826
    Epoch 7/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.2914 - accuracy: 0.8930
    Epoch 8/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.2697 - accuracy: 0.9006
    Epoch 9/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.2448 - accuracy: 0.9098
    Epoch 10/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.2637 - accuracy: 0.9068
    Epoch 11/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.2206 - accuracy: 0.9198
    Epoch 12/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.2136 - accuracy: 0.9200
    Epoch 13/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.2185 - accuracy: 0.9220
    Epoch 14/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1870 - accuracy: 0.9328
    Epoch 15/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1822 - accuracy: 0.9329
    Epoch 16/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1764 - accuracy: 0.9356
    Epoch 17/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1660 - accuracy: 0.9386
    Epoch 18/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1620 - accuracy: 0.9398
    Epoch 19/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1584 - accuracy: 0.9423
    Epoch 20/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1480 - accuracy: 0.9456
    Epoch 21/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1401 - accuracy: 0.9486
    Epoch 22/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1356 - accuracy: 0.9509
    Epoch 23/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1452 - accuracy: 0.9487
    Epoch 24/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1728 - accuracy: 0.9404
    Epoch 25/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1306 - accuracy: 0.9531
    Epoch 26/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1203 - accuracy: 0.9561
    Epoch 27/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1159 - accuracy: 0.9577
    Epoch 28/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1121 - accuracy: 0.9582
    Epoch 29/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1126 - accuracy: 0.9574
    Epoch 30/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1024 - accuracy: 0.9619
    57/57 [==============================] - 1s 20ms/step - loss: 0.2512 - accuracy: 0.9359
    Model: "sequential_48"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_144 (Conv1D)          (None, 88, 768)           7680      
    _________________________________________________________________
    max_pooling1d_48 (MaxPooling (None, 22, 768)           0         
    _________________________________________________________________
    conv1d_145 (Conv1D)          (None, 18, 512)           1966592   
    _________________________________________________________________
    average_pooling1d_48 (Averag (None, 9, 512)            0         
    _________________________________________________________________
    conv1d_146 (Conv1D)          (None, 7, 512)            786944    
    _________________________________________________________________
    global_average_pooling1d_48  (None, 512)               0         
    _________________________________________________________________
    dense_144 (Dense)            (None, 512)               262656    
    _________________________________________________________________
    dropout_96 (Dropout)         (None, 512)               0         
    _________________________________________________________________
    dense_145 (Dense)            (None, 512)               262656    
    _________________________________________________________________
    dropout_97 (Dropout)         (None, 512)               0         
    _________________________________________________________________
    dense_146 (Dense)            (None, 6)                 3078      
    =================================================================
    Total params: 3,289,606
    Trainable params: 3,289,606
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 10s 56ms/step - loss: 1.1426 - accuracy: 0.5097
    Epoch 2/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.7867 - accuracy: 0.6807
    Epoch 3/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.5211 - accuracy: 0.8044
    Epoch 4/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.4024 - accuracy: 0.8483
    Epoch 5/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.3414 - accuracy: 0.8733
    Epoch 6/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.3125 - accuracy: 0.8843
    Epoch 7/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.2849 - accuracy: 0.8936
    Epoch 8/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.2830 - accuracy: 0.8983
    Epoch 9/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.2449 - accuracy: 0.9097
    Epoch 10/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.2335 - accuracy: 0.9151
    Epoch 11/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.2149 - accuracy: 0.9199
    Epoch 12/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.2051 - accuracy: 0.9250
    Epoch 13/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1988 - accuracy: 0.9278
    Epoch 14/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1885 - accuracy: 0.9317
    Epoch 15/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1986 - accuracy: 0.9280
    Epoch 16/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1695 - accuracy: 0.9381
    Epoch 17/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1620 - accuracy: 0.9408
    Epoch 18/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1572 - accuracy: 0.9423
    Epoch 19/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1519 - accuracy: 0.9445
    Epoch 20/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1456 - accuracy: 0.9455
    Epoch 21/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1390 - accuracy: 0.9485
    Epoch 22/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1357 - accuracy: 0.9501
    Epoch 23/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1257 - accuracy: 0.9536
    Epoch 24/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1233 - accuracy: 0.9544
    Epoch 25/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1265 - accuracy: 0.9536
    Epoch 26/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1222 - accuracy: 0.9553
    Epoch 27/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1141 - accuracy: 0.9579
    Epoch 28/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1069 - accuracy: 0.9600
    Epoch 29/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1104 - accuracy: 0.9593
    Epoch 30/30
    171/171 [==============================] - 10s 56ms/step - loss: 0.1124 - accuracy: 0.9591
    57/57 [==============================] - 1s 19ms/step - loss: 0.2317 - accuracy: 0.9358
    Model: "sequential_49"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_147 (Conv1D)          (None, 86, 768)           12288     
    _________________________________________________________________
    max_pooling1d_49 (MaxPooling (None, 21, 768)           0         
    _________________________________________________________________
    conv1d_148 (Conv1D)          (None, 19, 768)           1770240   
    _________________________________________________________________
    average_pooling1d_49 (Averag (None, 9, 768)            0         
    _________________________________________________________________
    conv1d_149 (Conv1D)          (None, 5, 512)            1966592   
    _________________________________________________________________
    global_average_pooling1d_49  (None, 512)               0         
    _________________________________________________________________
    dense_147 (Dense)            (None, 512)               262656    
    _________________________________________________________________
    dropout_98 (Dropout)         (None, 512)               0         
    _________________________________________________________________
    dense_148 (Dense)            (None, 512)               262656    
    _________________________________________________________________
    dropout_99 (Dropout)         (None, 512)               0         
    _________________________________________________________________
    dense_149 (Dense)            (None, 6)                 3078      
    =================================================================
    Total params: 4,277,510
    Trainable params: 4,277,510
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 11s 66ms/step - loss: 1.1266 - accuracy: 0.5209
    Epoch 2/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.7351 - accuracy: 0.7009
    Epoch 3/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.5204 - accuracy: 0.7944
    Epoch 4/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.4066 - accuracy: 0.8432
    Epoch 5/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.3580 - accuracy: 0.8632
    Epoch 6/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.3217 - accuracy: 0.8774
    Epoch 7/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.3074 - accuracy: 0.8869
    Epoch 8/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.2596 - accuracy: 0.9028
    Epoch 9/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.2502 - accuracy: 0.9047
    Epoch 10/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.2352 - accuracy: 0.9120
    Epoch 11/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.2990 - accuracy: 0.8978
    Epoch 12/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.2193 - accuracy: 0.9201
    Epoch 13/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1995 - accuracy: 0.9257
    Epoch 14/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1903 - accuracy: 0.9279
    Epoch 15/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1762 - accuracy: 0.9327
    Epoch 16/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1713 - accuracy: 0.9352
    Epoch 17/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1617 - accuracy: 0.9377
    Epoch 18/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1784 - accuracy: 0.9369
    Epoch 19/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1565 - accuracy: 0.9407
    Epoch 20/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1432 - accuracy: 0.9459
    Epoch 21/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1335 - accuracy: 0.9488
    Epoch 22/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1304 - accuracy: 0.9504
    Epoch 23/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1239 - accuracy: 0.9518
    Epoch 24/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1251 - accuracy: 0.9520
    Epoch 25/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1199 - accuracy: 0.9553
    Epoch 26/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1119 - accuracy: 0.9571
    Epoch 27/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1138 - accuracy: 0.9567
    Epoch 28/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1075 - accuracy: 0.9588
    Epoch 29/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1061 - accuracy: 0.9597
    Epoch 30/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1035 - accuracy: 0.9601
    57/57 [==============================] - 1s 22ms/step - loss: 0.2555 - accuracy: 0.9360
    Model: "sequential_50"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_150 (Conv1D)          (None, 86, 768)           12288     
    _________________________________________________________________
    max_pooling1d_50 (MaxPooling (None, 21, 768)           0         
    _________________________________________________________________
    conv1d_151 (Conv1D)          (None, 19, 768)           1770240   
    _________________________________________________________________
    average_pooling1d_50 (Averag (None, 9, 768)            0         
    _________________________________________________________________
    conv1d_152 (Conv1D)          (None, 5, 512)            1966592   
    _________________________________________________________________
    global_average_pooling1d_50  (None, 512)               0         
    _________________________________________________________________
    dense_150 (Dense)            (None, 512)               262656    
    _________________________________________________________________
    dropout_100 (Dropout)        (None, 512)               0         
    _________________________________________________________________
    dense_151 (Dense)            (None, 512)               262656    
    _________________________________________________________________
    dropout_101 (Dropout)        (None, 512)               0         
    _________________________________________________________________
    dense_152 (Dense)            (None, 6)                 3078      
    =================================================================
    Total params: 4,277,510
    Trainable params: 4,277,510
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 11s 64ms/step - loss: 1.1472 - accuracy: 0.5123
    Epoch 2/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.7950 - accuracy: 0.6768
    Epoch 3/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.5185 - accuracy: 0.7999
    Epoch 4/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.4099 - accuracy: 0.84420s - los
    Epoch 5/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.3674 - accuracy: 0.8629
    Epoch 6/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.3570 - accuracy: 0.8703
    Epoch 7/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.2973 - accuracy: 0.8879
    Epoch 8/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.2723 - accuracy: 0.8967
    Epoch 9/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.2583 - accuracy: 0.9003
    Epoch 10/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.2311 - accuracy: 0.9113
    Epoch 11/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.2357 - accuracy: 0.9119
    Epoch 12/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.2093 - accuracy: 0.9182
    Epoch 13/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.3378 - accuracy: 0.8879
    Epoch 14/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.2061 - accuracy: 0.9236
    Epoch 15/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.2002 - accuracy: 0.9279
    Epoch 16/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1762 - accuracy: 0.9335
    Epoch 17/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1759 - accuracy: 0.9349
    Epoch 18/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1582 - accuracy: 0.9403
    Epoch 19/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1545 - accuracy: 0.9415
    Epoch 20/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1504 - accuracy: 0.9437
    Epoch 21/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1447 - accuracy: 0.9462
    Epoch 22/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1373 - accuracy: 0.9480
    Epoch 23/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1346 - accuracy: 0.9491
    Epoch 24/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1243 - accuracy: 0.9518
    Epoch 25/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1244 - accuracy: 0.9523
    Epoch 26/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1221 - accuracy: 0.9537
    Epoch 27/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1182 - accuracy: 0.9551
    Epoch 28/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1142 - accuracy: 0.9565
    Epoch 29/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1102 - accuracy: 0.9596
    Epoch 30/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1031 - accuracy: 0.9607
    57/57 [==============================] - 1s 20ms/step - loss: 0.2908 - accuracy: 0.9308
    Model: "sequential_51"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_153 (Conv1D)          (None, 86, 768)           12288     
    _________________________________________________________________
    max_pooling1d_51 (MaxPooling (None, 21, 768)           0         
    _________________________________________________________________
    conv1d_154 (Conv1D)          (None, 19, 768)           1770240   
    _________________________________________________________________
    average_pooling1d_51 (Averag (None, 9, 768)            0         
    _________________________________________________________________
    conv1d_155 (Conv1D)          (None, 5, 512)            1966592   
    _________________________________________________________________
    global_average_pooling1d_51  (None, 512)               0         
    _________________________________________________________________
    dense_153 (Dense)            (None, 512)               262656    
    _________________________________________________________________
    dropout_102 (Dropout)        (None, 512)               0         
    _________________________________________________________________
    dense_154 (Dense)            (None, 512)               262656    
    _________________________________________________________________
    dropout_103 (Dropout)        (None, 512)               0         
    _________________________________________________________________
    dense_155 (Dense)            (None, 6)                 3078      
    =================================================================
    Total params: 4,277,510
    Trainable params: 4,277,510
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 11s 66ms/step - loss: 1.1340 - accuracy: 0.5220
    Epoch 2/30
    171/171 [==============================] - 11s 64ms/step - loss: 0.7670 - accuracy: 0.6861
    Epoch 3/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.5155 - accuracy: 0.8000
    Epoch 4/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.3985 - accuracy: 0.8480
    Epoch 5/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.3716 - accuracy: 0.8612
    Epoch 6/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.3242 - accuracy: 0.8757
    Epoch 7/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.2826 - accuracy: 0.8924
    Epoch 8/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.3013 - accuracy: 0.8897
    Epoch 9/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.2528 - accuracy: 0.9051
    Epoch 10/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.2342 - accuracy: 0.9114
    Epoch 11/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.2214 - accuracy: 0.9161
    Epoch 12/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.2076 - accuracy: 0.9227
    Epoch 13/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.2182 - accuracy: 0.9203
    Epoch 14/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1889 - accuracy: 0.9290
    Epoch 15/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1869 - accuracy: 0.9312
    Epoch 16/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1757 - accuracy: 0.9341
    Epoch 17/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1602 - accuracy: 0.9396
    Epoch 18/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1585 - accuracy: 0.9407
    Epoch 19/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1556 - accuracy: 0.9398
    Epoch 20/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1985 - accuracy: 0.9331
    Epoch 21/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1433 - accuracy: 0.9457
    Epoch 22/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1315 - accuracy: 0.9509
    Epoch 23/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1340 - accuracy: 0.9500
    Epoch 24/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1271 - accuracy: 0.9522
    Epoch 25/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1224 - accuracy: 0.9549
    Epoch 26/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1192 - accuracy: 0.9547
    Epoch 27/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1129 - accuracy: 0.9576
    Epoch 28/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1101 - accuracy: 0.9588
    Epoch 29/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1083 - accuracy: 0.9585
    Epoch 30/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.0995 - accuracy: 0.9627
    57/57 [==============================] - 1s 22ms/step - loss: 0.2881 - accuracy: 0.9242
    Model: "sequential_52"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_156 (Conv1D)          (None, 86, 768)           12288     
    _________________________________________________________________
    max_pooling1d_52 (MaxPooling (None, 21, 768)           0         
    _________________________________________________________________
    conv1d_157 (Conv1D)          (None, 19, 768)           1770240   
    _________________________________________________________________
    average_pooling1d_52 (Averag (None, 9, 768)            0         
    _________________________________________________________________
    conv1d_158 (Conv1D)          (None, 5, 512)            1966592   
    _________________________________________________________________
    global_average_pooling1d_52  (None, 512)               0         
    _________________________________________________________________
    dense_156 (Dense)            (None, 512)               262656    
    _________________________________________________________________
    dropout_104 (Dropout)        (None, 512)               0         
    _________________________________________________________________
    dense_157 (Dense)            (None, 512)               262656    
    _________________________________________________________________
    dropout_105 (Dropout)        (None, 512)               0         
    _________________________________________________________________
    dense_158 (Dense)            (None, 6)                 3078      
    =================================================================
    Total params: 4,277,510
    Trainable params: 4,277,510
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
      2/171 [..............................] - ETA: 9s - loss: 1.7694 - accuracy: 0.1562WARNING:tensorflow:Callbacks method `on_train_batch_end` is slow compared to the batch time (batch time: 0.0257s vs `on_train_batch_end` time: 0.0430s). Check your callbacks.
    171/171 [==============================] - 11s 64ms/step - loss: 1.1327 - accuracy: 0.5184
    Epoch 2/30
    171/171 [==============================] - 11s 64ms/step - loss: 0.7609 - accuracy: 0.6931
    Epoch 3/30
    171/171 [==============================] - 11s 64ms/step - loss: 0.5199 - accuracy: 0.7997
    Epoch 4/30
    171/171 [==============================] - 11s 64ms/step - loss: 0.4008 - accuracy: 0.8463
    Epoch 5/30
    171/171 [==============================] - 11s 64ms/step - loss: 0.3459 - accuracy: 0.8663
    Epoch 6/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.3385 - accuracy: 0.8747
    Epoch 7/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.3055 - accuracy: 0.8842
    Epoch 8/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.2762 - accuracy: 0.8944
    Epoch 9/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.2955 - accuracy: 0.8896
    Epoch 10/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.2527 - accuracy: 0.9036
    Epoch 11/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.2279 - accuracy: 0.9126
    Epoch 12/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.2074 - accuracy: 0.9210
    Epoch 13/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.2080 - accuracy: 0.9212
    Epoch 14/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1912 - accuracy: 0.9267
    Epoch 15/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1808 - accuracy: 0.9289
    Epoch 16/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1730 - accuracy: 0.9355
    Epoch 17/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1827 - accuracy: 0.9327
    Epoch 18/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1590 - accuracy: 0.9401
    Epoch 19/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1523 - accuracy: 0.9423
    Epoch 20/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1453 - accuracy: 0.9430
    Epoch 21/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1414 - accuracy: 0.9461
    Epoch 22/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1416 - accuracy: 0.9472
    Epoch 23/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1314 - accuracy: 0.9501
    Epoch 24/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1222 - accuracy: 0.9531
    Epoch 25/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1189 - accuracy: 0.9549
    Epoch 26/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1157 - accuracy: 0.9558
    Epoch 27/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1142 - accuracy: 0.9569
    Epoch 28/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1124 - accuracy: 0.9585
    Epoch 29/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1089 - accuracy: 0.9595
    Epoch 30/30
    171/171 [==============================] - 11s 63ms/step - loss: 0.1154 - accuracy: 0.9578
    57/57 [==============================] - 1s 20ms/step - loss: 0.2426 - accuracy: 0.9391
    Model: "sequential_53"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_159 (Conv1D)          (None, 86, 768)           12288     
    _________________________________________________________________
    max_pooling1d_53 (MaxPooling (None, 43, 768)           0         
    _________________________________________________________________
    conv1d_160 (Conv1D)          (None, 39, 768)           2949888   
    _________________________________________________________________
    average_pooling1d_53 (Averag (None, 19, 768)           0         
    _________________________________________________________________
    conv1d_161 (Conv1D)          (None, 17, 256)           590080    
    _________________________________________________________________
    global_average_pooling1d_53  (None, 256)               0         
    _________________________________________________________________
    dense_159 (Dense)            (None, 512)               131584    
    _________________________________________________________________
    dropout_106 (Dropout)        (None, 512)               0         
    _________________________________________________________________
    dense_160 (Dense)            (None, 256)               131328    
    _________________________________________________________________
    dropout_107 (Dropout)        (None, 256)               0         
    _________________________________________________________________
    dense_161 (Dense)            (None, 6)                 1542      
    =================================================================
    Total params: 3,816,710
    Trainable params: 3,816,710
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 18s 107ms/step - loss: 1.1383 - accuracy: 0.5212
    Epoch 2/30
    171/171 [==============================] - 18s 104ms/step - loss: 0.8043 - accuracy: 0.6673
    Epoch 3/30
    171/171 [==============================] - 18s 104ms/step - loss: 0.6146 - accuracy: 0.7618
    Epoch 4/30
    171/171 [==============================] - 18s 104ms/step - loss: 0.4554 - accuracy: 0.8307
    Epoch 5/30
    171/171 [==============================] - 18s 104ms/step - loss: 0.3655 - accuracy: 0.8641
    Epoch 6/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.3317 - accuracy: 0.8745
    Epoch 7/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.3436 - accuracy: 0.8737
    Epoch 8/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.3096 - accuracy: 0.8851
    Epoch 9/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.2646 - accuracy: 0.9004
    Epoch 10/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.2587 - accuracy: 0.9032
    Epoch 11/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.2480 - accuracy: 0.9074
    Epoch 12/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.2373 - accuracy: 0.9095
    Epoch 13/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.2172 - accuracy: 0.9183
    Epoch 14/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.2204 - accuracy: 0.9180
    Epoch 15/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.2025 - accuracy: 0.9239
    Epoch 16/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.1952 - accuracy: 0.9275
    Epoch 17/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.1922 - accuracy: 0.9279
    Epoch 18/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.1874 - accuracy: 0.9313
    Epoch 19/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.1861 - accuracy: 0.9309
    Epoch 20/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.1735 - accuracy: 0.9348
    Epoch 21/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.1635 - accuracy: 0.9386
    Epoch 22/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.2479 - accuracy: 0.9167
    Epoch 23/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.1653 - accuracy: 0.9393
    Epoch 24/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.1546 - accuracy: 0.9426
    Epoch 25/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.1470 - accuracy: 0.9465
    Epoch 26/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.1430 - accuracy: 0.9471
    Epoch 27/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.1383 - accuracy: 0.9483
    Epoch 28/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.1337 - accuracy: 0.9504
    Epoch 29/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.1327 - accuracy: 0.9512
    Epoch 30/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.1301 - accuracy: 0.9516
    57/57 [==============================] - 2s 37ms/step - loss: 0.1947 - accuracy: 0.9398
    Model: "sequential_54"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_162 (Conv1D)          (None, 86, 768)           12288     
    _________________________________________________________________
    max_pooling1d_54 (MaxPooling (None, 43, 768)           0         
    _________________________________________________________________
    conv1d_163 (Conv1D)          (None, 39, 768)           2949888   
    _________________________________________________________________
    average_pooling1d_54 (Averag (None, 19, 768)           0         
    _________________________________________________________________
    conv1d_164 (Conv1D)          (None, 17, 256)           590080    
    _________________________________________________________________
    global_average_pooling1d_54  (None, 256)               0         
    _________________________________________________________________
    dense_162 (Dense)            (None, 512)               131584    
    _________________________________________________________________
    dropout_108 (Dropout)        (None, 512)               0         
    _________________________________________________________________
    dense_163 (Dense)            (None, 256)               131328    
    _________________________________________________________________
    dropout_109 (Dropout)        (None, 256)               0         
    _________________________________________________________________
    dense_164 (Dense)            (None, 6)                 1542      
    =================================================================
    Total params: 3,816,710
    Trainable params: 3,816,710
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
      2/171 [..............................] - ETA: 15s - loss: 1.7811 - accuracy: 0.1836WARNING:tensorflow:Callbacks method `on_train_batch_end` is slow compared to the batch time (batch time: 0.0419s vs `on_train_batch_end` time: 0.0659s). Check your callbacks.
    171/171 [==============================] - 18s 105ms/step - loss: 1.1323 - accuracy: 0.5220
    Epoch 2/30
    171/171 [==============================] - 18s 104ms/step - loss: 0.7976 - accuracy: 0.6700
    Epoch 3/30
    171/171 [==============================] - 18s 104ms/step - loss: 0.5697 - accuracy: 0.7771
    Epoch 4/30
    171/171 [==============================] - 18s 104ms/step - loss: 0.4686 - accuracy: 0.8212
    Epoch 5/30
    171/171 [==============================] - 18s 104ms/step - loss: 0.3650 - accuracy: 0.8635
    Epoch 6/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.3315 - accuracy: 0.8751
    Epoch 7/30
    171/171 [==============================] - 18s 104ms/step - loss: 0.3024 - accuracy: 0.8867
    Epoch 8/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.3875 - accuracy: 0.8633
    Epoch 9/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.3049 - accuracy: 0.8883
    Epoch 10/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.2579 - accuracy: 0.9055
    Epoch 11/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.2455 - accuracy: 0.9100
    Epoch 12/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.2279 - accuracy: 0.9161
    Epoch 13/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.2386 - accuracy: 0.9139
    Epoch 14/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.2138 - accuracy: 0.9220
    Epoch 15/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.2048 - accuracy: 0.9231
    Epoch 16/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.2094 - accuracy: 0.9242
    Epoch 17/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.1915 - accuracy: 0.9286
    Epoch 18/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.1785 - accuracy: 0.9335
    Epoch 19/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.1782 - accuracy: 0.9336
    Epoch 20/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.1693 - accuracy: 0.9372
    Epoch 21/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.1670 - accuracy: 0.9379
    Epoch 22/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.2224 - accuracy: 0.9239
    Epoch 23/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.1679 - accuracy: 0.9370
    Epoch 24/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.1555 - accuracy: 0.9411
    Epoch 25/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.1484 - accuracy: 0.9447
    Epoch 26/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.1454 - accuracy: 0.9450
    Epoch 27/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.1419 - accuracy: 0.9470
    Epoch 28/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.1534 - accuracy: 0.9448
    Epoch 29/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.1403 - accuracy: 0.9471
    Epoch 30/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.1290 - accuracy: 0.9505
    57/57 [==============================] - 2s 34ms/step - loss: 0.2045 - accuracy: 0.9411
    Model: "sequential_55"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_165 (Conv1D)          (None, 86, 768)           12288     
    _________________________________________________________________
    max_pooling1d_55 (MaxPooling (None, 43, 768)           0         
    _________________________________________________________________
    conv1d_166 (Conv1D)          (None, 39, 768)           2949888   
    _________________________________________________________________
    average_pooling1d_55 (Averag (None, 19, 768)           0         
    _________________________________________________________________
    conv1d_167 (Conv1D)          (None, 17, 256)           590080    
    _________________________________________________________________
    global_average_pooling1d_55  (None, 256)               0         
    _________________________________________________________________
    dense_165 (Dense)            (None, 512)               131584    
    _________________________________________________________________
    dropout_110 (Dropout)        (None, 512)               0         
    _________________________________________________________________
    dense_166 (Dense)            (None, 256)               131328    
    _________________________________________________________________
    dropout_111 (Dropout)        (None, 256)               0         
    _________________________________________________________________
    dense_167 (Dense)            (None, 6)                 1542      
    =================================================================
    Total params: 3,816,710
    Trainable params: 3,816,710
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
      2/171 [..............................] - ETA: 15s - loss: 1.7775 - accuracy: 0.2109WARNING:tensorflow:Callbacks method `on_train_batch_end` is slow compared to the batch time (batch time: 0.0416s vs `on_train_batch_end` time: 0.0696s). Check your callbacks.
    171/171 [==============================] - 18s 108ms/step - loss: 1.1271 - accuracy: 0.5293
    Epoch 2/30
    171/171 [==============================] - 18s 104ms/step - loss: 0.7887 - accuracy: 0.6748
    Epoch 3/30
    171/171 [==============================] - 18s 104ms/step - loss: 0.5727 - accuracy: 0.7776
    Epoch 4/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.4897 - accuracy: 0.8193
    Epoch 5/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.3910 - accuracy: 0.8544
    Epoch 6/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.3381 - accuracy: 0.8726
    Epoch 7/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.3078 - accuracy: 0.8836
    Epoch 8/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.3073 - accuracy: 0.8857
    Epoch 9/30
    171/171 [==============================] - 18s 104ms/step - loss: 0.2719 - accuracy: 0.8970
    Epoch 10/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.2552 - accuracy: 0.9038
    Epoch 11/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.2503 - accuracy: 0.9065
    Epoch 12/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.2472 - accuracy: 0.9082
    Epoch 13/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.2208 - accuracy: 0.9178
    Epoch 14/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.2094 - accuracy: 0.9207
    Epoch 15/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.2082 - accuracy: 0.9221
    Epoch 16/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.2020 - accuracy: 0.9240
    Epoch 17/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.1922 - accuracy: 0.9275
    Epoch 18/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.1948 - accuracy: 0.9279
    Epoch 19/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.1744 - accuracy: 0.9335
    Epoch 20/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.1741 - accuracy: 0.9346
    Epoch 21/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.1687 - accuracy: 0.9367
    Epoch 22/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.1608 - accuracy: 0.9400
    Epoch 23/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.1571 - accuracy: 0.9417
    Epoch 24/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.1502 - accuracy: 0.9439
    Epoch 25/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.1527 - accuracy: 0.9438
    Epoch 26/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.1406 - accuracy: 0.9467
    Epoch 27/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.1508 - accuracy: 0.9443
    Epoch 28/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.1427 - accuracy: 0.9466
    Epoch 29/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.1355 - accuracy: 0.9500
    Epoch 30/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.1250 - accuracy: 0.9531
    57/57 [==============================] - 2s 36ms/step - loss: 0.2042 - accuracy: 0.9368
    Model: "sequential_56"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_168 (Conv1D)          (None, 86, 768)           12288     
    _________________________________________________________________
    max_pooling1d_56 (MaxPooling (None, 43, 768)           0         
    _________________________________________________________________
    conv1d_169 (Conv1D)          (None, 39, 768)           2949888   
    _________________________________________________________________
    average_pooling1d_56 (Averag (None, 19, 768)           0         
    _________________________________________________________________
    conv1d_170 (Conv1D)          (None, 17, 256)           590080    
    _________________________________________________________________
    global_average_pooling1d_56  (None, 256)               0         
    _________________________________________________________________
    dense_168 (Dense)            (None, 512)               131584    
    _________________________________________________________________
    dropout_112 (Dropout)        (None, 512)               0         
    _________________________________________________________________
    dense_169 (Dense)            (None, 256)               131328    
    _________________________________________________________________
    dropout_113 (Dropout)        (None, 256)               0         
    _________________________________________________________________
    dense_170 (Dense)            (None, 6)                 1542      
    =================================================================
    Total params: 3,816,710
    Trainable params: 3,816,710
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 18s 104ms/step - loss: 1.1433 - accuracy: 0.5134
    Epoch 2/30
    171/171 [==============================] - 18s 104ms/step - loss: 0.8153 - accuracy: 0.6616
    Epoch 3/30
    171/171 [==============================] - 18s 104ms/step - loss: 0.6018 - accuracy: 0.7616s - loss: 0.6091 
    Epoch 4/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.4572 - accuracy: 0.8259
    Epoch 5/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.3838 - accuracy: 0.8552
    Epoch 6/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.3441 - accuracy: 0.8708
    Epoch 7/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.3151 - accuracy: 0.8801
    Epoch 8/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.3022 - accuracy: 0.8863
    Epoch 9/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.2760 - accuracy: 0.8965
    Epoch 10/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.4594 - accuracy: 0.8392s - loss: 0.4594 - accuracy: 0.83
    Epoch 11/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.2611 - accuracy: 0.9051
    Epoch 12/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.2396 - accuracy: 0.9106
    Epoch 13/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.2515 - accuracy: 0.9096
    Epoch 14/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.2169 - accuracy: 0.9202
    Epoch 15/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.2016 - accuracy: 0.9255
    Epoch 16/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.2025 - accuracy: 0.9261
    Epoch 17/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.1915 - accuracy: 0.9286
    Epoch 18/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.1920 - accuracy: 0.9280
    Epoch 19/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.1875 - accuracy: 0.9286
    Epoch 20/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.1834 - accuracy: 0.9323
    Epoch 21/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.1709 - accuracy: 0.9357
    Epoch 22/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.1656 - accuracy: 0.9370
    Epoch 23/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.1708 - accuracy: 0.9376
    Epoch 24/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.1539 - accuracy: 0.9424
    Epoch 25/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.1517 - accuracy: 0.9430
    Epoch 26/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.1450 - accuracy: 0.9460
    Epoch 27/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.1419 - accuracy: 0.9460
    Epoch 28/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.1399 - accuracy: 0.9479
    Epoch 29/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.1458 - accuracy: 0.9462
    Epoch 30/30
    171/171 [==============================] - 18s 103ms/step - loss: 0.1332 - accuracy: 0.9502
    57/57 [==============================] - 2s 34ms/step - loss: 0.1954 - accuracy: 0.9375
    Model: "sequential_57"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_171 (Conv1D)          (None, 86, 768)           12288     
    _________________________________________________________________
    max_pooling1d_57 (MaxPooling (None, 43, 768)           0         
    _________________________________________________________________
    conv1d_172 (Conv1D)          (None, 41, 768)           1770240   
    _________________________________________________________________
    average_pooling1d_57 (Averag (None, 10, 768)           0         
    _________________________________________________________________
    conv1d_173 (Conv1D)          (None, 6, 768)            2949888   
    _________________________________________________________________
    global_average_pooling1d_57  (None, 768)               0         
    _________________________________________________________________
    dense_171 (Dense)            (None, 512)               393728    
    _________________________________________________________________
    dropout_114 (Dropout)        (None, 512)               0         
    _________________________________________________________________
    dense_172 (Dense)            (None, 256)               131328    
    _________________________________________________________________
    dropout_115 (Dropout)        (None, 256)               0         
    _________________________________________________________________
    dense_173 (Dense)            (None, 6)                 1542      
    =================================================================
    Total params: 5,259,014
    Trainable params: 5,259,014
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 18s 104ms/step - loss: 1.4075 - accuracy: 0.4129
    Epoch 2/30
    171/171 [==============================] - 17s 101ms/step - loss: 1.2049 - accuracy: 0.4960
    Epoch 3/30
    171/171 [==============================] - 17s 101ms/step - loss: 1.0373 - accuracy: 0.5797
    Epoch 4/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.8859 - accuracy: 0.6510
    Epoch 5/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.7834 - accuracy: 0.6985
    Epoch 6/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.7013 - accuracy: 0.7272
    Epoch 7/30
    171/171 [==============================] - 17s 101ms/step - loss: 1.1423 - accuracy: 0.6450
    Epoch 8/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.9406 - accuracy: 0.6272
    Epoch 9/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.6857 - accuracy: 0.7342
    Epoch 10/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.5728 - accuracy: 0.7779
    Epoch 11/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.5391 - accuracy: 0.7912
    Epoch 12/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.5025 - accuracy: 0.8029
    Epoch 13/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.4765 - accuracy: 0.8120
    Epoch 14/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.4551 - accuracy: 0.8184
    Epoch 15/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.4327 - accuracy: 0.8294
    Epoch 16/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.4198 - accuracy: 0.8340
    Epoch 17/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.4111 - accuracy: 0.8385
    Epoch 18/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.4055 - accuracy: 0.8413
    Epoch 19/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.3928 - accuracy: 0.8452
    Epoch 20/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.3664 - accuracy: 0.8531
    Epoch 21/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.3707 - accuracy: 0.8553
    Epoch 22/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.3716 - accuracy: 0.8563
    Epoch 23/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.4097 - accuracy: 0.8455
    Epoch 24/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.3683 - accuracy: 0.8577
    Epoch 25/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.3487 - accuracy: 0.8634
    Epoch 26/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.3194 - accuracy: 0.8739
    Epoch 27/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.3097 - accuracy: 0.8754
    Epoch 28/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.3046 - accuracy: 0.8800s
    Epoch 29/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.2876 - accuracy: 0.8860
    Epoch 30/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.2888 - accuracy: 0.8863
    57/57 [==============================] - 2s 35ms/step - loss: 0.3283 - accuracy: 0.8824
    Model: "sequential_58"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_174 (Conv1D)          (None, 86, 768)           12288     
    _________________________________________________________________
    max_pooling1d_58 (MaxPooling (None, 43, 768)           0         
    _________________________________________________________________
    conv1d_175 (Conv1D)          (None, 41, 768)           1770240   
    _________________________________________________________________
    average_pooling1d_58 (Averag (None, 10, 768)           0         
    _________________________________________________________________
    conv1d_176 (Conv1D)          (None, 6, 768)            2949888   
    _________________________________________________________________
    global_average_pooling1d_58  (None, 768)               0         
    _________________________________________________________________
    dense_174 (Dense)            (None, 512)               393728    
    _________________________________________________________________
    dropout_116 (Dropout)        (None, 512)               0         
    _________________________________________________________________
    dense_175 (Dense)            (None, 256)               131328    
    _________________________________________________________________
    dropout_117 (Dropout)        (None, 256)               0         
    _________________________________________________________________
    dense_176 (Dense)            (None, 6)                 1542      
    =================================================================
    Total params: 5,259,014
    Trainable params: 5,259,014
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 17s 101ms/step - loss: 1.4071 - accuracy: 0.4138
    Epoch 2/30
    171/171 [==============================] - 17s 100ms/step - loss: 1.2465 - accuracy: 0.4787
    Epoch 3/30
    171/171 [==============================] - 17s 101ms/step - loss: 1.0560 - accuracy: 0.5658
    Epoch 4/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.8968 - accuracy: 0.6486
    Epoch 5/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.8146 - accuracy: 0.6824
    Epoch 6/30
    171/171 [==============================] - 17s 100ms/step - loss: 1.4933 - accuracy: 0.4489
    Epoch 7/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.9398 - accuracy: 0.6287
    Epoch 8/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.7405 - accuracy: 0.7152
    Epoch 9/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.6721 - accuracy: 0.7433
    Epoch 10/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.5944 - accuracy: 0.7706
    Epoch 11/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.5570 - accuracy: 0.7833
    Epoch 12/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.5309 - accuracy: 0.7946
    Epoch 13/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.5010 - accuracy: 0.8042
    Epoch 14/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.4865 - accuracy: 0.8116
    Epoch 15/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.4475 - accuracy: 0.8254
    Epoch 16/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.4438 - accuracy: 0.8239
    Epoch 17/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.4412 - accuracy: 0.8304
    Epoch 18/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.4117 - accuracy: 0.8376
    Epoch 19/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.4058 - accuracy: 0.8439
    Epoch 20/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.3910 - accuracy: 0.8467
    Epoch 21/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.3694 - accuracy: 0.8551
    Epoch 22/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.3848 - accuracy: 0.8517
    Epoch 23/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.3633 - accuracy: 0.8603
    Epoch 24/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.3579 - accuracy: 0.8605
    Epoch 25/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.3355 - accuracy: 0.8677
    Epoch 26/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.3438 - accuracy: 0.8669
    Epoch 27/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.3371 - accuracy: 0.8682
    Epoch 28/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.3156 - accuracy: 0.8766
    Epoch 29/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.3211 - accuracy: 0.8749
    Epoch 30/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.3169 - accuracy: 0.8748
    57/57 [==============================] - 2s 32ms/step - loss: 0.3094 - accuracy: 0.8838
    Model: "sequential_59"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_177 (Conv1D)          (None, 86, 768)           12288     
    _________________________________________________________________
    max_pooling1d_59 (MaxPooling (None, 43, 768)           0         
    _________________________________________________________________
    conv1d_178 (Conv1D)          (None, 41, 768)           1770240   
    _________________________________________________________________
    average_pooling1d_59 (Averag (None, 10, 768)           0         
    _________________________________________________________________
    conv1d_179 (Conv1D)          (None, 6, 768)            2949888   
    _________________________________________________________________
    global_average_pooling1d_59  (None, 768)               0         
    _________________________________________________________________
    dense_177 (Dense)            (None, 512)               393728    
    _________________________________________________________________
    dropout_118 (Dropout)        (None, 512)               0         
    _________________________________________________________________
    dense_178 (Dense)            (None, 256)               131328    
    _________________________________________________________________
    dropout_119 (Dropout)        (None, 256)               0         
    _________________________________________________________________
    dense_179 (Dense)            (None, 6)                 1542      
    =================================================================
    Total params: 5,259,014
    Trainable params: 5,259,014
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 18s 104ms/step - loss: 1.4082 - accuracy: 0.4122
    Epoch 2/30
    171/171 [==============================] - 17s 101ms/step - loss: 1.2168 - accuracy: 0.4854
    Epoch 3/30
    171/171 [==============================] - 17s 101ms/step - loss: 1.0851 - accuracy: 0.5574
    Epoch 4/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.9234 - accuracy: 0.6368
    Epoch 5/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.7921 - accuracy: 0.6924
    Epoch 6/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.7177 - accuracy: 0.7219
    Epoch 7/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.6241 - accuracy: 0.7579
    Epoch 8/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.5828 - accuracy: 0.7719
    Epoch 9/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.5559 - accuracy: 0.7816
    Epoch 10/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.5199 - accuracy: 0.7950
    Epoch 11/30
    171/171 [==============================] - 17s 101ms/step - loss: 1.6186 - accuracy: 0.5389
    Epoch 12/30
    171/171 [==============================] - 17s 100ms/step - loss: 1.1816 - accuracy: 0.5027
    Epoch 13/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.8529 - accuracy: 0.6726
    Epoch 14/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.6514 - accuracy: 0.7544
    Epoch 15/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.5576 - accuracy: 0.7853
    Epoch 16/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.5149 - accuracy: 0.7987
    Epoch 17/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.4894 - accuracy: 0.8090
    Epoch 18/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.4600 - accuracy: 0.8220
    Epoch 19/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.4440 - accuracy: 0.8261
    Epoch 20/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.4266 - accuracy: 0.8331
    Epoch 21/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.3984 - accuracy: 0.8450
    Epoch 22/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.3855 - accuracy: 0.8489
    Epoch 23/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.3892 - accuracy: 0.8501
    Epoch 24/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.3656 - accuracy: 0.8582
    Epoch 25/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.3821 - accuracy: 0.8540
    Epoch 26/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.3576 - accuracy: 0.8619
    Epoch 27/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.3453 - accuracy: 0.8647
    Epoch 28/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.3390 - accuracy: 0.8685
    Epoch 29/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.3303 - accuracy: 0.8699
    Epoch 30/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.3253 - accuracy: 0.8713
    57/57 [==============================] - 2s 35ms/step - loss: 0.3663 - accuracy: 0.8614
    Model: "sequential_60"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_180 (Conv1D)          (None, 86, 768)           12288     
    _________________________________________________________________
    max_pooling1d_60 (MaxPooling (None, 43, 768)           0         
    _________________________________________________________________
    conv1d_181 (Conv1D)          (None, 41, 768)           1770240   
    _________________________________________________________________
    average_pooling1d_60 (Averag (None, 10, 768)           0         
    _________________________________________________________________
    conv1d_182 (Conv1D)          (None, 6, 768)            2949888   
    _________________________________________________________________
    global_average_pooling1d_60  (None, 768)               0         
    _________________________________________________________________
    dense_180 (Dense)            (None, 512)               393728    
    _________________________________________________________________
    dropout_120 (Dropout)        (None, 512)               0         
    _________________________________________________________________
    dense_181 (Dense)            (None, 256)               131328    
    _________________________________________________________________
    dropout_121 (Dropout)        (None, 256)               0         
    _________________________________________________________________
    dense_182 (Dense)            (None, 6)                 1542      
    =================================================================
    Total params: 5,259,014
    Trainable params: 5,259,014
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 17s 101ms/step - loss: 1.3947 - accuracy: 0.4153
    Epoch 2/30
    171/171 [==============================] - 17s 100ms/step - loss: 1.2324 - accuracy: 0.4817
    Epoch 3/30
    171/171 [==============================] - 17s 101ms/step - loss: 1.1101 - accuracy: 0.5422
    Epoch 4/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.9650 - accuracy: 0.6129
    Epoch 5/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.8109 - accuracy: 0.6828
    Epoch 6/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.7295 - accuracy: 0.7176
    Epoch 7/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.6520 - accuracy: 0.7493
    Epoch 8/30
    171/171 [==============================] - 17s 101ms/step - loss: 1.0343 - accuracy: 0.6536
    Epoch 9/30
    171/171 [==============================] - 17s 101ms/step - loss: 1.1277 - accuracy: 0.5247
    Epoch 10/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.7301 - accuracy: 0.7171
    Epoch 11/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.5938 - accuracy: 0.7650
    Epoch 12/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.5423 - accuracy: 0.7811
    Epoch 13/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.5018 - accuracy: 0.7994
    Epoch 14/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.4721 - accuracy: 0.8107
    Epoch 15/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.4493 - accuracy: 0.8203
    Epoch 16/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.4561 - accuracy: 0.8196
    Epoch 17/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.4259 - accuracy: 0.8310
    Epoch 18/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.4091 - accuracy: 0.8374
    Epoch 19/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.3879 - accuracy: 0.8451
    Epoch 20/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.3849 - accuracy: 0.8463
    Epoch 21/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.3886 - accuracy: 0.8468
    Epoch 22/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.3601 - accuracy: 0.8560
    Epoch 23/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.3467 - accuracy: 0.8619
    Epoch 24/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.3433 - accuracy: 0.8634
    Epoch 25/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.3350 - accuracy: 0.8667
    Epoch 26/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.3227 - accuracy: 0.8712
    Epoch 27/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.3234 - accuracy: 0.8695
    Epoch 28/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.3161 - accuracy: 0.8728
    Epoch 29/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.3060 - accuracy: 0.8782
    Epoch 30/30
    171/171 [==============================] - 17s 101ms/step - loss: 0.2978 - accuracy: 0.8817
    57/57 [==============================] - 2s 32ms/step - loss: 0.3123 - accuracy: 0.8810
    Model: "sequential_61"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_183 (Conv1D)          (None, 88, 256)           2560      
    _________________________________________________________________
    max_pooling1d_61 (MaxPooling (None, 44, 256)           0         
    _________________________________________________________________
    conv1d_184 (Conv1D)          (None, 40, 512)           655872    
    _________________________________________________________________
    average_pooling1d_61 (Averag (None, 10, 512)           0         
    _________________________________________________________________
    conv1d_185 (Conv1D)          (None, 6, 512)            1311232   
    _________________________________________________________________
    global_average_pooling1d_61  (None, 512)               0         
    _________________________________________________________________
    dense_183 (Dense)            (None, 256)               131328    
    _________________________________________________________________
    dropout_122 (Dropout)        (None, 256)               0         
    _________________________________________________________________
    dense_184 (Dense)            (None, 256)               65792     
    _________________________________________________________________
    dropout_123 (Dropout)        (None, 256)               0         
    _________________________________________________________________
    dense_185 (Dense)            (None, 6)                 1542      
    =================================================================
    Total params: 2,168,326
    Trainable params: 2,168,326
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 7s 41ms/step - loss: 1.1338 - accuracy: 0.5235
    Epoch 2/30
    171/171 [==============================] - 7s 40ms/step - loss: 0.7627 - accuracy: 0.6908
    Epoch 3/30
    171/171 [==============================] - 7s 40ms/step - loss: 0.5642 - accuracy: 0.7897
    Epoch 4/30
    171/171 [==============================] - 7s 40ms/step - loss: 0.4109 - accuracy: 0.8465
    Epoch 5/30
    171/171 [==============================] - 7s 40ms/step - loss: 0.3436 - accuracy: 0.8718
    Epoch 6/30
    171/171 [==============================] - 7s 40ms/step - loss: 0.3269 - accuracy: 0.8783
    Epoch 7/30
    171/171 [==============================] - 7s 39ms/step - loss: 0.2916 - accuracy: 0.8936
    Epoch 8/30
    171/171 [==============================] - 7s 40ms/step - loss: 0.2638 - accuracy: 0.9028
    Epoch 9/30
    171/171 [==============================] - 7s 40ms/step - loss: 0.2456 - accuracy: 0.9085
    Epoch 10/30
    171/171 [==============================] - 7s 39ms/step - loss: 0.2325 - accuracy: 0.9143
    Epoch 11/30
    171/171 [==============================] - 7s 40ms/step - loss: 0.2144 - accuracy: 0.9203
    Epoch 12/30
    171/171 [==============================] - 7s 40ms/step - loss: 0.2144 - accuracy: 0.9213
    Epoch 13/30
    171/171 [==============================] - 7s 40ms/step - loss: 0.2106 - accuracy: 0.9228 0s - loss: 0.2109 - 
    Epoch 14/30
    171/171 [==============================] - 7s 40ms/step - loss: 0.2279 - accuracy: 0.9206
    Epoch 15/30
    171/171 [==============================] - 7s 39ms/step - loss: 0.2037 - accuracy: 0.9270
    Epoch 16/30
    171/171 [==============================] - 7s 39ms/step - loss: 0.1763 - accuracy: 0.9337
    Epoch 17/30
    171/171 [==============================] - 7s 39ms/step - loss: 0.1678 - accuracy: 0.9359
    Epoch 18/30
    171/171 [==============================] - 7s 39ms/step - loss: 0.1585 - accuracy: 0.9403
    Epoch 19/30
    171/171 [==============================] - 7s 40ms/step - loss: 0.1535 - accuracy: 0.9423
    Epoch 20/30
    171/171 [==============================] - 7s 39ms/step - loss: 0.1623 - accuracy: 0.9401
    Epoch 21/30
    171/171 [==============================] - 7s 39ms/step - loss: 0.1475 - accuracy: 0.9447
    Epoch 22/30
    171/171 [==============================] - 7s 39ms/step - loss: 0.1467 - accuracy: 0.9452
    Epoch 23/30
    171/171 [==============================] - 7s 39ms/step - loss: 0.1356 - accuracy: 0.9501
    Epoch 24/30
    171/171 [==============================] - 7s 39ms/step - loss: 0.1320 - accuracy: 0.9512
    Epoch 25/30
    171/171 [==============================] - 7s 39ms/step - loss: 0.1370 - accuracy: 0.9498
    Epoch 26/30
    171/171 [==============================] - 7s 39ms/step - loss: 0.1217 - accuracy: 0.9539
    Epoch 27/30
    171/171 [==============================] - 7s 39ms/step - loss: 0.1230 - accuracy: 0.9534
    Epoch 28/30
    171/171 [==============================] - 7s 39ms/step - loss: 0.1212 - accuracy: 0.9548
    Epoch 29/30
    171/171 [==============================] - 7s 39ms/step - loss: 0.1110 - accuracy: 0.9589
    Epoch 30/30
    171/171 [==============================] - 7s 39ms/step - loss: 0.1139 - accuracy: 0.9575
    57/57 [==============================] - 1s 15ms/step - loss: 0.2227 - accuracy: 0.9333
    Model: "sequential_62"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_186 (Conv1D)          (None, 88, 256)           2560      
    _________________________________________________________________
    max_pooling1d_62 (MaxPooling (None, 44, 256)           0         
    _________________________________________________________________
    conv1d_187 (Conv1D)          (None, 40, 512)           655872    
    _________________________________________________________________
    average_pooling1d_62 (Averag (None, 10, 512)           0         
    _________________________________________________________________
    conv1d_188 (Conv1D)          (None, 6, 512)            1311232   
    _________________________________________________________________
    global_average_pooling1d_62  (None, 512)               0         
    _________________________________________________________________
    dense_186 (Dense)            (None, 256)               131328    
    _________________________________________________________________
    dropout_124 (Dropout)        (None, 256)               0         
    _________________________________________________________________
    dense_187 (Dense)            (None, 256)               65792     
    _________________________________________________________________
    dropout_125 (Dropout)        (None, 256)               0         
    _________________________________________________________________
    dense_188 (Dense)            (None, 6)                 1542      
    =================================================================
    Total params: 2,168,326
    Trainable params: 2,168,326
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
      2/171 [..............................] - ETA: 6s - loss: 1.7804 - accuracy: 0.1562WARNING:tensorflow:Callbacks method `on_train_batch_end` is slow compared to the batch time (batch time: 0.0178s vs `on_train_batch_end` time: 0.0393s). Check your callbacks.
    171/171 [==============================] - 7s 40ms/step - loss: 1.1177 - accuracy: 0.5274
    Epoch 2/30
    171/171 [==============================] - 7s 40ms/step - loss: 0.7863 - accuracy: 0.6839
    Epoch 3/30
    171/171 [==============================] - 7s 40ms/step - loss: 0.5634 - accuracy: 0.7869
    Epoch 4/30
    171/171 [==============================] - 7s 40ms/step - loss: 0.4091 - accuracy: 0.8491
    Epoch 5/30
    171/171 [==============================] - 7s 40ms/step - loss: 0.4068 - accuracy: 0.8535
    Epoch 6/30
    171/171 [==============================] - 7s 40ms/step - loss: 0.3140 - accuracy: 0.8842
    Epoch 7/30
    171/171 [==============================] - 7s 40ms/step - loss: 0.2991 - accuracy: 0.8893 0s - loss:
    Epoch 8/30
    171/171 [==============================] - 7s 39ms/step - loss: 0.2605 - accuracy: 0.9031
    Epoch 9/30
    171/171 [==============================] - 7s 39ms/step - loss: 0.2497 - accuracy: 0.9068
    Epoch 10/30
    171/171 [==============================] - 7s 39ms/step - loss: 0.2371 - accuracy: 0.9129
    Epoch 11/30
    171/171 [==============================] - 7s 40ms/step - loss: 0.2206 - accuracy: 0.9186
    Epoch 12/30
    171/171 [==============================] - 7s 39ms/step - loss: 0.2440 - accuracy: 0.9133
    Epoch 13/30
    171/171 [==============================] - 7s 40ms/step - loss: 0.2045 - accuracy: 0.9252
    Epoch 14/30
    171/171 [==============================] - 7s 39ms/step - loss: 0.1930 - accuracy: 0.9278
    Epoch 15/30
    171/171 [==============================] - 7s 39ms/step - loss: 0.1979 - accuracy: 0.9277
    Epoch 16/30
    171/171 [==============================] - 7s 39ms/step - loss: 0.1819 - accuracy: 0.9332
    Epoch 17/30
    171/171 [==============================] - 7s 39ms/step - loss: 0.1708 - accuracy: 0.9354
    Epoch 18/30
    171/171 [==============================] - 7s 39ms/step - loss: 0.1629 - accuracy: 0.9393
    Epoch 19/30
    171/171 [==============================] - 7s 39ms/step - loss: 0.1911 - accuracy: 0.9331
    Epoch 20/30
    171/171 [==============================] - 7s 39ms/step - loss: 0.1548 - accuracy: 0.9419
    Epoch 21/30
    171/171 [==============================] - 7s 39ms/step - loss: 0.1452 - accuracy: 0.9459
    Epoch 22/30
    171/171 [==============================] - 7s 39ms/step - loss: 0.1440 - accuracy: 0.9463
    Epoch 23/30
    171/171 [==============================] - 7s 39ms/step - loss: 0.1378 - accuracy: 0.9480
    Epoch 24/30
    171/171 [==============================] - 7s 39ms/step - loss: 0.1309 - accuracy: 0.9510
    Epoch 25/30
    171/171 [==============================] - 7s 39ms/step - loss: 0.1369 - accuracy: 0.9492
    Epoch 26/30
    171/171 [==============================] - 7s 39ms/step - loss: 0.1280 - accuracy: 0.9517
    Epoch 27/30
    171/171 [==============================] - 7s 39ms/step - loss: 0.1204 - accuracy: 0.9553
    Epoch 28/30
    171/171 [==============================] - 7s 39ms/step - loss: 0.1187 - accuracy: 0.9554
    Epoch 29/30
    171/171 [==============================] - 7s 39ms/step - loss: 0.1131 - accuracy: 0.9571 0s - loss: 0.1129 - accuracy: 0. - ETA: 0s - loss: 0.1128 - accura
    Epoch 30/30
    171/171 [==============================] - 7s 39ms/step - loss: 0.1171 - accuracy: 0.9573
    57/57 [==============================] - 1s 13ms/step - loss: 0.2334 - accuracy: 0.9352
    Model: "sequential_63"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_189 (Conv1D)          (None, 88, 256)           2560      
    _________________________________________________________________
    max_pooling1d_63 (MaxPooling (None, 44, 256)           0         
    _________________________________________________________________
    conv1d_190 (Conv1D)          (None, 40, 512)           655872    
    _________________________________________________________________
    average_pooling1d_63 (Averag (None, 10, 512)           0         
    _________________________________________________________________
    conv1d_191 (Conv1D)          (None, 6, 512)            1311232   
    _________________________________________________________________
    global_average_pooling1d_63  (None, 512)               0         
    _________________________________________________________________
    dense_189 (Dense)            (None, 256)               131328    
    _________________________________________________________________
    dropout_126 (Dropout)        (None, 256)               0         
    _________________________________________________________________
    dense_190 (Dense)            (None, 256)               65792     
    _________________________________________________________________
    dropout_127 (Dropout)        (None, 256)               0         
    _________________________________________________________________
    dense_191 (Dense)            (None, 6)                 1542      
    =================================================================
    Total params: 2,168,326
    Trainable params: 2,168,326
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 7s 41ms/step - loss: 1.1136 - accuracy: 0.5284 0s - loss: 1.1254 - 
    Epoch 2/30
    171/171 [==============================] - 7s 40ms/step - loss: 0.7527 - accuracy: 0.7003
    Epoch 3/30
    171/171 [==============================] - 7s 40ms/step - loss: 0.5459 - accuracy: 0.7961
    Epoch 4/30
    171/171 [==============================] - 7s 40ms/step - loss: 0.4126 - accuracy: 0.8488
    Epoch 5/30
    171/171 [==============================] - 7s 40ms/step - loss: 0.3462 - accuracy: 0.8711
    Epoch 6/30
    171/171 [==============================] - 7s 40ms/step - loss: 0.3032 - accuracy: 0.8881
    Epoch 7/30
    171/171 [==============================] - 7s 40ms/step - loss: 0.2874 - accuracy: 0.8956
    Epoch 8/30
    171/171 [==============================] - 7s 40ms/step - loss: 0.2684 - accuracy: 0.9015
    Epoch 9/30
    171/171 [==============================] - 7s 40ms/step - loss: 0.2440 - accuracy: 0.9097
    Epoch 10/30
    171/171 [==============================] - 7s 40ms/step - loss: 0.2327 - accuracy: 0.9139
    Epoch 11/30
    171/171 [==============================] - 7s 40ms/step - loss: 0.2133 - accuracy: 0.9203
    Epoch 12/30
    171/171 [==============================] - 7s 40ms/step - loss: 0.2131 - accuracy: 0.9207 0s - loss: 0.2141 - accuracy: 
    Epoch 13/30
    171/171 [==============================] - 7s 40ms/step - loss: 0.1953 - accuracy: 0.9263
    Epoch 14/30
    171/171 [==============================] - 7s 40ms/step - loss: 0.1933 - accuracy: 0.9283
    Epoch 15/30
    171/171 [==============================] - 7s 40ms/step - loss: 0.1814 - accuracy: 0.9333
    Epoch 16/30
    171/171 [==============================] - 7s 40ms/step - loss: 0.1674 - accuracy: 0.9369
    Epoch 17/30
    171/171 [==============================] - 7s 40ms/step - loss: 0.1613 - accuracy: 0.9404
    Epoch 18/30
    171/171 [==============================] - 7s 40ms/step - loss: 0.1574 - accuracy: 0.9418
    Epoch 19/30
    171/171 [==============================] - 7s 40ms/step - loss: 0.1502 - accuracy: 0.9439
    Epoch 20/30
    171/171 [==============================] - 7s 40ms/step - loss: 0.1560 - accuracy: 0.9420
    Epoch 21/30
    171/171 [==============================] - 7s 40ms/step - loss: 0.1401 - accuracy: 0.9482
    Epoch 22/30
    171/171 [==============================] - 7s 40ms/step - loss: 0.1342 - accuracy: 0.9506
    Epoch 23/30
    171/171 [==============================] - 7s 39ms/step - loss: 0.1996 - accuracy: 0.9368
    Epoch 24/30
    171/171 [==============================] - 7s 39ms/step - loss: 0.1392 - accuracy: 0.9482
    Epoch 25/30
    171/171 [==============================] - 7s 39ms/step - loss: 0.1270 - accuracy: 0.9531
    Epoch 26/30
    171/171 [==============================] - 7s 39ms/step - loss: 0.1180 - accuracy: 0.9555
    Epoch 27/30
    171/171 [==============================] - 7s 40ms/step - loss: 0.1131 - accuracy: 0.9572
    Epoch 28/30
    171/171 [==============================] - 7s 39ms/step - loss: 0.1113 - accuracy: 0.9585
    Epoch 29/30
    171/171 [==============================] - 7s 39ms/step - loss: 0.1089 - accuracy: 0.9595
    Epoch 30/30
    171/171 [==============================] - 7s 40ms/step - loss: 0.1063 - accuracy: 0.9600
    57/57 [==============================] - 1s 15ms/step - loss: 0.2577 - accuracy: 0.9266
    Model: "sequential_64"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_192 (Conv1D)          (None, 88, 256)           2560      
    _________________________________________________________________
    max_pooling1d_64 (MaxPooling (None, 44, 256)           0         
    _________________________________________________________________
    conv1d_193 (Conv1D)          (None, 40, 512)           655872    
    _________________________________________________________________
    average_pooling1d_64 (Averag (None, 10, 512)           0         
    _________________________________________________________________
    conv1d_194 (Conv1D)          (None, 6, 512)            1311232   
    _________________________________________________________________
    global_average_pooling1d_64  (None, 512)               0         
    _________________________________________________________________
    dense_192 (Dense)            (None, 256)               131328    
    _________________________________________________________________
    dropout_128 (Dropout)        (None, 256)               0         
    _________________________________________________________________
    dense_193 (Dense)            (None, 256)               65792     
    _________________________________________________________________
    dropout_129 (Dropout)        (None, 256)               0         
    _________________________________________________________________
    dense_194 (Dense)            (None, 6)                 1542      
    =================================================================
    Total params: 2,168,326
    Trainable params: 2,168,326
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 7s 40ms/step - loss: 1.1391 - accuracy: 0.5228
    Epoch 2/30
    171/171 [==============================] - 7s 40ms/step - loss: 0.8043 - accuracy: 0.6804
    Epoch 3/30
    171/171 [==============================] - 7s 40ms/step - loss: 0.6143 - accuracy: 0.7695
    Epoch 4/30
    171/171 [==============================] - 7s 40ms/step - loss: 0.4480 - accuracy: 0.8363
    Epoch 5/30
    171/171 [==============================] - 7s 40ms/step - loss: 0.3537 - accuracy: 0.8700
    Epoch 6/30
    171/171 [==============================] - 7s 40ms/step - loss: 0.3158 - accuracy: 0.8830
    Epoch 7/30
    171/171 [==============================] - 7s 40ms/step - loss: 0.2838 - accuracy: 0.8945
    Epoch 8/30
    171/171 [==============================] - 7s 40ms/step - loss: 0.2775 - accuracy: 0.8997
    Epoch 9/30
    171/171 [==============================] - 7s 40ms/step - loss: 0.2440 - accuracy: 0.9097
    Epoch 10/30
    171/171 [==============================] - 7s 40ms/step - loss: 0.2345 - accuracy: 0.9146
    Epoch 11/30
    171/171 [==============================] - 7s 40ms/step - loss: 0.3864 - accuracy: 0.8728 1s
    Epoch 12/30
    171/171 [==============================] - 7s 39ms/step - loss: 0.2318 - accuracy: 0.9169
    Epoch 13/30
    171/171 [==============================] - 7s 39ms/step - loss: 0.2054 - accuracy: 0.9247
    Epoch 14/30
    171/171 [==============================] - 7s 40ms/step - loss: 0.1960 - accuracy: 0.9293
    Epoch 15/30
    171/171 [==============================] - 7s 39ms/step - loss: 0.1838 - accuracy: 0.9324
    Epoch 16/30
    171/171 [==============================] - 7s 40ms/step - loss: 0.1797 - accuracy: 0.9345
    Epoch 17/30
    171/171 [==============================] - 7s 40ms/step - loss: 0.1717 - accuracy: 0.9371
    Epoch 18/30
    171/171 [==============================] - 7s 39ms/step - loss: 0.1649 - accuracy: 0.9372
    Epoch 19/30
    171/171 [==============================] - 7s 39ms/step - loss: 0.1595 - accuracy: 0.9404
    Epoch 20/30
    171/171 [==============================] - 7s 39ms/step - loss: 0.1566 - accuracy: 0.9425
    Epoch 21/30
    171/171 [==============================] - 7s 39ms/step - loss: 0.1653 - accuracy: 0.9407
    Epoch 22/30
    171/171 [==============================] - 7s 40ms/step - loss: 0.1438 - accuracy: 0.9457
    Epoch 23/30
    171/171 [==============================] - 7s 39ms/step - loss: 0.1359 - accuracy: 0.9486
    Epoch 24/30
    171/171 [==============================] - 7s 40ms/step - loss: 0.1358 - accuracy: 0.9492
    Epoch 25/30
    171/171 [==============================] - 7s 39ms/step - loss: 0.1422 - accuracy: 0.9487
    Epoch 26/30
    171/171 [==============================] - 7s 39ms/step - loss: 0.1244 - accuracy: 0.9537
    Epoch 27/30
    171/171 [==============================] - 7s 40ms/step - loss: 0.1203 - accuracy: 0.9545
    Epoch 28/30
    171/171 [==============================] - 7s 40ms/step - loss: 0.1189 - accuracy: 0.9554
    Epoch 29/30
    171/171 [==============================] - 7s 39ms/step - loss: 0.1187 - accuracy: 0.9558
    Epoch 30/30
    171/171 [==============================] - 7s 39ms/step - loss: 0.1095 - accuracy: 0.9597
    57/57 [==============================] - 1s 13ms/step - loss: 0.2185 - accuracy: 0.9395
    Model: "sequential_65"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_195 (Conv1D)          (None, 86, 256)           4096      
    _________________________________________________________________
    max_pooling1d_65 (MaxPooling (None, 21, 256)           0         
    _________________________________________________________________
    conv1d_196 (Conv1D)          (None, 17, 512)           655872    
    _________________________________________________________________
    average_pooling1d_65 (Averag (None, 8, 512)            0         
    _________________________________________________________________
    conv1d_197 (Conv1D)          (None, 4, 768)            1966848   
    _________________________________________________________________
    global_average_pooling1d_65  (None, 768)               0         
    _________________________________________________________________
    dense_195 (Dense)            (None, 512)               393728    
    _________________________________________________________________
    dropout_130 (Dropout)        (None, 512)               0         
    _________________________________________________________________
    dense_196 (Dense)            (None, 512)               262656    
    _________________________________________________________________
    dropout_131 (Dropout)        (None, 512)               0         
    _________________________________________________________________
    dense_197 (Dense)            (None, 6)                 3078      
    =================================================================
    Total params: 3,286,278
    Trainable params: 3,286,278
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
      1/171 [..............................] - ETA: 2s - loss: 1.8040 - accuracy: 0.1484WARNING:tensorflow:Callbacks method `on_train_batch_end` is slow compared to the batch time (batch time: 0.0051s vs `on_train_batch_end` time: 0.0340s). Check your callbacks.
    171/171 [==============================] - 6s 37ms/step - loss: 1.4455 - accuracy: 0.4295
    Epoch 2/30
    171/171 [==============================] - 6s 34ms/step - loss: 1.1203 - accuracy: 0.5399
    Epoch 3/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.9748 - accuracy: 0.6052
    Epoch 4/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.8461 - accuracy: 0.6644
    Epoch 5/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.7769 - accuracy: 0.6962
    Epoch 6/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.6960 - accuracy: 0.7301
    Epoch 7/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.6666 - accuracy: 0.7372
    Epoch 8/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.5977 - accuracy: 0.7628
    Epoch 9/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.5929 - accuracy: 0.7646
    Epoch 10/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.5537 - accuracy: 0.7772
    Epoch 11/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.5200 - accuracy: 0.7900
    Epoch 12/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.4990 - accuracy: 0.7960
    Epoch 13/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.4956 - accuracy: 0.7988
    Epoch 14/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.4570 - accuracy: 0.8152
    Epoch 15/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.4359 - accuracy: 0.8261
    Epoch 16/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.4372 - accuracy: 0.8275
    Epoch 17/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.4078 - accuracy: 0.8373
    Epoch 18/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.3817 - accuracy: 0.8484
    Epoch 19/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.3703 - accuracy: 0.8526
    Epoch 20/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.3630 - accuracy: 0.8562
    Epoch 21/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.3517 - accuracy: 0.8587
    Epoch 22/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.3735 - accuracy: 0.8559
    Epoch 23/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.3362 - accuracy: 0.8668
    Epoch 24/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.3130 - accuracy: 0.8754
    Epoch 25/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.3030 - accuracy: 0.8785
    Epoch 26/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.2970 - accuracy: 0.8815
    Epoch 27/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.2889 - accuracy: 0.8859
    Epoch 28/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.2810 - accuracy: 0.8876 0s - loss: 0.2781 
    Epoch 29/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.2696 - accuracy: 0.8930
    Epoch 30/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.2618 - accuracy: 0.8963
    57/57 [==============================] - 1s 12ms/step - loss: 0.3413 - accuracy: 0.8803
    Model: "sequential_66"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_198 (Conv1D)          (None, 86, 256)           4096      
    _________________________________________________________________
    max_pooling1d_66 (MaxPooling (None, 21, 256)           0         
    _________________________________________________________________
    conv1d_199 (Conv1D)          (None, 17, 512)           655872    
    _________________________________________________________________
    average_pooling1d_66 (Averag (None, 8, 512)            0         
    _________________________________________________________________
    conv1d_200 (Conv1D)          (None, 4, 768)            1966848   
    _________________________________________________________________
    global_average_pooling1d_66  (None, 768)               0         
    _________________________________________________________________
    dense_198 (Dense)            (None, 512)               393728    
    _________________________________________________________________
    dropout_132 (Dropout)        (None, 512)               0         
    _________________________________________________________________
    dense_199 (Dense)            (None, 512)               262656    
    _________________________________________________________________
    dropout_133 (Dropout)        (None, 512)               0         
    _________________________________________________________________
    dense_200 (Dense)            (None, 6)                 3078      
    =================================================================
    Total params: 3,286,278
    Trainable params: 3,286,278
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 6s 34ms/step - loss: 1.3573 - accuracy: 0.4334
    Epoch 2/30
    171/171 [==============================] - 6s 34ms/step - loss: 1.1354 - accuracy: 0.5299
    Epoch 3/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.9756 - accuracy: 0.6108
    Epoch 4/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.8307 - accuracy: 0.6770
    Epoch 5/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.7308 - accuracy: 0.7150
    Epoch 6/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.6771 - accuracy: 0.7360
    Epoch 7/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.6308 - accuracy: 0.7525
    Epoch 8/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.6494 - accuracy: 0.7495
    Epoch 9/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.5478 - accuracy: 0.7813
    Epoch 10/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.5294 - accuracy: 0.7893
    Epoch 11/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.4890 - accuracy: 0.8012
    Epoch 12/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.4820 - accuracy: 0.8073
    Epoch 13/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.4501 - accuracy: 0.8167
    Epoch 14/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.4396 - accuracy: 0.8213
    Epoch 15/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.8727 - accuracy: 0.7297
    Epoch 16/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.9233 - accuracy: 0.6272
    Epoch 17/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.5525 - accuracy: 0.7807
    Epoch 18/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.4842 - accuracy: 0.8031
    Epoch 19/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.4403 - accuracy: 0.8192
    Epoch 20/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.4145 - accuracy: 0.8285
    Epoch 21/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.4095 - accuracy: 0.8351
    Epoch 22/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.3831 - accuracy: 0.8443
    Epoch 23/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.3722 - accuracy: 0.8493
    Epoch 24/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.3538 - accuracy: 0.8568
    Epoch 25/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.3464 - accuracy: 0.8604
    Epoch 26/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.3318 - accuracy: 0.8650
    Epoch 27/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.3231 - accuracy: 0.8687
    Epoch 28/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.3159 - accuracy: 0.8706
    Epoch 29/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.3078 - accuracy: 0.8758
    Epoch 30/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.3029 - accuracy: 0.8777
    57/57 [==============================] - 1s 10ms/step - loss: 0.3582 - accuracy: 0.8713
    Model: "sequential_67"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_201 (Conv1D)          (None, 86, 256)           4096      
    _________________________________________________________________
    max_pooling1d_67 (MaxPooling (None, 21, 256)           0         
    _________________________________________________________________
    conv1d_202 (Conv1D)          (None, 17, 512)           655872    
    _________________________________________________________________
    average_pooling1d_67 (Averag (None, 8, 512)            0         
    _________________________________________________________________
    conv1d_203 (Conv1D)          (None, 4, 768)            1966848   
    _________________________________________________________________
    global_average_pooling1d_67  (None, 768)               0         
    _________________________________________________________________
    dense_201 (Dense)            (None, 512)               393728    
    _________________________________________________________________
    dropout_134 (Dropout)        (None, 512)               0         
    _________________________________________________________________
    dense_202 (Dense)            (None, 512)               262656    
    _________________________________________________________________
    dropout_135 (Dropout)        (None, 512)               0         
    _________________________________________________________________
    dense_203 (Dense)            (None, 6)                 3078      
    =================================================================
    Total params: 3,286,278
    Trainable params: 3,286,278
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 6s 37ms/step - loss: 1.3395 - accuracy: 0.4389
    Epoch 2/30
    171/171 [==============================] - 6s 34ms/step - loss: 1.1246 - accuracy: 0.5343
    Epoch 3/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.9914 - accuracy: 0.6027
    Epoch 4/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.8182 - accuracy: 0.6771
    Epoch 5/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.7485 - accuracy: 0.7113
    Epoch 6/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.6827 - accuracy: 0.7337
    Epoch 7/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.6577 - accuracy: 0.7458
    Epoch 8/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.5920 - accuracy: 0.7697
    Epoch 9/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.6530 - accuracy: 0.7516
    Epoch 10/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.5410 - accuracy: 0.7849
    Epoch 11/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.5077 - accuracy: 0.7939
    Epoch 12/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.4906 - accuracy: 0.8022
    Epoch 13/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.4602 - accuracy: 0.8124
    Epoch 14/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.4809 - accuracy: 0.8078
    Epoch 15/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.4442 - accuracy: 0.8203
    Epoch 16/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.4138 - accuracy: 0.8322
    Epoch 17/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.4152 - accuracy: 0.8352
    Epoch 18/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.3872 - accuracy: 0.8457
    Epoch 19/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.3711 - accuracy: 0.8496
    Epoch 20/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.3544 - accuracy: 0.8572
    Epoch 21/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.3538 - accuracy: 0.8598
    Epoch 22/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.3306 - accuracy: 0.8670
    Epoch 23/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.3221 - accuracy: 0.8700
    Epoch 24/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.3130 - accuracy: 0.8757
    Epoch 25/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.3016 - accuracy: 0.8777
    Epoch 26/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.2863 - accuracy: 0.8829
    Epoch 27/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.3807 - accuracy: 0.8598
    Epoch 28/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.3089 - accuracy: 0.8781
    Epoch 29/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.2679 - accuracy: 0.8930
    Epoch 30/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.2599 - accuracy: 0.8963
    57/57 [==============================] - 1s 13ms/step - loss: 0.3602 - accuracy: 0.8851
    Model: "sequential_68"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_204 (Conv1D)          (None, 86, 256)           4096      
    _________________________________________________________________
    max_pooling1d_68 (MaxPooling (None, 21, 256)           0         
    _________________________________________________________________
    conv1d_205 (Conv1D)          (None, 17, 512)           655872    
    _________________________________________________________________
    average_pooling1d_68 (Averag (None, 8, 512)            0         
    _________________________________________________________________
    conv1d_206 (Conv1D)          (None, 4, 768)            1966848   
    _________________________________________________________________
    global_average_pooling1d_68  (None, 768)               0         
    _________________________________________________________________
    dense_204 (Dense)            (None, 512)               393728    
    _________________________________________________________________
    dropout_136 (Dropout)        (None, 512)               0         
    _________________________________________________________________
    dense_205 (Dense)            (None, 512)               262656    
    _________________________________________________________________
    dropout_137 (Dropout)        (None, 512)               0         
    _________________________________________________________________
    dense_206 (Dense)            (None, 6)                 3078      
    =================================================================
    Total params: 3,286,278
    Trainable params: 3,286,278
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 6s 34ms/step - loss: 1.3283 - accuracy: 0.4409
    Epoch 2/30
    171/171 [==============================] - 6s 34ms/step - loss: 1.1195 - accuracy: 0.5300
    Epoch 3/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.9986 - accuracy: 0.5943
    Epoch 4/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.8551 - accuracy: 0.6657
    Epoch 5/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.7826 - accuracy: 0.6978
    Epoch 6/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.6945 - accuracy: 0.7277
    Epoch 7/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.6443 - accuracy: 0.7465
    Epoch 8/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.6127 - accuracy: 0.7594
    Epoch 9/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.5729 - accuracy: 0.7711
    Epoch 10/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.5588 - accuracy: 0.7783
    Epoch 11/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.5071 - accuracy: 0.7932
    Epoch 12/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.4800 - accuracy: 0.8047
    Epoch 13/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.4768 - accuracy: 0.8054
    Epoch 14/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.4504 - accuracy: 0.8121
    Epoch 15/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.4305 - accuracy: 0.8234
    Epoch 16/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.4115 - accuracy: 0.8306
    Epoch 17/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.3958 - accuracy: 0.8374
    Epoch 18/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.4902 - accuracy: 0.8087
    Epoch 19/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.3725 - accuracy: 0.8473
    Epoch 20/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.3513 - accuracy: 0.8582
    Epoch 21/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.3360 - accuracy: 0.8631 1s -
    Epoch 22/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.3222 - accuracy: 0.8677
    Epoch 23/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.3961 - accuracy: 0.8461
    Epoch 24/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.3141 - accuracy: 0.8733
    Epoch 25/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.2968 - accuracy: 0.8789
    Epoch 26/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.2857 - accuracy: 0.8854
    Epoch 27/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.2788 - accuracy: 0.8890
    Epoch 28/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.2722 - accuracy: 0.8909
    Epoch 29/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.2631 - accuracy: 0.8943
    Epoch 30/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.2568 - accuracy: 0.8979
    57/57 [==============================] - 1s 10ms/step - loss: 0.3356 - accuracy: 0.8859
    Model: "sequential_69"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_207 (Conv1D)          (None, 86, 512)           8192      
    _________________________________________________________________
    max_pooling1d_69 (MaxPooling (None, 43, 512)           0         
    _________________________________________________________________
    conv1d_208 (Conv1D)          (None, 41, 512)           786944    
    _________________________________________________________________
    average_pooling1d_69 (Averag (None, 20, 512)           0         
    _________________________________________________________________
    conv1d_209 (Conv1D)          (None, 18, 256)           393472    
    _________________________________________________________________
    global_average_pooling1d_69  (None, 256)               0         
    _________________________________________________________________
    dense_207 (Dense)            (None, 512)               131584    
    _________________________________________________________________
    dropout_138 (Dropout)        (None, 512)               0         
    _________________________________________________________________
    dense_208 (Dense)            (None, 256)               131328    
    _________________________________________________________________
    dropout_139 (Dropout)        (None, 256)               0         
    _________________________________________________________________
    dense_209 (Dense)            (None, 6)                 1542      
    =================================================================
    Total params: 1,453,062
    Trainable params: 1,453,062
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 9s 51ms/step - loss: 1.3481 - accuracy: 0.4242
    Epoch 2/30
    171/171 [==============================] - 9s 50ms/step - loss: 1.1307 - accuracy: 0.5225
    Epoch 3/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.9421 - accuracy: 0.6227
    Epoch 4/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.8324 - accuracy: 0.6784
    Epoch 5/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.7471 - accuracy: 0.7116
    Epoch 6/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.7090 - accuracy: 0.7238
    Epoch 7/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.6596 - accuracy: 0.7458
    Epoch 8/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.6237 - accuracy: 0.7564
    Epoch 9/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.6078 - accuracy: 0.7657
    Epoch 10/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.5606 - accuracy: 0.7806
    Epoch 11/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.5365 - accuracy: 0.7884
    Epoch 12/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.5188 - accuracy: 0.7949
    Epoch 13/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.6321 - accuracy: 0.7596
    Epoch 14/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.4907 - accuracy: 0.8013
    Epoch 15/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.5405 - accuracy: 0.7901
    Epoch 16/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.4734 - accuracy: 0.8081
    Epoch 17/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.4615 - accuracy: 0.8120
    Epoch 18/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.4705 - accuracy: 0.8115
    Epoch 19/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.4298 - accuracy: 0.8236
    Epoch 20/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.4282 - accuracy: 0.8259
    Epoch 21/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.4119 - accuracy: 0.8325
    Epoch 22/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.4128 - accuracy: 0.8329
    Epoch 23/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.4052 - accuracy: 0.8356
    Epoch 24/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.4163 - accuracy: 0.8339
    Epoch 25/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.3792 - accuracy: 0.8460
    Epoch 26/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.3720 - accuracy: 0.8510
    Epoch 27/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.3638 - accuracy: 0.8541
    Epoch 28/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.3799 - accuracy: 0.8518
    Epoch 29/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.3561 - accuracy: 0.8580
    Epoch 30/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.3453 - accuracy: 0.8621
    57/57 [==============================] - 1s 18ms/step - loss: 0.3434 - accuracy: 0.8657
    Model: "sequential_70"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_210 (Conv1D)          (None, 86, 512)           8192      
    _________________________________________________________________
    max_pooling1d_70 (MaxPooling (None, 43, 512)           0         
    _________________________________________________________________
    conv1d_211 (Conv1D)          (None, 41, 512)           786944    
    _________________________________________________________________
    average_pooling1d_70 (Averag (None, 20, 512)           0         
    _________________________________________________________________
    conv1d_212 (Conv1D)          (None, 18, 256)           393472    
    _________________________________________________________________
    global_average_pooling1d_70  (None, 256)               0         
    _________________________________________________________________
    dense_210 (Dense)            (None, 512)               131584    
    _________________________________________________________________
    dropout_140 (Dropout)        (None, 512)               0         
    _________________________________________________________________
    dense_211 (Dense)            (None, 256)               131328    
    _________________________________________________________________
    dropout_141 (Dropout)        (None, 256)               0         
    _________________________________________________________________
    dense_212 (Dense)            (None, 6)                 1542      
    =================================================================
    Total params: 1,453,062
    Trainable params: 1,453,062
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 9s 50ms/step - loss: 1.3506 - accuracy: 0.4259
    Epoch 2/30
    171/171 [==============================] - 9s 51ms/step - loss: 1.1427 - accuracy: 0.5183
    Epoch 3/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.9634 - accuracy: 0.6171
    Epoch 4/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.8222 - accuracy: 0.6836
    Epoch 5/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.7620 - accuracy: 0.7043
    Epoch 6/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.7116 - accuracy: 0.7241
    Epoch 7/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.6693 - accuracy: 0.7408
    Epoch 8/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.6310 - accuracy: 0.7563
    Epoch 9/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.5954 - accuracy: 0.7703
    Epoch 10/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.5887 - accuracy: 0.7734
    Epoch 11/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.5612 - accuracy: 0.7816
    Epoch 12/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.5295 - accuracy: 0.7928
    Epoch 13/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.5304 - accuracy: 0.7894
    Epoch 14/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.4912 - accuracy: 0.8034
    Epoch 15/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.5034 - accuracy: 0.7998
    Epoch 16/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.4877 - accuracy: 0.8040
    Epoch 17/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.4574 - accuracy: 0.8145
    Epoch 18/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.4603 - accuracy: 0.8124
    Epoch 19/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.4482 - accuracy: 0.8179
    Epoch 20/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.4281 - accuracy: 0.8258
    Epoch 21/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.4447 - accuracy: 0.8194
    Epoch 22/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.4161 - accuracy: 0.8289
    Epoch 23/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.4071 - accuracy: 0.8338
    Epoch 24/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.4410 - accuracy: 0.8251
    Epoch 25/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.3990 - accuracy: 0.8390
    Epoch 26/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.3822 - accuracy: 0.8465
    Epoch 27/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.3819 - accuracy: 0.8465
    Epoch 28/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.3715 - accuracy: 0.8514
    Epoch 29/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.3577 - accuracy: 0.8577
    Epoch 30/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.3730 - accuracy: 0.8532
    57/57 [==============================] - 1s 18ms/step - loss: 0.3557 - accuracy: 0.8631
    Model: "sequential_71"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_213 (Conv1D)          (None, 86, 512)           8192      
    _________________________________________________________________
    max_pooling1d_71 (MaxPooling (None, 43, 512)           0         
    _________________________________________________________________
    conv1d_214 (Conv1D)          (None, 41, 512)           786944    
    _________________________________________________________________
    average_pooling1d_71 (Averag (None, 20, 512)           0         
    _________________________________________________________________
    conv1d_215 (Conv1D)          (None, 18, 256)           393472    
    _________________________________________________________________
    global_average_pooling1d_71  (None, 256)               0         
    _________________________________________________________________
    dense_213 (Dense)            (None, 512)               131584    
    _________________________________________________________________
    dropout_142 (Dropout)        (None, 512)               0         
    _________________________________________________________________
    dense_214 (Dense)            (None, 256)               131328    
    _________________________________________________________________
    dropout_143 (Dropout)        (None, 256)               0         
    _________________________________________________________________
    dense_215 (Dense)            (None, 6)                 1542      
    =================================================================
    Total params: 1,453,062
    Trainable params: 1,453,062
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 9s 51ms/step - loss: 1.3411 - accuracy: 0.4309
    Epoch 2/30
    171/171 [==============================] - 9s 50ms/step - loss: 1.1454 - accuracy: 0.5182
    Epoch 3/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.9587 - accuracy: 0.6220
    Epoch 4/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.8286 - accuracy: 0.6816
    Epoch 5/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.7516 - accuracy: 0.7136
    Epoch 6/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.6965 - accuracy: 0.7321
    Epoch 7/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.6492 - accuracy: 0.7505
    Epoch 8/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.6227 - accuracy: 0.7598
    Epoch 9/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.6020 - accuracy: 0.7677
    Epoch 10/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.5668 - accuracy: 0.7827
    Epoch 11/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.5326 - accuracy: 0.7911
    Epoch 12/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.5218 - accuracy: 0.7941
    Epoch 13/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.5006 - accuracy: 0.8002
    Epoch 14/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.4841 - accuracy: 0.8072
    Epoch 15/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.4957 - accuracy: 0.8044
    Epoch 16/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.4617 - accuracy: 0.8144
    Epoch 17/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.4570 - accuracy: 0.8172
    Epoch 18/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.4347 - accuracy: 0.8281
    Epoch 19/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.4296 - accuracy: 0.8294
    Epoch 20/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.4372 - accuracy: 0.8296
    Epoch 21/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.4077 - accuracy: 0.8370
    Epoch 22/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.4957 - accuracy: 0.8135
    Epoch 23/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.4190 - accuracy: 0.8368
    Epoch 24/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.4059 - accuracy: 0.8422
    Epoch 25/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.3855 - accuracy: 0.8482 0s - loss: 0.3866 
    Epoch 26/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.4114 - accuracy: 0.8414
    Epoch 27/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.3762 - accuracy: 0.8530
    Epoch 28/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.3604 - accuracy: 0.8581
    Epoch 29/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.3657 - accuracy: 0.8587
    Epoch 30/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.3468 - accuracy: 0.8633
    57/57 [==============================] - 1s 18ms/step - loss: 0.3574 - accuracy: 0.8646
    Model: "sequential_72"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_216 (Conv1D)          (None, 86, 512)           8192      
    _________________________________________________________________
    max_pooling1d_72 (MaxPooling (None, 43, 512)           0         
    _________________________________________________________________
    conv1d_217 (Conv1D)          (None, 41, 512)           786944    
    _________________________________________________________________
    average_pooling1d_72 (Averag (None, 20, 512)           0         
    _________________________________________________________________
    conv1d_218 (Conv1D)          (None, 18, 256)           393472    
    _________________________________________________________________
    global_average_pooling1d_72  (None, 256)               0         
    _________________________________________________________________
    dense_216 (Dense)            (None, 512)               131584    
    _________________________________________________________________
    dropout_144 (Dropout)        (None, 512)               0         
    _________________________________________________________________
    dense_217 (Dense)            (None, 256)               131328    
    _________________________________________________________________
    dropout_145 (Dropout)        (None, 256)               0         
    _________________________________________________________________
    dense_218 (Dense)            (None, 6)                 1542      
    =================================================================
    Total params: 1,453,062
    Trainable params: 1,453,062
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 9s 50ms/step - loss: 1.3423 - accuracy: 0.4282
    Epoch 2/30
    171/171 [==============================] - 9s 50ms/step - loss: 1.1621 - accuracy: 0.5117
    Epoch 3/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.9523 - accuracy: 0.6203
    Epoch 4/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.8402 - accuracy: 0.6753
    Epoch 5/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.7578 - accuracy: 0.7091
    Epoch 6/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.7057 - accuracy: 0.7276
    Epoch 7/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.6534 - accuracy: 0.7475
    Epoch 8/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.6364 - accuracy: 0.7549
    Epoch 9/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.5976 - accuracy: 0.7689 0s - loss: 0.5980 - accura
    Epoch 10/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.5689 - accuracy: 0.7782
    Epoch 11/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.5436 - accuracy: 0.7865
    Epoch 12/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.5155 - accuracy: 0.7960
    Epoch 13/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.5108 - accuracy: 0.7967
    Epoch 14/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.4914 - accuracy: 0.8030
    Epoch 15/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.4774 - accuracy: 0.8075
    Epoch 16/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.4685 - accuracy: 0.8107
    Epoch 17/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.4923 - accuracy: 0.8035
    Epoch 18/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.4551 - accuracy: 0.8161
    Epoch 19/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.4428 - accuracy: 0.8196
    Epoch 20/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.4283 - accuracy: 0.8224
    Epoch 21/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.4294 - accuracy: 0.8239
    Epoch 22/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.4199 - accuracy: 0.8290
    Epoch 23/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.4020 - accuracy: 0.8369
    Epoch 24/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.3960 - accuracy: 0.8390
    Epoch 25/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.4027 - accuracy: 0.8399
    Epoch 26/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.3782 - accuracy: 0.8469
    Epoch 27/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.3806 - accuracy: 0.8462
    Epoch 28/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.3940 - accuracy: 0.8439
    Epoch 29/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.3660 - accuracy: 0.8540
    Epoch 30/30
    171/171 [==============================] - 9s 50ms/step - loss: 0.3560 - accuracy: 0.8561
    57/57 [==============================] - 1s 18ms/step - loss: 0.3445 - accuracy: 0.8707
    Model: "sequential_73"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_219 (Conv1D)          (None, 88, 256)           2560      
    _________________________________________________________________
    max_pooling1d_73 (MaxPooling (None, 22, 256)           0         
    _________________________________________________________________
    conv1d_220 (Conv1D)          (None, 20, 768)           590592    
    _________________________________________________________________
    average_pooling1d_73 (Averag (None, 5, 768)            0         
    _________________________________________________________________
    conv1d_221 (Conv1D)          (None, 3, 256)            590080    
    _________________________________________________________________
    global_average_pooling1d_73  (None, 256)               0         
    _________________________________________________________________
    dense_219 (Dense)            (None, 512)               131584    
    _________________________________________________________________
    dropout_146 (Dropout)        (None, 512)               0         
    _________________________________________________________________
    dense_220 (Dense)            (None, 256)               131328    
    _________________________________________________________________
    dropout_147 (Dropout)        (None, 256)               0         
    _________________________________________________________________
    dense_221 (Dense)            (None, 6)                 1542      
    =================================================================
    Total params: 1,447,686
    Trainable params: 1,447,686
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 5s 27ms/step - loss: 1.1231 - accuracy: 0.5225
    Epoch 2/30
    171/171 [==============================] - 4s 25ms/step - loss: 0.7654 - accuracy: 0.6914
    Epoch 3/30
    171/171 [==============================] - 4s 24ms/step - loss: 0.5356 - accuracy: 0.8012
    Epoch 4/30
    171/171 [==============================] - 4s 24ms/step - loss: 0.4143 - accuracy: 0.8480
    Epoch 5/30
    171/171 [==============================] - 4s 24ms/step - loss: 0.3448 - accuracy: 0.8720
    Epoch 6/30
    171/171 [==============================] - 4s 24ms/step - loss: 0.3309 - accuracy: 0.8774
    Epoch 7/30
    171/171 [==============================] - 4s 24ms/step - loss: 0.2827 - accuracy: 0.8926
    Epoch 8/30
    171/171 [==============================] - 4s 24ms/step - loss: 0.2640 - accuracy: 0.9013
    Epoch 9/30
    171/171 [==============================] - 4s 25ms/step - loss: 0.2500 - accuracy: 0.9059
    Epoch 10/30
    171/171 [==============================] - 4s 24ms/step - loss: 0.2529 - accuracy: 0.9073
    Epoch 11/30
    171/171 [==============================] - 4s 24ms/step - loss: 0.2194 - accuracy: 0.9189
    Epoch 12/30
    171/171 [==============================] - 4s 24ms/step - loss: 0.2062 - accuracy: 0.9217
    Epoch 13/30
    171/171 [==============================] - 4s 24ms/step - loss: 0.2210 - accuracy: 0.9189
    Epoch 14/30
    171/171 [==============================] - 4s 24ms/step - loss: 0.2064 - accuracy: 0.9250
    Epoch 15/30
    171/171 [==============================] - 4s 24ms/step - loss: 0.1900 - accuracy: 0.9298
    Epoch 16/30
    171/171 [==============================] - 4s 24ms/step - loss: 0.1759 - accuracy: 0.9342
    Epoch 17/30
    171/171 [==============================] - 4s 24ms/step - loss: 0.1673 - accuracy: 0.9353
    Epoch 18/30
    171/171 [==============================] - 4s 24ms/step - loss: 0.1706 - accuracy: 0.9380
    Epoch 19/30
    171/171 [==============================] - 4s 25ms/step - loss: 0.1706 - accuracy: 0.9393
    Epoch 20/30
    171/171 [==============================] - 4s 24ms/step - loss: 0.1606 - accuracy: 0.9405
    Epoch 21/30
    171/171 [==============================] - 4s 24ms/step - loss: 0.1469 - accuracy: 0.9453
    Epoch 22/30
    171/171 [==============================] - 4s 24ms/step - loss: 0.1623 - accuracy: 0.9423
    Epoch 23/30
    171/171 [==============================] - 4s 24ms/step - loss: 0.1373 - accuracy: 0.9495
    Epoch 24/30
    171/171 [==============================] - 4s 24ms/step - loss: 0.1293 - accuracy: 0.9516
    Epoch 25/30
    171/171 [==============================] - 4s 24ms/step - loss: 0.1246 - accuracy: 0.9535
    Epoch 26/30
    171/171 [==============================] - 4s 24ms/step - loss: 0.1197 - accuracy: 0.9559
    Epoch 27/30
    171/171 [==============================] - 4s 24ms/step - loss: 0.1224 - accuracy: 0.9554
    Epoch 28/30
    171/171 [==============================] - 4s 24ms/step - loss: 0.1161 - accuracy: 0.9576
    Epoch 29/30
    171/171 [==============================] - 4s 24ms/step - loss: 0.1116 - accuracy: 0.9589
    Epoch 30/30
    171/171 [==============================] - 4s 24ms/step - loss: 0.1090 - accuracy: 0.9599
    57/57 [==============================] - 1s 12ms/step - loss: 0.2194 - accuracy: 0.9372
    Model: "sequential_74"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_222 (Conv1D)          (None, 88, 256)           2560      
    _________________________________________________________________
    max_pooling1d_74 (MaxPooling (None, 22, 256)           0         
    _________________________________________________________________
    conv1d_223 (Conv1D)          (None, 20, 768)           590592    
    _________________________________________________________________
    average_pooling1d_74 (Averag (None, 5, 768)            0         
    _________________________________________________________________
    conv1d_224 (Conv1D)          (None, 3, 256)            590080    
    _________________________________________________________________
    global_average_pooling1d_74  (None, 256)               0         
    _________________________________________________________________
    dense_222 (Dense)            (None, 512)               131584    
    _________________________________________________________________
    dropout_148 (Dropout)        (None, 512)               0         
    _________________________________________________________________
    dense_223 (Dense)            (None, 256)               131328    
    _________________________________________________________________
    dropout_149 (Dropout)        (None, 256)               0         
    _________________________________________________________________
    dense_224 (Dense)            (None, 6)                 1542      
    =================================================================
    Total params: 1,447,686
    Trainable params: 1,447,686
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
      1/171 [..............................] - ETA: 2s - loss: 1.7946 - accuracy: 0.1602WARNING:tensorflow:Callbacks method `on_train_batch_end` is slow compared to the batch time (batch time: 0.0067s vs `on_train_batch_end` time: 0.0156s). Check your callbacks.
    171/171 [==============================] - 4s 25ms/step - loss: 1.1347 - accuracy: 0.5167
    Epoch 2/30
    171/171 [==============================] - 4s 25ms/step - loss: 0.7817 - accuracy: 0.6854
    Epoch 3/30
    171/171 [==============================] - 4s 24ms/step - loss: 0.5371 - accuracy: 0.7977
    Epoch 4/30
    171/171 [==============================] - 4s 24ms/step - loss: 0.4163 - accuracy: 0.8464
    Epoch 5/30
    171/171 [==============================] - 4s 24ms/step - loss: 0.3816 - accuracy: 0.8603
    Epoch 6/30
    171/171 [==============================] - 4s 24ms/step - loss: 0.3154 - accuracy: 0.8849
    Epoch 7/30
    171/171 [==============================] - 4s 24ms/step - loss: 0.3262 - accuracy: 0.8848
    Epoch 8/30
    171/171 [==============================] - 4s 25ms/step - loss: 0.2708 - accuracy: 0.9020
    Epoch 9/30
    171/171 [==============================] - 4s 24ms/step - loss: 0.2583 - accuracy: 0.9074
    Epoch 10/30
    171/171 [==============================] - 4s 24ms/step - loss: 0.2381 - accuracy: 0.9134
    Epoch 11/30
    171/171 [==============================] - 4s 24ms/step - loss: 0.2206 - accuracy: 0.9205
    Epoch 12/30
    171/171 [==============================] - 4s 24ms/step - loss: 0.2313 - accuracy: 0.9184
    Epoch 13/30
    171/171 [==============================] - 4s 24ms/step - loss: 0.2028 - accuracy: 0.9268
    Epoch 14/30
    171/171 [==============================] - 4s 24ms/step - loss: 0.1935 - accuracy: 0.9300
    Epoch 15/30
    171/171 [==============================] - 4s 24ms/step - loss: 0.1857 - accuracy: 0.9323
    Epoch 16/30
    171/171 [==============================] - 4s 24ms/step - loss: 0.1862 - accuracy: 0.9336
    Epoch 17/30
    171/171 [==============================] - 4s 24ms/step - loss: 0.1784 - accuracy: 0.9351
    Epoch 18/30
    171/171 [==============================] - 4s 24ms/step - loss: 0.1802 - accuracy: 0.9350
    Epoch 19/30
    171/171 [==============================] - 4s 24ms/step - loss: 0.1595 - accuracy: 0.9410
    Epoch 20/30
    171/171 [==============================] - 4s 24ms/step - loss: 0.1501 - accuracy: 0.9444
    Epoch 21/30
    171/171 [==============================] - 4s 24ms/step - loss: 0.1457 - accuracy: 0.9476
    Epoch 22/30
    171/171 [==============================] - 4s 24ms/step - loss: 0.1399 - accuracy: 0.9486
    Epoch 23/30
    171/171 [==============================] - 4s 24ms/step - loss: 0.1374 - accuracy: 0.9492
    Epoch 24/30
    171/171 [==============================] - 4s 24ms/step - loss: 0.1276 - accuracy: 0.9529
    Epoch 25/30
    171/171 [==============================] - 4s 24ms/step - loss: 0.1260 - accuracy: 0.9539
    Epoch 26/30
    171/171 [==============================] - 4s 24ms/step - loss: 0.1244 - accuracy: 0.9554
    Epoch 27/30
    171/171 [==============================] - 4s 24ms/step - loss: 0.1170 - accuracy: 0.9564 0s
    Epoch 28/30
    171/171 [==============================] - 4s 24ms/step - loss: 0.1146 - accuracy: 0.9584
    Epoch 29/30
    171/171 [==============================] - 4s 24ms/step - loss: 0.1183 - accuracy: 0.9568
    Epoch 30/30
    171/171 [==============================] - 4s 24ms/step - loss: 0.1076 - accuracy: 0.9593
    57/57 [==============================] - 0s 9ms/step - loss: 0.2649 - accuracy: 0.9266
    Model: "sequential_75"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_225 (Conv1D)          (None, 88, 256)           2560      
    _________________________________________________________________
    max_pooling1d_75 (MaxPooling (None, 22, 256)           0         
    _________________________________________________________________
    conv1d_226 (Conv1D)          (None, 20, 768)           590592    
    _________________________________________________________________
    average_pooling1d_75 (Averag (None, 5, 768)            0         
    _________________________________________________________________
    conv1d_227 (Conv1D)          (None, 3, 256)            590080    
    _________________________________________________________________
    global_average_pooling1d_75  (None, 256)               0         
    _________________________________________________________________
    dense_225 (Dense)            (None, 512)               131584    
    _________________________________________________________________
    dropout_150 (Dropout)        (None, 512)               0         
    _________________________________________________________________
    dense_226 (Dense)            (None, 256)               131328    
    _________________________________________________________________
    dropout_151 (Dropout)        (None, 256)               0         
    _________________________________________________________________
    dense_227 (Dense)            (None, 6)                 1542      
    =================================================================
    Total params: 1,447,686
    Trainable params: 1,447,686
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 5s 27ms/step - loss: 1.1391 - accuracy: 0.5206
    Epoch 2/30
    171/171 [==============================] - 4s 25ms/step - loss: 0.7868 - accuracy: 0.6808
    Epoch 3/30
    171/171 [==============================] - 4s 25ms/step - loss: 0.5727 - accuracy: 0.7824
    Epoch 4/30
    171/171 [==============================] - 4s 24ms/step - loss: 0.4404 - accuracy: 0.8394
    Epoch 5/30
    171/171 [==============================] - 4s 24ms/step - loss: 0.3549 - accuracy: 0.8670
    Epoch 6/30
    171/171 [==============================] - 4s 25ms/step - loss: 0.3318 - accuracy: 0.8766
    Epoch 7/30
    171/171 [==============================] - 4s 24ms/step - loss: 0.2927 - accuracy: 0.8894
    Epoch 8/30
    171/171 [==============================] - 4s 24ms/step - loss: 0.2649 - accuracy: 0.9015
    Epoch 9/30
    171/171 [==============================] - 4s 25ms/step - loss: 0.2801 - accuracy: 0.8999
    Epoch 10/30
    171/171 [==============================] - 4s 26ms/step - loss: 0.2455 - accuracy: 0.9119
    Epoch 11/30
    171/171 [==============================] - 4s 26ms/step - loss: 0.2348 - accuracy: 0.9139
    Epoch 12/30
    171/171 [==============================] - 4s 25ms/step - loss: 0.2099 - accuracy: 0.9232
    Epoch 13/30
    171/171 [==============================] - 4s 25ms/step - loss: 0.1998 - accuracy: 0.9280
    Epoch 14/30
    171/171 [==============================] - 4s 25ms/step - loss: 0.1982 - accuracy: 0.9272
    Epoch 15/30
    171/171 [==============================] - 4s 25ms/step - loss: 0.2518 - accuracy: 0.9159
    Epoch 16/30
    171/171 [==============================] - 4s 26ms/step - loss: 0.1833 - accuracy: 0.9337
    Epoch 17/30
    171/171 [==============================] - 4s 26ms/step - loss: 0.1693 - accuracy: 0.9384
    Epoch 18/30
    171/171 [==============================] - 5s 27ms/step - loss: 0.1805 - accuracy: 0.9366
    Epoch 19/30
    171/171 [==============================] - 4s 25ms/step - loss: 0.1657 - accuracy: 0.9408
    Epoch 20/30
    171/171 [==============================] - 4s 25ms/step - loss: 0.1541 - accuracy: 0.9443
    Epoch 21/30
    171/171 [==============================] - 4s 25ms/step - loss: 0.1433 - accuracy: 0.9481
    Epoch 22/30
    171/171 [==============================] - 4s 25ms/step - loss: 0.1478 - accuracy: 0.9465
    Epoch 23/30
    171/171 [==============================] - 4s 25ms/step - loss: 0.1334 - accuracy: 0.9501
    Epoch 24/30
    171/171 [==============================] - 4s 26ms/step - loss: 0.1305 - accuracy: 0.9526
    Epoch 25/30
    171/171 [==============================] - 4s 25ms/step - loss: 0.1248 - accuracy: 0.9541
    Epoch 26/30
    171/171 [==============================] - 4s 25ms/step - loss: 0.1239 - accuracy: 0.9555
    Epoch 27/30
    171/171 [==============================] - 4s 25ms/step - loss: 0.1225 - accuracy: 0.9556
    Epoch 28/30
    171/171 [==============================] - 4s 25ms/step - loss: 0.1191 - accuracy: 0.9578
    Epoch 29/30
    171/171 [==============================] - 4s 25ms/step - loss: 0.1118 - accuracy: 0.9594
    Epoch 30/30
    171/171 [==============================] - 4s 25ms/step - loss: 0.1063 - accuracy: 0.9610
    57/57 [==============================] - 1s 12ms/step - loss: 0.2352 - accuracy: 0.9330
    Model: "sequential_76"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_228 (Conv1D)          (None, 88, 256)           2560      
    _________________________________________________________________
    max_pooling1d_76 (MaxPooling (None, 22, 256)           0         
    _________________________________________________________________
    conv1d_229 (Conv1D)          (None, 20, 768)           590592    
    _________________________________________________________________
    average_pooling1d_76 (Averag (None, 5, 768)            0         
    _________________________________________________________________
    conv1d_230 (Conv1D)          (None, 3, 256)            590080    
    _________________________________________________________________
    global_average_pooling1d_76  (None, 256)               0         
    _________________________________________________________________
    dense_228 (Dense)            (None, 512)               131584    
    _________________________________________________________________
    dropout_152 (Dropout)        (None, 512)               0         
    _________________________________________________________________
    dense_229 (Dense)            (None, 256)               131328    
    _________________________________________________________________
    dropout_153 (Dropout)        (None, 256)               0         
    _________________________________________________________________
    dense_230 (Dense)            (None, 6)                 1542      
    =================================================================
    Total params: 1,447,686
    Trainable params: 1,447,686
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
      1/171 [..............................] - ETA: 2s - loss: 1.7964 - accuracy: 0.1758WARNING:tensorflow:Callbacks method `on_train_batch_end` is slow compared to the batch time (batch time: 0.0099s vs `on_train_batch_end` time: 0.0160s). Check your callbacks.
    171/171 [==============================] - 4s 25ms/step - loss: 1.1220 - accuracy: 0.5198
    Epoch 2/30
    171/171 [==============================] - 4s 26ms/step - loss: 0.7747 - accuracy: 0.6837
    Epoch 3/30
    171/171 [==============================] - 4s 25ms/step - loss: 0.5595 - accuracy: 0.7880
    Epoch 4/30
    171/171 [==============================] - 4s 25ms/step - loss: 0.4142 - accuracy: 0.8454
    Epoch 5/30
    171/171 [==============================] - 4s 25ms/step - loss: 0.3572 - accuracy: 0.8687
    Epoch 6/30
    171/171 [==============================] - 4s 25ms/step - loss: 0.3219 - accuracy: 0.8817
    Epoch 7/30
    171/171 [==============================] - 4s 26ms/step - loss: 0.2881 - accuracy: 0.8928
    Epoch 8/30
    171/171 [==============================] - 4s 26ms/step - loss: 0.2640 - accuracy: 0.9021
    Epoch 9/30
    171/171 [==============================] - 4s 26ms/step - loss: 0.2556 - accuracy: 0.9083
    Epoch 10/30
    171/171 [==============================] - 4s 26ms/step - loss: 0.2587 - accuracy: 0.9084
    Epoch 11/30
    171/171 [==============================] - 4s 25ms/step - loss: 0.2234 - accuracy: 0.9174
    Epoch 12/30
    171/171 [==============================] - 4s 25ms/step - loss: 0.2305 - accuracy: 0.9184
    Epoch 13/30
    171/171 [==============================] - 4s 25ms/step - loss: 0.2025 - accuracy: 0.9261
    Epoch 14/30
    171/171 [==============================] - 4s 25ms/step - loss: 0.1898 - accuracy: 0.9306
    Epoch 15/30
    171/171 [==============================] - 4s 25ms/step - loss: 0.2048 - accuracy: 0.9278
    Epoch 16/30
    171/171 [==============================] - 4s 25ms/step - loss: 0.1759 - accuracy: 0.9353
    Epoch 17/30
    171/171 [==============================] - 4s 25ms/step - loss: 0.1716 - accuracy: 0.9388
    Epoch 18/30
    171/171 [==============================] - 4s 25ms/step - loss: 0.1603 - accuracy: 0.9412
    Epoch 19/30
    171/171 [==============================] - 4s 25ms/step - loss: 0.1528 - accuracy: 0.9441
    Epoch 20/30
    171/171 [==============================] - 4s 25ms/step - loss: 0.1492 - accuracy: 0.9450
    Epoch 21/30
    171/171 [==============================] - 4s 25ms/step - loss: 0.1461 - accuracy: 0.9475
    Epoch 22/30
    171/171 [==============================] - 4s 25ms/step - loss: 0.1422 - accuracy: 0.9477
    Epoch 23/30
    171/171 [==============================] - 4s 25ms/step - loss: 0.1431 - accuracy: 0.9481
    Epoch 24/30
    171/171 [==============================] - 4s 25ms/step - loss: 0.1329 - accuracy: 0.9522
    Epoch 25/30
    171/171 [==============================] - 4s 25ms/step - loss: 0.1321 - accuracy: 0.9531
    Epoch 26/30
    171/171 [==============================] - 4s 25ms/step - loss: 0.1211 - accuracy: 0.9560
    Epoch 27/30
    171/171 [==============================] - 4s 25ms/step - loss: 0.1204 - accuracy: 0.9545
    Epoch 28/30
    171/171 [==============================] - 4s 25ms/step - loss: 0.1142 - accuracy: 0.9575
    Epoch 29/30
    171/171 [==============================] - 4s 26ms/step - loss: 0.1175 - accuracy: 0.9568
    Epoch 30/30
    171/171 [==============================] - 4s 26ms/step - loss: 0.1082 - accuracy: 0.9603
    57/57 [==============================] - 1s 9ms/step - loss: 0.2284 - accuracy: 0.9354
    Model: "sequential_77"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_231 (Conv1D)          (None, 88, 256)           2560      
    _________________________________________________________________
    max_pooling1d_77 (MaxPooling (None, 44, 256)           0         
    _________________________________________________________________
    conv1d_232 (Conv1D)          (None, 42, 256)           196864    
    _________________________________________________________________
    average_pooling1d_77 (Averag (None, 21, 256)           0         
    _________________________________________________________________
    conv1d_233 (Conv1D)          (None, 17, 768)           983808    
    _________________________________________________________________
    global_average_pooling1d_77  (None, 768)               0         
    _________________________________________________________________
    dense_231 (Dense)            (None, 256)               196864    
    _________________________________________________________________
    dropout_154 (Dropout)        (None, 256)               0         
    _________________________________________________________________
    dense_232 (Dense)            (None, 256)               65792     
    _________________________________________________________________
    dropout_155 (Dropout)        (None, 256)               0         
    _________________________________________________________________
    dense_233 (Dense)            (None, 6)                 1542      
    =================================================================
    Total params: 1,447,430
    Trainable params: 1,447,430
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 6s 34ms/step - loss: 1.1491 - accuracy: 0.5140
    Epoch 2/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.8218 - accuracy: 0.6570
    Epoch 3/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.5835 - accuracy: 0.7760
    Epoch 4/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.4424 - accuracy: 0.8364
    Epoch 5/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.3600 - accuracy: 0.8679
    Epoch 6/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.3335 - accuracy: 0.8774
    Epoch 7/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.2975 - accuracy: 0.8897
    Epoch 8/30
    171/171 [==============================] - 6s 34ms/step - loss: 0.2801 - accuracy: 0.8959
    Epoch 9/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.2591 - accuracy: 0.9027
    Epoch 10/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.2506 - accuracy: 0.9091
    Epoch 11/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.2277 - accuracy: 0.9156
    Epoch 12/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.2356 - accuracy: 0.9142
    Epoch 13/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.2164 - accuracy: 0.9213
    Epoch 14/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.2060 - accuracy: 0.9248
    Epoch 15/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.1943 - accuracy: 0.9283
    Epoch 16/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.1919 - accuracy: 0.9306
    Epoch 17/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.1840 - accuracy: 0.9329
    Epoch 18/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.2490 - accuracy: 0.9163
    Epoch 19/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.1800 - accuracy: 0.9341
    Epoch 20/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.1650 - accuracy: 0.9385
    Epoch 21/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.1618 - accuracy: 0.9412
    Epoch 22/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.1566 - accuracy: 0.9432
    Epoch 23/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.1503 - accuracy: 0.9447
    Epoch 24/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.1461 - accuracy: 0.9456
    Epoch 25/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.1952 - accuracy: 0.9339
    Epoch 26/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.1434 - accuracy: 0.9470
    Epoch 27/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.1453 - accuracy: 0.9479
    Epoch 28/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.1307 - accuracy: 0.9525
    Epoch 29/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.1272 - accuracy: 0.9532
    Epoch 30/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.1294 - accuracy: 0.9527
    57/57 [==============================] - 1s 12ms/step - loss: 0.1921 - accuracy: 0.9378
    Model: "sequential_78"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_234 (Conv1D)          (None, 88, 256)           2560      
    _________________________________________________________________
    max_pooling1d_78 (MaxPooling (None, 44, 256)           0         
    _________________________________________________________________
    conv1d_235 (Conv1D)          (None, 42, 256)           196864    
    _________________________________________________________________
    average_pooling1d_78 (Averag (None, 21, 256)           0         
    _________________________________________________________________
    conv1d_236 (Conv1D)          (None, 17, 768)           983808    
    _________________________________________________________________
    global_average_pooling1d_78  (None, 768)               0         
    _________________________________________________________________
    dense_234 (Dense)            (None, 256)               196864    
    _________________________________________________________________
    dropout_156 (Dropout)        (None, 256)               0         
    _________________________________________________________________
    dense_235 (Dense)            (None, 256)               65792     
    _________________________________________________________________
    dropout_157 (Dropout)        (None, 256)               0         
    _________________________________________________________________
    dense_236 (Dense)            (None, 6)                 1542      
    =================================================================
    Total params: 1,447,430
    Trainable params: 1,447,430
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 6s 33ms/step - loss: 1.1443 - accuracy: 0.5175
    Epoch 2/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.8088 - accuracy: 0.6653
    Epoch 3/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.6001 - accuracy: 0.7630
    Epoch 4/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.4248 - accuracy: 0.8432
    Epoch 5/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.3673 - accuracy: 0.8670
    Epoch 6/30
    171/171 [==============================] - 6s 33ms/step - loss: 0.3153 - accuracy: 0.8820
    Epoch 7/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.3338 - accuracy: 0.8806
    Epoch 8/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.2693 - accuracy: 0.8996
    Epoch 9/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.2606 - accuracy: 0.9056
    Epoch 10/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.2621 - accuracy: 0.9056
    Epoch 11/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.2288 - accuracy: 0.9162
    Epoch 12/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.2331 - accuracy: 0.9168
    Epoch 13/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.2107 - accuracy: 0.9229
    Epoch 14/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.1987 - accuracy: 0.9274 0s - los
    Epoch 15/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.1904 - accuracy: 0.9299
    Epoch 16/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.1887 - accuracy: 0.9310
    Epoch 17/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.1788 - accuracy: 0.9337
    Epoch 18/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.1705 - accuracy: 0.9364 0s - loss: 0.1710 - accu
    Epoch 19/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.2104 - accuracy: 0.9292
    Epoch 20/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.1645 - accuracy: 0.9395
    Epoch 21/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.1582 - accuracy: 0.9420
    Epoch 22/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.1583 - accuracy: 0.9419
    Epoch 23/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.1491 - accuracy: 0.9457
    Epoch 24/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.1452 - accuracy: 0.9458
    Epoch 25/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.1388 - accuracy: 0.9478
    Epoch 26/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.1368 - accuracy: 0.9506
    Epoch 27/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.1305 - accuracy: 0.9517
    Epoch 28/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.1314 - accuracy: 0.9512
    Epoch 29/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.1272 - accuracy: 0.9533
    Epoch 30/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.1235 - accuracy: 0.9540
    57/57 [==============================] - 1s 12ms/step - loss: 0.2065 - accuracy: 0.9377
    Model: "sequential_79"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_237 (Conv1D)          (None, 88, 256)           2560      
    _________________________________________________________________
    max_pooling1d_79 (MaxPooling (None, 44, 256)           0         
    _________________________________________________________________
    conv1d_238 (Conv1D)          (None, 42, 256)           196864    
    _________________________________________________________________
    average_pooling1d_79 (Averag (None, 21, 256)           0         
    _________________________________________________________________
    conv1d_239 (Conv1D)          (None, 17, 768)           983808    
    _________________________________________________________________
    global_average_pooling1d_79  (None, 768)               0         
    _________________________________________________________________
    dense_237 (Dense)            (None, 256)               196864    
    _________________________________________________________________
    dropout_158 (Dropout)        (None, 256)               0         
    _________________________________________________________________
    dense_238 (Dense)            (None, 256)               65792     
    _________________________________________________________________
    dropout_159 (Dropout)        (None, 256)               0         
    _________________________________________________________________
    dense_239 (Dense)            (None, 6)                 1542      
    =================================================================
    Total params: 1,447,430
    Trainable params: 1,447,430
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 6s 33ms/step - loss: 1.1553 - accuracy: 0.5145
    Epoch 2/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.8103 - accuracy: 0.6704
    Epoch 3/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.6318 - accuracy: 0.7538
    Epoch 4/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.4546 - accuracy: 0.8336
    Epoch 5/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.3620 - accuracy: 0.8664
    Epoch 6/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.3168 - accuracy: 0.8822
    Epoch 7/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.3015 - accuracy: 0.8899
    Epoch 8/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.2759 - accuracy: 0.8988
    Epoch 9/30
    171/171 [==============================] - 5s 32ms/step - loss: 0.2604 - accuracy: 0.9022
    Epoch 10/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.2380 - accuracy: 0.9126
    Epoch 11/30
    171/171 [==============================] - 5s 32ms/step - loss: 0.2511 - accuracy: 0.9112 0s - loss: 0.2523 - accuracy: 
    Epoch 12/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.2196 - accuracy: 0.9205
    Epoch 13/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.2072 - accuracy: 0.9233
    Epoch 14/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.2032 - accuracy: 0.9249
    Epoch 15/30
    171/171 [==============================] - 5s 32ms/step - loss: 0.1932 - accuracy: 0.9278
    Epoch 16/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.1860 - accuracy: 0.9315
    Epoch 17/30
    171/171 [==============================] - 5s 32ms/step - loss: 0.1870 - accuracy: 0.9298
    Epoch 18/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.1765 - accuracy: 0.9342
    Epoch 19/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.1724 - accuracy: 0.9355
    Epoch 20/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.1706 - accuracy: 0.9361
    Epoch 21/30
    171/171 [==============================] - 5s 32ms/step - loss: 0.1711 - accuracy: 0.9382
    Epoch 22/30
    171/171 [==============================] - 5s 32ms/step - loss: 0.1573 - accuracy: 0.9410
    Epoch 23/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.1546 - accuracy: 0.9414
    Epoch 24/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.1485 - accuracy: 0.9439
    Epoch 25/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.1598 - accuracy: 0.9422
    Epoch 26/30
    171/171 [==============================] - 5s 32ms/step - loss: 0.1435 - accuracy: 0.9461
    Epoch 27/30
    171/171 [==============================] - 5s 32ms/step - loss: 0.1428 - accuracy: 0.9449
    Epoch 28/30
    171/171 [==============================] - 5s 32ms/step - loss: 0.1413 - accuracy: 0.9482
    Epoch 29/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.1284 - accuracy: 0.9513
    Epoch 30/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.1286 - accuracy: 0.9513
    57/57 [==============================] - 1s 12ms/step - loss: 0.2235 - accuracy: 0.9310
    Model: "sequential_80"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_240 (Conv1D)          (None, 88, 256)           2560      
    _________________________________________________________________
    max_pooling1d_80 (MaxPooling (None, 44, 256)           0         
    _________________________________________________________________
    conv1d_241 (Conv1D)          (None, 42, 256)           196864    
    _________________________________________________________________
    average_pooling1d_80 (Averag (None, 21, 256)           0         
    _________________________________________________________________
    conv1d_242 (Conv1D)          (None, 17, 768)           983808    
    _________________________________________________________________
    global_average_pooling1d_80  (None, 768)               0         
    _________________________________________________________________
    dense_240 (Dense)            (None, 256)               196864    
    _________________________________________________________________
    dropout_160 (Dropout)        (None, 256)               0         
    _________________________________________________________________
    dense_241 (Dense)            (None, 256)               65792     
    _________________________________________________________________
    dropout_161 (Dropout)        (None, 256)               0         
    _________________________________________________________________
    dense_242 (Dense)            (None, 6)                 1542      
    =================================================================
    Total params: 1,447,430
    Trainable params: 1,447,430
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
    171/171 [==============================] - 6s 32ms/step - loss: 1.1504 - accuracy: 0.5124
    Epoch 2/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.8250 - accuracy: 0.6594
    Epoch 3/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.6073 - accuracy: 0.7615
    Epoch 4/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.4359 - accuracy: 0.8381
    Epoch 5/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.3549 - accuracy: 0.8680
    Epoch 6/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.3771 - accuracy: 0.8657
    Epoch 7/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.2915 - accuracy: 0.8921
    Epoch 8/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.2843 - accuracy: 0.8971
    Epoch 9/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.2599 - accuracy: 0.9038
    Epoch 10/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.2403 - accuracy: 0.9126
    Epoch 11/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.2345 - accuracy: 0.9158
    Epoch 12/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.2156 - accuracy: 0.9208
    Epoch 13/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.2069 - accuracy: 0.9248
    Epoch 14/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.2053 - accuracy: 0.9262
    Epoch 15/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.1918 - accuracy: 0.9296
    Epoch 16/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.1878 - accuracy: 0.9307
    Epoch 17/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.1931 - accuracy: 0.9314
    Epoch 18/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.1798 - accuracy: 0.9344
    Epoch 19/30
    171/171 [==============================] - 5s 32ms/step - loss: 0.1659 - accuracy: 0.9377 0s - loss:
    Epoch 20/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.1581 - accuracy: 0.9398
    Epoch 21/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.1585 - accuracy: 0.9405
    Epoch 22/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.1738 - accuracy: 0.9372
    Epoch 23/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.1486 - accuracy: 0.9451
    Epoch 24/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.1469 - accuracy: 0.9447
    Epoch 25/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.1419 - accuracy: 0.9479
    Epoch 26/30
    171/171 [==============================] - 5s 32ms/step - loss: 0.1360 - accuracy: 0.9485
    Epoch 27/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.1331 - accuracy: 0.9501
    Epoch 28/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.1333 - accuracy: 0.9496
    Epoch 29/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.1307 - accuracy: 0.9516
    Epoch 30/30
    171/171 [==============================] - 6s 32ms/step - loss: 0.1247 - accuracy: 0.9540
    57/57 [==============================] - 1s 11ms/step - loss: 0.1877 - accuracy: 0.9383
    Model: "sequential_81"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    conv1d_243 (Conv1D)          (None, 86, 768)           12288     
    _________________________________________________________________
    max_pooling1d_81 (MaxPooling (None, 43, 768)           0         
    _________________________________________________________________
    conv1d_244 (Conv1D)          (None, 39, 768)           2949888   
    _________________________________________________________________
    average_pooling1d_81 (Averag (None, 19, 768)           0         
    _________________________________________________________________
    conv1d_245 (Conv1D)          (None, 17, 256)           590080    
    _________________________________________________________________
    global_average_pooling1d_81  (None, 256)               0         
    _________________________________________________________________
    dense_243 (Dense)            (None, 512)               131584    
    _________________________________________________________________
    dropout_162 (Dropout)        (None, 512)               0         
    _________________________________________________________________
    dense_244 (Dense)            (None, 256)               131328    
    _________________________________________________________________
    dropout_163 (Dropout)        (None, 256)               0         
    _________________________________________________________________
    dense_245 (Dense)            (None, 6)                 1542      
    =================================================================
    Total params: 3,816,710
    Trainable params: 3,816,710
    Non-trainable params: 0
    _________________________________________________________________
    Epoch 1/30
      2/228 [..............................] - ETA: 21s - loss: 1.7703 - accuracy: 0.1875WARNING:tensorflow:Callbacks method `on_train_batch_end` is slow compared to the batch time (batch time: 0.0411s vs `on_train_batch_end` time: 0.0695s). Check your callbacks.
    228/228 [==============================] - 24s 107ms/step - loss: 1.0827 - accuracy: 0.5452s - loss: 1
    Epoch 2/30
    228/228 [==============================] - 24s 104ms/step - loss: 0.7082 - accuracy: 0.7148
    Epoch 3/30
    228/228 [==============================] - 24s 104ms/step - loss: 0.4706 - accuracy: 0.8234
    Epoch 4/30
    228/228 [==============================] - 24s 104ms/step - loss: 0.3780 - accuracy: 0.8595
    Epoch 5/30
    228/228 [==============================] - 24s 104ms/step - loss: 0.3217 - accuracy: 0.8810
    Epoch 6/30
    228/228 [==============================] - 24s 104ms/step - loss: 0.3090 - accuracy: 0.8848
    Epoch 7/30
    228/228 [==============================] - 24s 103ms/step - loss: 0.2887 - accuracy: 0.8930
    Epoch 8/30
    228/228 [==============================] - 24s 103ms/step - loss: 0.2572 - accuracy: 0.9036
    Epoch 9/30
    228/228 [==============================] - 24s 103ms/step - loss: 0.2561 - accuracy: 0.9068
    Epoch 10/30
    228/228 [==============================] - 24s 103ms/step - loss: 0.2287 - accuracy: 0.9157
    Epoch 11/30
    228/228 [==============================] - 24s 103ms/step - loss: 0.2675 - accuracy: 0.9076
    Epoch 12/30
    228/228 [==============================] - 24s 103ms/step - loss: 0.2091 - accuracy: 0.9228
    Epoch 13/30
    228/228 [==============================] - 24s 103ms/step - loss: 0.1963 - accuracy: 0.9277
    Epoch 14/30
    228/228 [==============================] - 24s 103ms/step - loss: 0.1941 - accuracy: 0.9289
    Epoch 15/30
    228/228 [==============================] - 24s 103ms/step - loss: 0.1826 - accuracy: 0.9324
    Epoch 16/30
    228/228 [==============================] - 24s 103ms/step - loss: 0.1786 - accuracy: 0.9323
    Epoch 17/30
    228/228 [==============================] - 24s 103ms/step - loss: 0.1716 - accuracy: 0.9365
    Epoch 18/30
    228/228 [==============================] - 24s 103ms/step - loss: 0.1637 - accuracy: 0.9398
    Epoch 19/30
    228/228 [==============================] - 24s 103ms/step - loss: 0.1564 - accuracy: 0.9408
    Epoch 20/30
    228/228 [==============================] - 24s 103ms/step - loss: 0.1585 - accuracy: 0.9414
    Epoch 21/30
    228/228 [==============================] - 24s 103ms/step - loss: 0.1493 - accuracy: 0.9429
    Epoch 22/30
    228/228 [==============================] - 24s 103ms/step - loss: 0.1437 - accuracy: 0.9454
    Epoch 23/30
    228/228 [==============================] - 24s 103ms/step - loss: 0.1486 - accuracy: 0.9458
    Epoch 24/30
    228/228 [==============================] - 24s 103ms/step - loss: 0.1415 - accuracy: 0.9479
    Epoch 25/30
    228/228 [==============================] - 24s 103ms/step - loss: 0.1290 - accuracy: 0.9515
    Epoch 26/30
    228/228 [==============================] - 24s 103ms/step - loss: 0.1305 - accuracy: 0.9508
    Epoch 27/30
    228/228 [==============================] - 24s 103ms/step - loss: 0.1253 - accuracy: 0.9532
    Epoch 28/30
    228/228 [==============================] - 24s 103ms/step - loss: 0.1211 - accuracy: 0.9535
    Epoch 29/30
    228/228 [==============================] - 24s 103ms/step - loss: 0.1206 - accuracy: 0.9540
    Epoch 30/30
    228/228 [==============================] - 24s 103ms/step - loss: 0.1173 - accuracy: 0.9552
    Wall time: 6h 32min 7s
    


```python
print('Best score is: {} using {}'.format(rscv_results.best_score_,
rscv_results.best_params_))
```

    Best score is: 0.9387933015823364 using {'n_dense_2': 256, 'n_dense_1': 512, 'n_conv_3': 256, 'n_conv_2': 768, 'n_conv_1': 768, 'maxpooling_pool_size': 2, 'k_conv_3': 3, 'k_conv_2': 5, 'k_conv_1': 5, 'dropout_2': 0.4, 'dropout_1': 0.4, 'avepooling_pool_size': 2, 'activation': 'relu'}
    


```python
best_model = rscv_results.best_estimator_
```

### Test the best model based on the validation data


```python
y_hat = best_model.predict(X_valid)
```

    WARNING:tensorflow:From C:\Users\dfuller\AppData\Local\Continuum\anaconda3\envs\tf-gpu\lib\site-packages\tensorflow\python\keras\wrappers\scikit_learn.py:241: Sequential.predict_classes (from tensorflow.python.keras.engine.sequential) is deprecated and will be removed after 2021-01-01.
    Instructions for updating:
    Please use instead:* `np.argmax(model.predict(x), axis=-1)`,   if your model does multi-class classification   (e.g. if it uses a `softmax` last-layer activation).* `(model.predict(x) > 0.5).astype("int32")`,   if your model does binary classification   (e.g. if it uses a `sigmoid` last-layer activation).
    


```python
y_hat = to_categorical(y_hat)
y_hat[0]
```




    array([0., 0., 0., 0., 0., 1.], dtype=float32)




```python
y_valid[0]
```




    array([0., 0., 0., 0., 0., 1.], dtype=float32)




```python
plt.hist(y_hat)
_ = plt.axvline(x=0.5, color='orange')
```


    
![png](output_30_0.png)
    



```python
from sklearn.metrics import  accuracy_score as score
y_pred_classes = y_hat.round()
print(y_valid[0], y_hat[0], y_pred_classes[0])
acc = score(y_valid, y_pred_classes) * 100
acc
```

    [0. 0. 0. 0. 0. 1.] [0. 0. 0. 0. 0. 1.] [0. 0. 0. 0. 0. 1.]
    




    94.34836318715256




```python
pct_auc = roc_auc_score(y_valid, y_hat)*100.0
```


```python
"{:0.2f}".format(pct_auc)
```




    '96.65'




```python
float_y_hat = []
for y in y_hat:
    float_y_hat.append(y[0:6].round(3))
```


```python
ydf = pd.DataFrame(list(zip(float_y_hat, y_valid)), columns=['y_hat', 'y'])
```


```python
ydf.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>y_hat</th>
      <th>y</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>[0.0, 0.0, 0.0, 0.0, 0.0, 1.0]</td>
      <td>[0.0, 0.0, 0.0, 0.0, 0.0, 1.0]</td>
    </tr>
    <tr>
      <th>1</th>
      <td>[0.0, 0.0, 1.0, 0.0, 0.0, 0.0]</td>
      <td>[0.0, 0.0, 1.0, 0.0, 0.0, 0.0]</td>
    </tr>
    <tr>
      <th>2</th>
      <td>[0.0, 1.0, 0.0, 0.0, 0.0, 0.0]</td>
      <td>[0.0, 1.0, 0.0, 0.0, 0.0, 0.0]</td>
    </tr>
    <tr>
      <th>3</th>
      <td>[1.0, 0.0, 0.0, 0.0, 0.0, 0.0]</td>
      <td>[1.0, 0.0, 0.0, 0.0, 0.0, 0.0]</td>
    </tr>
    <tr>
      <th>4</th>
      <td>[0.0, 1.0, 0.0, 0.0, 0.0, 0.0]</td>
      <td>[0.0, 1.0, 0.0, 0.0, 0.0, 0.0]</td>
    </tr>
    <tr>
      <th>5</th>
      <td>[0.0, 0.0, 0.0, 0.0, 0.0, 1.0]</td>
      <td>[0.0, 0.0, 0.0, 0.0, 0.0, 1.0]</td>
    </tr>
    <tr>
      <th>6</th>
      <td>[0.0, 0.0, 0.0, 1.0, 0.0, 0.0]</td>
      <td>[0.0, 0.0, 0.0, 1.0, 0.0, 0.0]</td>
    </tr>
    <tr>
      <th>7</th>
      <td>[0.0, 1.0, 0.0, 0.0, 0.0, 0.0]</td>
      <td>[0.0, 1.0, 0.0, 0.0, 0.0, 0.0]</td>
    </tr>
    <tr>
      <th>8</th>
      <td>[1.0, 0.0, 0.0, 0.0, 0.0, 0.0]</td>
      <td>[1.0, 0.0, 0.0, 0.0, 0.0, 0.0]</td>
    </tr>
    <tr>
      <th>9</th>
      <td>[0.0, 1.0, 0.0, 0.0, 0.0, 0.0]</td>
      <td>[0.0, 1.0, 0.0, 0.0, 0.0, 0.0]</td>
    </tr>
  </tbody>
</table>
</div>




```python
results_df = pd.DataFrame(rscv_results.cv_results_['params'])
results_df['mean'] = rscv_results.cv_results_['mean_test_score']
results_df['std'] = rscv_results.cv_results_['std_test_score']
results_df.sort_values('mean', ascending=False, ignore_index=False)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>n_dense_2</th>
      <th>n_dense_1</th>
      <th>n_conv_3</th>
      <th>n_conv_2</th>
      <th>n_conv_1</th>
      <th>maxpooling_pool_size</th>
      <th>k_conv_3</th>
      <th>k_conv_2</th>
      <th>k_conv_1</th>
      <th>dropout_2</th>
      <th>dropout_1</th>
      <th>avepooling_pool_size</th>
      <th>activation</th>
      <th>mean</th>
      <th>std</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>13</th>
      <td>256</td>
      <td>512</td>
      <td>256</td>
      <td>768</td>
      <td>768</td>
      <td>2</td>
      <td>3</td>
      <td>5</td>
      <td>5</td>
      <td>0.4</td>
      <td>0.4</td>
      <td>2</td>
      <td>relu</td>
      <td>0.938793</td>
      <td>0.001746</td>
    </tr>
    <tr>
      <th>7</th>
      <td>512</td>
      <td>512</td>
      <td>512</td>
      <td>512</td>
      <td>768</td>
      <td>2</td>
      <td>3</td>
      <td>5</td>
      <td>5</td>
      <td>0.2</td>
      <td>0.2</td>
      <td>2</td>
      <td>relu</td>
      <td>0.938485</td>
      <td>0.003455</td>
    </tr>
    <tr>
      <th>10</th>
      <td>256</td>
      <td>256</td>
      <td>256</td>
      <td>512</td>
      <td>768</td>
      <td>2</td>
      <td>3</td>
      <td>3</td>
      <td>5</td>
      <td>0.2</td>
      <td>0.2</td>
      <td>2</td>
      <td>relu</td>
      <td>0.936837</td>
      <td>0.002056</td>
    </tr>
    <tr>
      <th>11</th>
      <td>512</td>
      <td>512</td>
      <td>512</td>
      <td>512</td>
      <td>768</td>
      <td>4</td>
      <td>3</td>
      <td>5</td>
      <td>3</td>
      <td>0.4</td>
      <td>0.2</td>
      <td>2</td>
      <td>relu</td>
      <td>0.936597</td>
      <td>0.000815</td>
    </tr>
    <tr>
      <th>19</th>
      <td>256</td>
      <td>256</td>
      <td>768</td>
      <td>256</td>
      <td>256</td>
      <td>2</td>
      <td>5</td>
      <td>3</td>
      <td>3</td>
      <td>0.2</td>
      <td>0.4</td>
      <td>2</td>
      <td>relu</td>
      <td>0.936202</td>
      <td>0.003002</td>
    </tr>
    <tr>
      <th>3</th>
      <td>512</td>
      <td>512</td>
      <td>256</td>
      <td>512</td>
      <td>256</td>
      <td>2</td>
      <td>3</td>
      <td>3</td>
      <td>3</td>
      <td>0.2</td>
      <td>0.4</td>
      <td>4</td>
      <td>relu</td>
      <td>0.933851</td>
      <td>0.003627</td>
    </tr>
    <tr>
      <th>15</th>
      <td>256</td>
      <td>256</td>
      <td>512</td>
      <td>512</td>
      <td>256</td>
      <td>2</td>
      <td>5</td>
      <td>5</td>
      <td>3</td>
      <td>0.2</td>
      <td>0.2</td>
      <td>4</td>
      <td>relu</td>
      <td>0.933628</td>
      <td>0.004654</td>
    </tr>
    <tr>
      <th>18</th>
      <td>256</td>
      <td>512</td>
      <td>256</td>
      <td>768</td>
      <td>256</td>
      <td>4</td>
      <td>3</td>
      <td>3</td>
      <td>3</td>
      <td>0.2</td>
      <td>0.4</td>
      <td>4</td>
      <td>relu</td>
      <td>0.933062</td>
      <td>0.004000</td>
    </tr>
    <tr>
      <th>12</th>
      <td>512</td>
      <td>512</td>
      <td>512</td>
      <td>768</td>
      <td>768</td>
      <td>4</td>
      <td>5</td>
      <td>3</td>
      <td>5</td>
      <td>0.2</td>
      <td>0.2</td>
      <td>2</td>
      <td>relu</td>
      <td>0.932547</td>
      <td>0.005648</td>
    </tr>
    <tr>
      <th>8</th>
      <td>256</td>
      <td>256</td>
      <td>512</td>
      <td>256</td>
      <td>768</td>
      <td>2</td>
      <td>3</td>
      <td>3</td>
      <td>5</td>
      <td>0.2</td>
      <td>0.2</td>
      <td>2</td>
      <td>relu</td>
      <td>0.932170</td>
      <td>0.002025</td>
    </tr>
    <tr>
      <th>0</th>
      <td>512</td>
      <td>512</td>
      <td>768</td>
      <td>768</td>
      <td>512</td>
      <td>4</td>
      <td>5</td>
      <td>3</td>
      <td>5</td>
      <td>0.4</td>
      <td>0.4</td>
      <td>2</td>
      <td>relu</td>
      <td>0.930454</td>
      <td>0.002463</td>
    </tr>
    <tr>
      <th>9</th>
      <td>512</td>
      <td>256</td>
      <td>768</td>
      <td>768</td>
      <td>256</td>
      <td>4</td>
      <td>5</td>
      <td>5</td>
      <td>5</td>
      <td>0.2</td>
      <td>0.4</td>
      <td>2</td>
      <td>relu</td>
      <td>0.925358</td>
      <td>0.006678</td>
    </tr>
    <tr>
      <th>6</th>
      <td>512</td>
      <td>256</td>
      <td>256</td>
      <td>512</td>
      <td>512</td>
      <td>4</td>
      <td>3</td>
      <td>3</td>
      <td>3</td>
      <td>0.2</td>
      <td>0.2</td>
      <td>2</td>
      <td>elu</td>
      <td>0.908542</td>
      <td>0.001080</td>
    </tr>
    <tr>
      <th>4</th>
      <td>256</td>
      <td>512</td>
      <td>512</td>
      <td>512</td>
      <td>256</td>
      <td>4</td>
      <td>5</td>
      <td>5</td>
      <td>3</td>
      <td>0.2</td>
      <td>0.2</td>
      <td>2</td>
      <td>elu</td>
      <td>0.903617</td>
      <td>0.004077</td>
    </tr>
    <tr>
      <th>1</th>
      <td>256</td>
      <td>512</td>
      <td>768</td>
      <td>256</td>
      <td>768</td>
      <td>4</td>
      <td>5</td>
      <td>5</td>
      <td>5</td>
      <td>0.4</td>
      <td>0.2</td>
      <td>2</td>
      <td>elu</td>
      <td>0.893751</td>
      <td>0.008755</td>
    </tr>
    <tr>
      <th>5</th>
      <td>256</td>
      <td>256</td>
      <td>768</td>
      <td>512</td>
      <td>512</td>
      <td>2</td>
      <td>3</td>
      <td>5</td>
      <td>5</td>
      <td>0.2</td>
      <td>0.2</td>
      <td>2</td>
      <td>elu</td>
      <td>0.891365</td>
      <td>0.007460</td>
    </tr>
    <tr>
      <th>2</th>
      <td>256</td>
      <td>512</td>
      <td>256</td>
      <td>768</td>
      <td>768</td>
      <td>2</td>
      <td>3</td>
      <td>3</td>
      <td>3</td>
      <td>0.4</td>
      <td>0.2</td>
      <td>2</td>
      <td>elu</td>
      <td>0.890199</td>
      <td>0.009477</td>
    </tr>
    <tr>
      <th>16</th>
      <td>512</td>
      <td>512</td>
      <td>768</td>
      <td>512</td>
      <td>256</td>
      <td>4</td>
      <td>5</td>
      <td>5</td>
      <td>5</td>
      <td>0.4</td>
      <td>0.2</td>
      <td>2</td>
      <td>elu</td>
      <td>0.880658</td>
      <td>0.005808</td>
    </tr>
    <tr>
      <th>14</th>
      <td>256</td>
      <td>512</td>
      <td>768</td>
      <td>768</td>
      <td>768</td>
      <td>2</td>
      <td>5</td>
      <td>3</td>
      <td>5</td>
      <td>0.4</td>
      <td>0.2</td>
      <td>4</td>
      <td>elu</td>
      <td>0.877175</td>
      <td>0.009149</td>
    </tr>
    <tr>
      <th>17</th>
      <td>256</td>
      <td>512</td>
      <td>256</td>
      <td>512</td>
      <td>512</td>
      <td>2</td>
      <td>3</td>
      <td>3</td>
      <td>5</td>
      <td>0.4</td>
      <td>0.4</td>
      <td>2</td>
      <td>elu</td>
      <td>0.866004</td>
      <td>0.002856</td>
    </tr>
  </tbody>
</table>
</div>




```python

```
